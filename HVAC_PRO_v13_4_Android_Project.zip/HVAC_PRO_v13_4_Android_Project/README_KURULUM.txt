HVAC PRO — Android Studio kaynak projesi
==========================================

Bu paket derlenmiş APK değildir; Android Studio kaynak projesidir.
Bu çalışma sürümünde:
- Türkçe / İngilizce dil seçimi için ilk arayüz desteği
- Ücretsiz temel hesaplama ekranları
- Professional özellik tanıtım ekranı (ödeme henüz bağlı değildir)
- Soğutma yükü, taze hava, proje kaydetme ve yazdırma/PDF akışı

ÖNEMLİ:
Professional ekranı şu an yalnızca ürün taslağıdır. Google Play Billing,
abonelik/tek seferlik satın alma, gizlilik politikası, imzalama anahtarı,
Play Console kaydı ve mağaza gereklilikleri henüz entegre edilmemiştir.
Hesaplama sonuçları ön boyutlandırma içindir; mühendislik doğrulaması gerekir.

APK oluşturma:
1. Android Studio kurulu bir bilgisayarda bu klasörü aç.
2. Gradle Sync tamamlandıktan sonra Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk

Telefon-only kullanıcı için:
Bu projeye GitHub Actions derleme akışı eklenerek telefondan GitHub web arayüzüyle
APK derlemek mümkün hale getirilebilir. Google Play yayını için ayrıca Play Console
geliştirici hesabı gerekir.


V5 NOTU: Yapı elemanları için U değeri seçenekleri sadeleştirilmiştir. Listeden yalıtım seviyesini seçebilir veya Manuel değer gir seçeneğini kullanabilirsiniz. Ön seçimler yaklaşık değerlerdir; kesin proje değerleri yapı detaylarından doğrulanmalıdır.


V6 NOTU: Türkiye'nin 81 ili için yaklaşık dış hava sıcaklığı başlangıç değerleri eklendi. Bu değerler resmî/standart tasarım koşulu değildir; proje bazında meteoroloji veya kabul edilen tasarım iklim verileriyle doğrulanmalıdır. Cam güneş kazancı yön ve gölgeleme katsayısıyla yaklaşık düzeltilir. Taze hava yükü, entalpi kuru hava kütlesi bazında hesaplanacak şekilde güncellendi. Sıcaklık girişlerinde negatif değer desteği eklendi.

V9: Android WebView native PrintManager bridge eklendi. Raporu yazdır/PDF butonu Android yazdırma ekranını açar; hedef olarak 'PDF olarak kaydet' seçilerek dosya kaydedilebilir. Android cihazda gerçek çıktı testi yapılmalıdır.


V10: Yaz/kış tasarım koşulu alanları, ilçe/proje konumu, tasarım verisi kaynağı seçimi ve basınç kaynağı seçimi eklendi. Şehir profilleri ön kabul niteliğindedir; resmî meteorolojik tasarım verisi değildir. Kış sıcaklığı V10’da kayıt/raporlama girdisidir; ısıtma yükü hesabı henüz eklenmemiştir.

V11: Kış tasarım dış hava sıcaklığı girildiğinde yaklaşık ısıtma yükü ön hesabı gösterilir. Bu hesap; duvar, çatı, zemin, cam iletimi ve taze hava/infiltrasyon duyulur kaybını içerir. Zemin için dış hava farkı kullanımı basitleştirilmiştir; profesyonel proje hesabında döşeme/zemin ve komşu hacim koşulları ayrıca doğrulanmalıdır.

V11.1 düzeltmesi: Kış tasarım dış hava sıcaklığı alanı metin girişi olarak değiştirildi; negatif değerler ve virgüllü ondalık girişler (ör. -8,5) desteklenir.


V11.2 DÜZELTMELERİ
- Ekranda görünen hatalı \\n metni kaldırıldı.
- Kış tasarım sıcaklığı boş bırakıldığında önceki ısıtma sonucu kayıt hafızasından temizlenir.


V12.0 – GOOGLE PLAY HAZIRLIK AŞAMASI
- compileSdk ve targetSdk 36 olarak güncellendi.
- Android Gradle Plugin 8.10.1 ve Gradle 8.11.1 kullanılır.
- GitHub Actions artık test için debug APK ve yayın hazırlığı için release AAB üretir.
- Üretilen release AAB henüz imzalı değildir; Google Play'e yüklemek için güvenli upload keystore/signing yapılandırması ayrıca yapılmalıdır.
- Google Play Billing henüz eklenmedi. Professional/ısıtma kilidi satın alma doğrulaması tamamlanana kadar etkinleştirilmemelidir.
- Ürün kimliği planı: hvac_pro_professional_lifetime (tek seferlik, tüketilmeyen ürün). Fiyat hedefi 349 TL; Play Console'da ayrıca tanımlanacaktır.


HVAC PRO V12.2
- Isıtma hesabı ücretsiz sürümde Professional kilidi arkasına alındı.
- Şehir değişince kış dış hava sıcaklığı için rakıma dayalı yaklaşık ön kabul değeri doldurulur.
- Bu değer resmî tasarım meteoroloji verisi değildir; mühendislik projesinde doğrulanmalıdır.
- Google Play Billing henüz entegre değildir; uygulama şu anda ödeme almaz.
- Version code: 15, version name: 12.2.


V12.4 değişikliği: PDF raporu oluşturma/kaydetme işlemi Professional satın alma kontrolüne bağlandı. Google Play Billing henüz entegre değildir; doğrulanmış satın alma olmadan PDF dışa aktarımı açılmaz.


V12.4 ARAYÜZ GÜNCELLEMESİ
- Kurumsal lacivert, mavi ve beyaz renk paleti yenilendi.
- Ana gezinme menüsü mobil uyumlu alt menüye taşındı.
- Hesaplama ve Professional işlevleri korunmuştur.

V12.7: Professional mühendislik araçları arayüzü ve hesap fonksiyonları eklendi: kanal kesiti, Darcy-Weisbach düz/yerel basınç kaybı, kapasite kontrolü, çoklu mahal yük özeti ve ısıtma ön hesabı. Billing entegrasyonu henüz yoktur; HVAC_PRO_ENTITLED false olduğu için araçlar satın alma doğrulanana kadar kilitlidir. Sonuçlar ön boyutlandırma niteliğindedir.

V12.7: Kanal basınç kaybında Reynolds ve Swamee-Jain otomatik Darcy faktörü; esnek çoklu mahal (30 mahal); ısıtma hesabında zemin/komşu hacim sıcaklığı ve taze hava ısı geri kazanım verimi; giriş doğrulama iyileştirmeleri.


HVAC PRO V12.8
- Giriş doğrulamaları: bağıl nem 0–100%, basınç 50–120 kPa, emniyet payı 0–50%.
- Kanal debisi/hız/ölçü doğrulamaları ve boş giriş hatası düzeltildi.
- Basınç kaybı giriş sınırları güçlendirildi; geçiş rejimi uyarısı korunur.
- Soğutma emniyet payı, negatif net yükte yanlış pozitif gösterim üretmeyecek şekilde ayrıştırıldı.
- Isıtma hesabında tasarım sıcaklığı, zemin sıcaklığı, HRV verimi ve emniyet payı doğrulaması eklendi.
Not: Kaynak kodu düzeyinde güncellenmiştir. Android cihaz testi, resmi standart doğrulaması ve Google Play Billing entegrasyonu ayrıca yapılmalıdır.


HVAC PRO V13.0 – YAYIN HAZIRLIK PAKETİ
======================================
- Android versionName 13.0 / versionCode 24.
- Mevcut hesaplama ekranları ve Professional kilitleri korunmuştur.
- Uygulama içi gizlilik politikası ve kullanım kılavuzu HTML sayfaları eklenmiştir.
- PLAY_STORE_MATERIALS klasöründe Türkçe/İngilizce mağaza metin taslakları,
  gizlilik politikası taslağı, veri güvenliği hazırlık notları ve test planı bulunur.
- web/ klasöründe GitHub Pages için basit tanıtım sitesi taslağı vardır.

YAYIN ÖNCESİ ZORUNLU İŞLER:
1. Google Play hesabı kimlik doğrulaması tamamlanmalıdır.
2. hvac_pro_professional_lifetime ürünü Play Console'da tanımlanmalıdır.
3. Gerçek Google Play Billing ve güvenli satın alma doğrulaması yapılmalıdır.
4. Gizlilik politikasındaki [İLETİŞİM E-POSTASI] ve [GELİŞTİRİCİ/İŞLETME ADI]
   alanları doldurulup HTTPS üzerinden yayımlanmalıdır.
5. Data safety formu nihai APK, SDK'lar ve gerçek veri akışına göre tamamlanmalıdır.
6. Release AAB henüz imzalı değildir. Upload keystore ve güvenli imzalama yapılandırması gerekir.
7. Kapalı test, cihaz testleri ve mühendislik doğrulaması tamamlanmalıdır.

GitHub Actions:
Kök .github/workflows/build-apk.yml dosyası depo kökünde korunmalıdır.


V13.1 IKON GUNCELLEMESI
Android launcher adaptive/round/monochrome ikonlari eklendi. Google Play 512x512 ikonu PLAY_STORE_MATERIALS klasorundedir.

V13.1.1 DERLEME DÜZELTMESİ
- Android manifest teması AppTheme olarak ayarlandı.
- androidx.core.splashscreen'e ait olmayan android:postSplashScreenTheme
  özniteliği kaldırıldı. Android'in sistem splash arka planı/ikon kaynakları korundu.
- versionCode 26 / versionName 13.1.1.

V13.2 TEMA GUNCELLEMESI
- Uygulama arayuzu ikonun lacivert/mavi/buz mavisi/turuncu marka paletine uyarlandi.
- Kartlar, alanlar, alt menu, butonlar ve sonuc panelleri koyu tema kontrastina gore duzenlendi.
- Baslik alanindaki kar tanesi yerine HVAC PRO marka ikonu eklendi.
- PWA theme_color ve background_color degerleri koyu marka temasina alindi.
- versionCode 27 / versionName 13.2.

V13.3: Kullanım kılavuzu tam İngilizce çeviriyle dil seçimine bağlandı. Harici kılavuz da dil seçicili. Üst marka alanı daha kompakt ve hizalı hale getirildi. VersionCode 28 / VersionName 13.3.

V13.4: English UI dictionary expanded for remaining calculation, fresh-air, project, Professional and engineering labels/help text. Language switching now also translates placeholders, titles, aria-labels and select options. VersionCode 29 / VersionName 13.4.
