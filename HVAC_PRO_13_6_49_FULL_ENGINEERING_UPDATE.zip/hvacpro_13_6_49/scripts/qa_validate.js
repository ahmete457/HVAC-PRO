#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'app/src/main/assets/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const jsonPath = path.join(root, 'app/src/main/assets/climate-data-tr.json');
const climate = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const climateJsPath = path.join(root, 'app/src/main/assets/climate-data-tr.js');
const climateJs = fs.readFileSync(climateJsPath, 'utf8');
const csv = fs.readFileSync(path.join(root, 'weather-data/turkiye_81_il_on_kabul.csv'), 'utf8').replace(/^\uFEFF/, '');

function pass(message) { console.log(`PASS  ${message}`); }
function near(actual, expected, tolerance, label) {
  assert.ok(Number.isFinite(actual), `${label}: result is not finite`);
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: expected ${expected} ± ${tolerance}, got ${actual}`);
}

// HTML structure and JavaScript syntax.
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const duplicateIds = ids.filter((id, i) => ids.indexOf(id) !== i);
assert.deepStrictEqual([...new Set(duplicateIds)], [], `Duplicate HTML IDs: ${[...new Set(duplicateIds)].join(', ')}`);
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
assert.ok(scripts.length > 0, 'No inline application script found');
for (const script of scripts) new vm.Script(script, { filename: 'index.html:inline-script' });
const allScript = scripts.join('\n');
const literalRefs = [...allScript.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(m => m[1]);
const missingRefs = [...new Set(literalRefs.filter(id => !ids.includes(id)))];
assert.deepStrictEqual(missingRefs, [], `JavaScript references missing DOM IDs: ${missingRefs.join(', ')}`);
pass('HTML IDs are unique; inline JavaScript parses; literal DOM references exist');

// City profiles are retained in the UI for offline WebView use. Keep them synchronized
// with the maintained JSON dataset until the native asset bridge is migrated.
new vm.Script(climateJs, { filename: 'climate-data-tr.js' });
const climateSandbox = { window: {} };
vm.runInNewContext(climateJs, climateSandbox);
assert.ok(climateSandbox.window.HVAC_CLIMATE_DATA, 'Generated climate data asset did not initialize');
assert.strictEqual(JSON.stringify(climateSandbox.window.HVAC_CLIMATE_DATA), JSON.stringify(climate), 'Generated JS climate data is stale; regenerate it from the JSON source');
const cityProfiles = Object.fromEntries(climate.cities.map(c => [c.city, [c.legacy_summer_start_value_c, c.elevation_m, c.legacy_outdoor_rh_start_value_pct]]));
assert.ok(allScript.includes('const cityProfiles=Object.fromEntries(climateRecords.map'), 'Application must derive city profiles from the generated climate data asset');
assert.ok(html.includes('window.HVAC_CLIMATE_DATA ='), 'Application must embed the climate dataset for offline WebView startup');
assert.ok(allScript.includes('if(climateRecords.length!==81){console.error('), 'Missing climate records must not abort all app startup scripts');
assert.strictEqual(climate.schema_version, 1, 'Unexpected climate schema version');
assert.strictEqual(climate.country, 'TR', 'Climate country must be TR');
assert.strictEqual(climate.cities.length, 81, 'Climate JSON must contain 81 provinces');
assert.strictEqual(Object.keys(cityProfiles).length, 81, 'UI city profiles must contain 81 provinces');
const cityMap = new Map(climate.cities.map(c => [c.city, c]));
for (const [city, values] of Object.entries(cityProfiles)) {
  const record = cityMap.get(city);
  assert.ok(record, `City missing from JSON: ${city}`);
  assert.strictEqual(JSON.stringify(values), JSON.stringify([record.legacy_summer_start_value_c, record.elevation_m, record.legacy_outdoor_rh_start_value_pct]), `City profile mismatch: ${city}`);
  assert.strictEqual(record.design_weather_status, 'not_verified', `Unverified climate status changed: ${city}`);
  assert.strictEqual(record.summer_design_db_c, null, `Unverified summer DB must remain null: ${city}`);
  assert.strictEqual(record.summer_design_wb_c, null, `Unverified summer WB must remain null: ${city}`);
  assert.strictEqual(record.winter_design_db_c, null, `Unverified winter DB must remain null: ${city}`);
}
const csvRows = csv.trim().split(/\r?\n/);
assert.strictEqual(csvRows.length, 82, 'Climate CSV must contain header + 81 provinces');
pass('81-city JSON, CSV and offline UI profiles are consistent; unverified design values remain null');

// Extract the exact pure calculation functions used by the app and run reference vectors.
const functionNames = ['satPressure', 'moist', 'dewPoint', 'wetBulb', 'calculateOutdoorAirLoad', 'pressureFromAltitude', 'psychroSolveTemperature', 'psychroStateFromTW'];
const lines = allScript.split(/\r?\n/);
const functionLines = [];
for (const name of functionNames) {
  const line = lines.find(l => l.startsWith(`function ${name}(`));
  assert.ok(line, `Calculation function missing: ${name}`);
  functionLines.push(line);
}
const sandbox = {};
vm.runInNewContext(`${functionLines.join('\n')}\nglobalThis.api={satPressure,moist,dewPoint,wetBulb,calculateOutdoorAirLoad,pressureFromAltitude,psychroSolveTemperature,psychroStateFromTW};`, sandbox);
const api = sandbox.api;
const state = api.moist(25, 50, 101325);
near(state.w, 0.0098579061, 1e-8, 'Humidity ratio at 25°C / 50% RH');
near(state.h, 50.2630159, 1e-5, 'Enthalpy at 25°C / 50% RH');
near(state.rhoDry, 1.1654536, 1e-5, 'Dry-air density at 25°C / 50% RH');
near(api.wetBulb(25, state.w, 101325), 17.82206, 0.02, 'Wet-bulb temperature');
near(api.pressureFromAltitude(0), 101325, 0.1, 'Standard pressure at sea level');
near(api.pressureFromAltitude(950), 90420.98, 0.1, 'Standard pressure at 950 m');
const air = api.calculateOutdoorAirLoad(120, 35, 24, 40, 50, 90500);
near(air.total, 838.6374, 0.02, 'Outdoor-air total enthalpy load');
near(air.sensible + air.latent, air.total, 1e-8, 'Outdoor-air sensible + latent energy balance');
const zeroFlow = api.calculateOutdoorAirLoad(0, 35, 24, 40, 50, 90500);
near(zeroFlow.total, 0, 1e-12, 'Zero-flow air load');
const freeCooling = api.calculateOutdoorAirLoad(120, 20, 24, 40, 50, 101325);
assert.ok(freeCooling.total < 0, 'Cooler outdoor air should retain signed free-cooling contribution');
const wMix=(stateA,stateB,frac)=>((1-frac)*stateA.rhoDry*stateA.w+frac*stateB.rhoDry*stateB.w)/((1-frac)*stateA.rhoDry+frac*stateB.rhoDry);
const hMix=(stateA,stateB,frac)=>((1-frac)*stateA.rhoDry*stateA.h+frac*stateB.rhoDry*stateB.h)/((1-frac)*stateA.rhoDry+frac*stateB.rhoDry);
const hot=api.moist(30,50,101325), cool=api.moist(20,50,101325), wm=wMix(hot,cool,0.3), hm=hMix(hot,cool,0.3), tm=api.psychroSolveTemperature(hm,wm);
near(api.psychroStateFromTW(tm,wm,101325).h,hm,1e-8,'Psychrometric mixed-air enthalpy balance');
const mixedState=api.psychroStateFromTW(tm,wm,101325);
assert.ok(Number.isFinite(mixedState.rhoDry)&&mixedState.rhoDry>0,'Mixed-air dry-air density must be calculated and positive');
const mixedMass=(1000/3600*hot.rhoDry)+(300/3600*cool.rhoDry);
const mixedFlow=mixedMass/mixedState.rhoDry*3600;
assert.ok(Number.isFinite(mixedFlow)&&mixedFlow>0,'Mixed-state equivalent volume flow must be finite');
near(mixedFlow,1300,10.0,'Mixed-state equivalent volume flow should be approximately conserved');
const heated=api.psychroStateFromTW(40,hot.w,101325);
near(heated.w,hot.w,1e-12,'Constant-humidity-ratio heating');
assert.ok(heated.h>hot.h,'Heating must increase moist-air enthalpy');
pass('Psychrometric, pressure-altitude, outdoor-air and new process reference vectors pass');

assert.ok(html.includes('id="psychroMixFlow"'), 'Separate second-air volumetric flow input must exist');
assert.ok(!html.includes('psychroMixFraction'), 'Legacy airflow percentage input must be removed');
assert.ok(allScript.includes("m1=flow/3600*a.rhoDry,m2=flow2/3600*c.rhoDry"), 'Mixing must use each inlet volumetric flow and its own dry-air density');
assert.ok(allScript.includes('const mixedVolume=mdot/b.rhoDry*3600'), 'Mixed-state equivalent volume flow must be reported');
const flow1=1000,flow2=300;
const m1=flow1/3600*hot.rhoDry,m2=flow2/3600*cool.rhoDry,mt=m1+m2;
const wActual=(m1*hot.w+m2*cool.w)/mt,hActual=(m1*hot.h+m2*cool.h)/mt;
const tActual=api.psychroSolveTemperature(hActual,wActual);
const mixedActual=api.psychroStateFromTW(tActual,wActual,101325);
near(mixedActual.h,hActual,1e-8,'Independent-volume-flow mixing enthalpy balance');
near(mixedActual.w,(m1*hot.w+m2*cool.w)/mt,1e-12,'Independent-volume-flow mixing humidity balance');
assert.ok(Math.abs((m1/mt)-0.7)>0.001, 'Different inlet densities must alter dry-air mass split from simple 70/30 volume split');
pass('Separate inlet volume-flow inputs, mixed-state dry-air density and mass/enthalpy balances are present');

// Critical guardrails must remain present in the app source.
for (const token of ['function validateCoolingInputs()', 'function readStrictNumber(id)', 'winterT< -60||winterT>25', "['official','measured'].includes(source)", "const meta=[['stationName'", 'shgc:{min:0,max:1', 'shade:{min:0,max:1', 'if(!validateCoolingInputs())return;', 'Correct invalid inputs before creating the report.']) {
  assert.ok(allScript.includes(token), `Missing input/report safety guard: ${token}`);
}
assert.ok(html.includes('Bilgi amaçlıdır; mevcut soğutma yükü modelinde kullanılmaz.'), 'Ceiling-height limitation must be visible');
for (const id of ['stationName','stationPeriod','stationSource','stationLat','stationLon']) assert.ok(ids.includes(id), `Missing weather provenance field: ${id}`);
pass('Input validation and stale-report prevention guards are present');

// Execute the real shared input validator against a minimal DOM test double.
const validationStart = allScript.indexOf('const $=id=>document.getElementById(id)');
const validationEnd = allScript.indexOf('function syncUPreset', validationStart);
assert.ok(validationStart >= 0 && validationEnd > validationStart, 'Could not isolate shared input validator');
const validationSource = allScript.slice(validationStart, validationEnd);
const elementMap = new Map();
for (const match of html.matchAll(/<input\b([^>]*)>/g)) {
  const attrs = Object.fromEntries([...match[1].matchAll(/([\w-]+)=["']([^"']*)["']/g)].map(m => [m[1], m[2]]));
  if (attrs.id) elementMap.set(attrs.id, { value: attrs.value || '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
for (const id of ['weatherSource','glassOrientation','totalKW','totalBTU','sensible','latent','breakdown','heatingBreakdown','heatingKW']) {
  if (!elementMap.has(id)) elementMap.set(id, { value: id === 'weatherSource' ? 'preliminary' : (id === 'glassOrientation' ? '1' : ''), textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
elementMap.get('weatherSource').value = 'preliminary';
elementMap.get('glassOrientation').value = '1';
const testWindow = { __hvacLang: 'tr', lastCalc: { total: 123 }, lastHeating: { total: 456 } };
const validationContext = {
  document: { getElementById: id => elementMap.get(id) || { value: '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } }, querySelector: () => ({ style: {} }) },
  window: testWindow,
  updateLoadComparison() {}
};
vm.runInNewContext(`${validationSource}\nglobalThis.validationApi={validateCoolingInputs,readStrictNumber};`, validationContext);
const validator = validationContext.validationApi;
assert.strictEqual(validator.validateCoolingInputs(), true, 'Default cooling inputs should validate');
elementMap.get('shgc').value = '1.2';
assert.strictEqual(validator.validateCoolingInputs(), false, 'SHGC above 1 must be rejected');
assert.ok(elementMap.get('shgc').validationMessage, 'SHGC validation message should be set');
elementMap.get('shgc').value = '0.7';
elementMap.get('freshAir').value = '-10';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Negative fresh-air flow must be rejected');
elementMap.get('freshAir').value = '120';
elementMap.get('weatherSource').value = 'official';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Official source without provenance must be rejected');
elementMap.get('stationName').value = 'Test Station 123';
elementMap.get('stationPeriod').value = '1991-2020';
elementMap.get('stationSource').value = 'Official climate record';
elementMap.get('stationLat').value = '39.9';
elementMap.get('stationLon').value = '32.8';
assert.strictEqual(validator.validateCoolingInputs(), true, 'Complete official source metadata should validate');
elementMap.get('stationLon').value = '181';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Longitude outside valid range must be rejected');
pass('Live input-validator tests pass: defaults, SHGC, negative airflow and official weather provenance');

const hydronicHtml = fs.readFileSync(path.join(root, "app/src/main/assets/index.html"), "utf8");
assert.ok(hydronicHtml.includes('id="hydronic"') && hydronicHtml.includes('data-tab="hydronic"'));
pass("Project-based hydronic navigation and panel are present");
assert.ok(hydronicHtml.includes("64/Re") && hydronicHtml.includes("5.74/Math.pow(Re,0.9)") && hydronicHtml.includes("K*dyn"));
pass("Hydronic Darcy-Weisbach, Swamee-Jain and local-loss calculations are present");
assert.ok(hydronicHtml.includes("Kritik devre basınç kaybı") && hydronicHtml.includes("Kapalı devrelerde statik bina yüksekliği"));
pass("Hydronic critical-path report and closed-loop static-head caution are present");

// V13.6.39 HVAC discipline navigation and bilingual coverage checks.
const disciplineChecks = [
  ['discipline hub exists', html.includes('id="disciplineHub"')],
  ['six HVAC discipline entry points exist', ['cooling','heating','ventilation','hydronic','psychrometrics','equipment'].every(x=>html.includes('data-hvac-jump="'+x+'"'))],
  ['discipline navigation handler exists', html.includes('function hvacOpenDiscipline(target)')],
  ['discipline English labels exist', ['hubCooling','hubHeating','hubVentilation','hubHydronic','hubPsychro','hubEquipment'].every(x=>html.includes('data-i18n="'+x+'"'))],
  ['English dictionary contains discipline names', ['Cooling','Heating','Ventilation','Hydronics','Psychrometrics','Equipment & Systems'].every(x=>html.includes(x))],
  ['touch duct editor supports drawing, terminals, undo and clear', html.includes('pointerdown') && html.includes('pointerup') && html.includes('airUndo') && html.includes('airClear') && html.includes('data-air-tool="supply"') && html.includes('data-air-tool="return"')],
  ['ventilation opens dedicated panel', html.includes('data-hvac-jump="ventilation"') && html.includes("target==='ventilation'") && html.includes('id="airDesign"') && html.includes('id="airRouteCanvas"') && html.includes('data-air-tool="duct"')]
];
for (const [name, ok] of disciplineChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) process.exitCode=1; }

// V13.6.46 duct lengths, responsive room cards and straight-duct friction checks
assert.ok(html.includes('data-key=\"sm\"') && html.includes('data-key=\"sb\"') && html.includes('data-key=\"rm\"') && html.includes('data-key=\"rb\"'), 'Each terminal must accept separate supply/return main and branch lengths');
assert.ok(html.includes('function friction(q,sz,L)') && html.includes('function makeRowsTable(rows,kind)'), 'Segment schedule calculates straight duct friction loss from entered lengths');
assert.ok(html.includes('className=\'da-room-card\'') && html.includes('grid-template-columns:1fr'), 'Automatic terminal inputs use responsive cards on narrow screens');

// V13.6.45 2D duct design studio checks
const ductStudioChecks = [
 ['dedicated full-screen 2D duct studio exists', html.includes('id="ductStudio"') && html.includes('id="dsCanvas"')],
 ['manual tools include duct, AHU, terminal and fittings', ['duct','ahu','terminal','elbow','tee','reducer','damper','delete'].every(x=>html.includes('data-ds-tool="'+x+'"'))],
 ['manual element properties and local save exist', ['dsName','dsFlow','dsWidth','dsHeight','dsLength','dsK','dsSave','hvacpro_duct_studio_v1'].every(x=>html.includes(x))],
 ['automatic design accepts AHU and terminal flow criteria', ['daFlow','daCount','daMainV','daBranchV','daShape','daRows','daGenerate'].every(x=>html.includes('id="'+x+'"'))],
 ['automatic duct sizing calculates supply and return segment dimensions', html.includes('function sizeFor(q,v,shape,ratio)') && html.includes('Üfleme terminal debileri toplamı') && html.includes('Dönüş/ emiş') && html.includes('daZoomIn') && html.includes('daCanvasWrap')],
 ['English translations include duct design workspace', html.includes("'Kanal Tasarım Stüdyosu':'Duct Design Studio'")],
 ['app version is 13.6.49 / versionCode 79', fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8').includes('versionCode = 79') && fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8').includes('versionName = "13.6.49"')]
];
ductStudioChecks.push(['automatic ducts include editable local-loss coefficients and critical-path aggregation', ['data-key=\"skm\"','data-key=\"skb\"','data-key=\"rkm\"','data-key=\"rkb\"','function makeRowsTable(rows,kind)','const local=(sz,K)=>','sRows.critical.dp','rRows.critical.dp'].every(x=>html.includes(x))]);
const localLoss = 2.0 * 1.2 * 4.0 * 4.0 / 2;
near(localLoss, 19.2, 1e-9, 'duct fitting local-loss reference (K=2, rho=1.2, v=4 m/s)');

ductStudioChecks.push(['equipment pressure-drop inputs and separate supply/return fan ESP are implemented',
 ['daSFilter','daRFilter','daSCoil','daRCoil','daSHru','daRHru','daSSilencer','daRSilencer','daSOther','daROther','daSSafety','daRSafety'].every(id=>html.includes('id="'+id+'"')) &&
 html.includes('sFanBase=sRows.critical.dp+sEq') && html.includes('rFanBase=rRows.critical.dp+rEq')]);
ductStudioChecks.push(['duct model explicitly discloses topology and fresh-air/exhaust limitations',
 html.includes('Taze hava/egzoz ayrı ağ olarak henüz modellenmez') && html.includes('keyfî çok düğümlü ağ çözümü değildir')]);

for (const [name, ok] of ductStudioChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) process.exitCode=1; }

// V13.6.40 air distribution design module checks
assert(html.includes('id=\"airDistributionTool\"'), 'air distribution terminal tool exists');
assert(html.includes("target==='ventilation'") && html.includes('id="airDesign"') && html.includes('id="airRouteCanvas"') && html.includes('data-air-tool="duct"'), 'ventilation tile opens the dedicated air design panel');
assert(html.includes('id=\"ductPathTool\"'), 'duct critical-path tool exists');
