# HVAC PRO 13.6.43

## 2D air-duct drawing editor (first interactive prototype)
- Added a dedicated touch-friendly canvas to Air Distribution Design.
- Users can draw duct segments by dragging on the canvas.
- Users can place supply and return terminals.
- Each duct segment stores its drawn length, entered airflow, nominal size and target velocity.
- Added undo and clear controls plus a live schematic summary.
- Added explicit preliminary-design limitations: no calibrated floor-plan scale, automatic branch flow balancing, fitting library or manufacturer terminal selection yet.
- Existing sizing and pressure-loss calculators are retained.

## QA
- Pending full Android Gradle build and physical-device validation.
