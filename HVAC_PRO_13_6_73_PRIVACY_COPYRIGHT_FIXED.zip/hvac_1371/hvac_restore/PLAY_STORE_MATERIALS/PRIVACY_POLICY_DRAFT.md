# HVAC PRO – Gizlilik Politikası

**Son güncelleme:** 2 Kasım 2026  
**Uygulama/yayıncı görünen adı:** HVAC PRO  
**İletişim:** support.hvacpro@gmail.com

## 1. Kapsam
Bu politika, HVAC PRO Android uygulamasının mevcut kaynak sürümünde kişisel verilerin nasıl işlendiğini açıklar. Uygulamanın sonraki sürümlerine reklam, analiz, hata raporlama veya ödeme SDK'ları eklenirse politika ve Google Play Veri Güvenliği beyanı gerçek veri akışına göre güncellenecektir.

## 2. Uygulama içinde girilen bilgiler
Kullanıcı tarafından girilen HVAC proje, mahal, cihaz ve hesaplama bilgileri uygulamanın işlevlerini sağlamak amacıyla cihaz üzerinde işlenebilir. Proje kayıtları cihazdaki uygulama/WebView yerel depolamasında tutulabilir. Uygulama verilerinin veya uygulamanın silinmesi bu yerel kayıtların kaybolmasına neden olabilir.

## 3. Veri aktarımı ve üçüncü taraf hizmetler
Bu kaynak kod paketinde geliştiriciye ait bir sunucuya proje verisi gönderen API tanımlanmamıştır. Yayımlanacak nihai derlemedeki Android izinleri, kütüphaneler ve üçüncü taraf SDK'lar ayrıca incelenmelidir. Bu metin, henüz eklenmemiş reklam, analiz, hata raporlama veya ödeme hizmetleri için veri toplama/aktarımı olmadığı yönünde taahhüt oluşturmaz.

## 4. Satın almalar
Bu kaynak sürümünde Google Play Billing entegrasyonu etkin değildir. Uygulama içi satın alma etkinleştirildiğinde ödeme Google Play tarafından yürütülecek; satın alma ve lisans durumu bilgileri Professional erişimini yönetmek için işlenecektir. Entegrasyon tamamlandığında bu bölüm gerçek uygulama davranışına göre güncellenecektir.

## 5. Veri güvenliği ve saklama
Bu sürümde proje bilgileri yerel cihaz depolamasında tutulabilir. Bu kaynak sürümünde proje verileri için bulut hesabı veya senkronizasyon hizmeti sunulmamaktadır.

## 6. Verilerin silinmesi
Yerel proje kayıtları, Android ayarlarından HVAC PRO uygulamasının verileri temizlenerek veya uygulama kaldırılarak silinebilir.

## 7. Çocukların gizliliği
HVAC PRO çocuklara yönelik tasarlanmamıştır ve çocukları hedefleyen bir uygulama değildir.

## 8. Politika değişiklikleri
Uygulamanın özellikleri veya kullandığı hizmetler değiştiğinde bu politika güncellenebilir.

## 9. İletişim
Gizlilik, veri talepleri ve teknik destek: **support.hvacpro@gmail.com**

**Not:** HVAC PRO, uygulama ve yayıncı görünen adıdır; tek başına bir şirket veya tüzel kişi unvanı beyanı değildir.
