# HVAC PRO Professional — Billing Preparation

## Current state (13.6.29)
- Debug APKs temporarily unlock every Professional feature already implemented so the user can test the full current feature set before launch. This entitlement is derived only from the native `BuildConfig.DEBUG` bridge. Release APK/AAB builds remain locked until verified Google Play Billing entitlement is implemented.
- Google Play Billing is not integrated. No payment is collected and no local preference/flag unlocks paid features in release builds.
- Professional price target: one-time purchase, 349 TL (localized Play prices must be configured in Play Console).
- PDF printing is gated as a Professional feature in release builds. Debug-only PDF testing uses the native Android print bridge. Report title and provenance metadata follow the selected Turkish/English language.

## Required before enabling purchases
1. Complete Google Play developer identity verification.
2. Create the one-time in-app product in Play Console (suggested product ID: `hvac_pro_professional_lifetime`; confirm ID before implementation).
3. Add Google Play Billing Library using a current supported version and implement purchase, pending, acknowledged, cancelled, refunded/revoked, and restore flows.
4. Verify purchase tokens with a trusted backend / Google Play Developer API; never unlock based only on a client-side boolean or a local preference.
5. Test with Play license testers and an internal testing track, including reinstall and restore on another device.
6. Enable entitlement only after verified active purchase; keep all paid actions behind the same entitlement check.

## PDF language verification
- Select English, create/print report: title and metadata should be English.
- Select Turkish, create/print report: title and metadata should be Turkish.
- Check date locale, city/district, design temperatures, RH, data source, and pressure.
- PDF creation can be exercised in the debug APK through the native Android print bridge. Release builds remain purchase-gated.

## Safety
Keep the QA bypass tied exclusively to `BuildConfig.DEBUG`; never replace it with a hard-coded `true` value or enable it in release builds. Billing integration and Play Console product configuration are still pending.


## QA feature additions in 13.6.29
- Advanced psychrometric process calculator is available in Debug QA builds: mixing, sensible heating, cooling/dehumidification, humidification and dehumidification.
- Release Professional entitlement remains purchase-gated; Billing is not integrated.
