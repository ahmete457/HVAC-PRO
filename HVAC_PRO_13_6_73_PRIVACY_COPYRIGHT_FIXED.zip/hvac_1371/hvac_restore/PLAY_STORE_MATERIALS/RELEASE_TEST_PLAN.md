# HVAC PRO V13.6.50 – yayın test planı

## Fonksiyonel testler
- [ ] Şehir seçimi dış hava ve rakım varsayımlarını güncelliyor.
- [ ] Negatif/virgüllü kış sıcaklığı doğru okunuyor.
- [ ] Soğutma girdilerinde boş/negatif/geçersiz değer engelleniyor.
- [ ] SHGC ve gölgeleme katsayısı 0–1 dışında reddediliyor.
- [ ] Resmî veri/saha ölçümünde istasyon, dönem, kaynak ve koordinat bilgileri zorunlu; PDF/proje kaydına ekleniyor.
- [ ] Şehir seçimi JSON kaynaklı 81 il profilini çevrimdışı yükleyebiliyor.
- [ ] RH 0–100%, basınç sınırları doğrulanıyor.
- [ ] Psikrometrik hava karışımı kuru hava kütle dengesiyle doğrulanıyor.
- [ ] Sabit nem oranlı ısıtma prosesinde nem oranı korunuyor ve entalpi artıyor.
- [ ] Soğutma/nem alma çıkış koşulları proses yönü ve doygunluk açısından doğrulanıyor.
- [ ] Nemlendirme/nem alma su transferi kg/h olarak kontrol ediliyor.
- [ ] Yeni psikrometri aracı Türkçe ve İngilizce arayüzlerde kontrol ediliyor.
- [ ] Kanal kesiti dairesel/dikdörtgen örneklerle karşılaştırılıyor.
- [ ] Basınç kaybı laminer, geçiş ve türbülans rejimlerinde test ediliyor.
- [ ] Cihaz kapasitesi üretici katalog koşullarıyla doğrulanıyor.
- [ ] Çoklu mahal 1, 3 ve 30 mahalle test ediliyor.
- [ ] PDF A4, sayfa taşması ve Türkçe karakter kontrolü gerçek Android cihazda yapılıyor.
- [ ] Geçersiz girişten sonra eski soğutma/ısıtma sonucu veya eski PDF raporu kullanılamıyor.
- [ ] GitHub Actions kaynak QA, Gradle build ve Android lint adımları başarılı.
- [ ] Release APK/AAB imza doğrulaması başarılı; artifact adı `HVAC-PRO-v13.6.50-packages`.
- [ ] Proje kaydı uygulama yeniden başlatılınca korunuyor.
- [ ] Billing satın alma, pending, iptal, restore ve refund senaryoları test ediliyor.

## Bağımsız örnekler
1. 1200 m³/h ve 5 m/s için A=Q/v=0.06667 m²; dairesel teorik çap yaklaşık 291 mm.
2. Darcy-Weisbach: Δp=f(L/D)(ρv²/2)+ΣK(ρv²/2).
3. Isıtma iletim, dış hava, infiltrasyon, taze hava, HRV ve zemin varsayımları ayrı raporlanmalı.

## Yayın kapıları
- [ ] Play Console kimlik doğrulaması tamam.
- [ ] hvac_pro_professional_lifetime ürünü tanımlandı.
- [ ] Billing ve güvenli satın alma doğrulaması tamam.
- [ ] Upload keystore güvenli oluşturuldu, repoya eklenmedi.
- [ ] İmzalı AAB internal/closed test'e yüklendi.
- [ ] Store listing, içerik derecelendirmesi, target API ve Data safety tamam.

## V13.6.50 — tam proje çalışma alanı regresyonu
- [ ] Proje kaydı; hesaplama, taze hava, hidronik, kanal tasarımı ve cihaz girdilerini saklar.
- [ ] Proje açma; eski V1 yedek/proje kayıtlarıyla geriye dönük uyumludur.
- [ ] Hidronik segment sayısı ve her segmentin alanları doğru geri yüklenir.
- [ ] Otomatik kanal tasarımındaki mahal/terminal satırları doğru geri yüklenir.
- [ ] Manuel 2D kanal çizimi proje değiştirildiğinde doğru geri yüklenir.
- [ ] Isıtma hesabı yapılmışsa proje açıldığında ısıtma hesabı yeniden çalıştırılır.
