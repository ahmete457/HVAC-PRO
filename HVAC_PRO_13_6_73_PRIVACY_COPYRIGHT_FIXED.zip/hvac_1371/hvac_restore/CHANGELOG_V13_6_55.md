# HVAC PRO V13.6.55 — City-only location lookup foundation

## Implemented
- International place lookup now accepts only Photon/OpenStreetMap features explicitly classified as `city`.
- Town, village, hamlet, suburb and generic locality results are excluded.
- Added native Android SQLite cache (`hvacpro_geo.db`) for searched cities, storing country code, city name, region, coordinates, source and update timestamp.
- Added a narrow JavaScript bridge for city-cache search and writes.
- Search uses saved SQLite city results first and falls back to the live lookup when online; saved results can be searched offline after the first successful lookup.
- Selected international city stores latitude/longitude and source metadata in the project WebView state.
- Bumped app version to 13.6.55 / versionCode 85.

## Important scope note
This is the offline cache foundation, not yet a complete preloaded worldwide city gazetteer and not a climate database. A city appears in offline search after it has been successfully looked up online on that device. No design temperatures, humidity, weather-station observations or EPW/ERA5 values are fabricated or inferred from the city lookup.

## Data attribution
Live location lookup: Photon geocoder / OpenStreetMap contributors. The app displays attribution in the location panel. Cached entries retain their source label.
