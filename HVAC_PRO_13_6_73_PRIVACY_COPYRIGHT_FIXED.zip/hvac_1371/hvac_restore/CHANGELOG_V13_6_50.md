# HVAC PRO 13.6.50 — Tam mühendislik çalışma alanı proje kaydı

## Proje çalışma alanı
- Proje kaydı artık ana soğutma/ısıtma tasarım girdilerinin yanında uygulamadaki kimlikli form alanlarını da saklar.
- Hidronik devre segmentleri, otomatik kanal tasarımındaki mahal/terminal girdileri ve cihaz üzerindeki manuel 2D kanal çizimi proje kaydına eklenir.
- Proje açıldığında kayıtlı form alanları ve dinamik segment/terminal satırları geri yüklenir.
- Daha önce ısıtma hesabı çalıştırılmış projeler açıldığında ısıtma hesabı yeniden hesaplanır.
- Eski proje kayıtları için geriye dönük uyumluluk korunur; `workspace` alanı bulunmayan kayıtlar eski yöntemle açılır.

## Sürüm ve paketleme
- Android versionName: 13.6.50
- Android versionCode: 80
- GitHub Actions artifact adı: `HVAC-PRO-v13.6.50-packages`

## Doğrulama sınırı
- Kaynak JavaScript/hesap QA ve tarayıcı etkileşim testleri çalıştırılmalıdır.
- Bu çalışma ortamında Android SDK/Gradle bulunmadığından yeni APK derlemesi ve gerçek Android cihaz testi yapılmış sayılmaz.
