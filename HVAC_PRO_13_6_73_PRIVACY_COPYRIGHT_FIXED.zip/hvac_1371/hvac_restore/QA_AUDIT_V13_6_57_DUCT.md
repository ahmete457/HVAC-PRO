# HVAC PRO 13.6.57 — Kanal modülü QA özeti

## Değişiklik
- Otomatik kanal tasarımındaki sabit 30 mahal sınırı kaldırıldı.
- Mahal ekle, son mahali sil ve mahal kartından tekil silme kontrolleri eklendi.
- Her mahal için üfleme/dönüş debisi, ana kanal/branşman uzunluğu ve ayrı yerel kayıp katsayıları düzenlenebilir.
- Proje geri yükleme sırasında mahal sayısı artık 30 ile sınırlandırılmıyor.
- Uygulama sürümü 13.6.57, versionCode 86.

## Kontroller
- `node scripts/qa_validate.js`: PASS
- `python scripts/qa_validate_project.py`: PASS
- HTML içindeki JavaScript sözdizimi, benzersiz DOM ID'leri ve mühendislik referans kontrolleri QA betiklerinde doğrulandı.
- Android XML ve proje yapısı kontrolleri başarılı.

## Henüz yapılmayan
- Bu ortamda Gradle wrapper bulunmadığından APK derlemesi yapılmadı.
- Fiziksel Android cihaz üzerinde dokunmatik kullanım testi yapılmadı.

## Mühendislik sınırı
Otomatik şema seri ana kanal + yan branşman topolojisi için ön tasarımdır; genel amaçlı çok düğümlü ağ çözücüsü değildir. ΣK değerleri kullanıcı tarafından girilir. Nihai kanal ve fan seçimi, gerçek fitting/terminal/cihaz üretici verileri ve geçerli tasarım standartlarıyla doğrulanmalıdır.
