# HVAC PRO 13.6.52 — QA / kapsam notu

## Geliştirmeler
- Lisanslı gateway üzerinden küresel geocoding ve koordinata göre 1991–2020 ERA5 günlük iklim arşivi bağlantısı; gateway URL henüz yapılandırılmadı.
- Kaynak, dönem ve koordinat proje alanlarına kaydedilir.
- Günlük maksimum sıcaklık P99 / günlük minimum sıcaklık P01 yalnızca ön tasarım taramasıdır; ASHRAE saatlik tasarım koşulu değildir.
- Soğutma ve ısıtma hesapları bağımsız test edilebilir saf fonksiyonlara ayrıldı.
- Tavan yüksekliği artık hacim ve ACH bilgisini üretir; temel ısı yükü denklemine yanlış bir katsayıyla eklenmez.
- SHGC/gölgeleme 0–1, sıcaklık ve negatif debi doğrulaması önceki sürümdeki gibi korunmuştur; tavan yüksekliği 1.5–20 m aralığına alındı.
- PDF/proje kaydı V13.6.51'de eklenen çalışma alanı ve çok disiplinli rapor altyapısını korur.
- GitHub Actions otomatik QA + Android debug APK/lint + imza varsa release APK/AAB akışını sürdürür.

## Küresel veri yaklaşımı
- Uygulama tarafındaki küresel arama/iklim adaptörü hazırdır ancak `HVAC_PRO_CLIMATE_API_BASE` varsayılan olarak boştur; lisanslı gateway kurulana kadar arama butonu devre dışıdır.
- Open-Meteo ücretsiz API uç noktaları uygulamada çağrılmaz; ücretsiz plan ticari olmayan kullanım içindir. Tarihsel/iklim verileri için ticari Professional veya üzeri plan gerekir.
- ASHRAE 2025: 12.424 istasyon; yazılım geliştirici lisansı olmadan tasarım verisi gömülmedi.
- Open-Meteo ERA5: 1991–2020 günlük arşiv; P99 daily Tmax / P01 daily Tmin / median daily mean RH; site pressure is estimated from returned elevation using standard-atmosphere pressure. Model verisi; tasarım standardı yerine geçmez.
- TMYx / WMO kaynakları politika belgesinde listelendi; TMYx dosyalarının ve WMO istasyon verilerinin doğrudan içeri alınması sonraki veri lisansı/format entegrasyonudur.

## Otomatik QA sonuçları
- JavaScript kaynak / hesap testleri: 30 PASS, 0 FAIL.
- Android proje yapısal testleri: 67 PASS, 0 FAIL.
- HTML içi JavaScript sözdizimi, yinelenen ID ve DOM referans kontrolleri geçti.
- Soğutma tam yükü, ısıtma iletim/ventilasyon yükü, ısı geri kazanımı, SHGC, giriş aralıkları ve küresel iklim veri şeması kontrolleri geçti.
- PDF/proje saklama ve GitHub Actions yapılandırması yapısal olarak doğrulandı.

## QA sınırı
- Statik QA ve sayısal referans vektörleri çalıştırıldı; saha ölçümü, üretici eğrisi veya standart uygunluk sertifikası değildir.
- Bu çalışma ortamında Android SDK/Gradle/ADB bulunmadığı için yeni APK burada derlenemez veya gerçek telefonda test edilemez. GitHub Actions build çıktısı cihazda denenmelidir.
- Küresel iklim modülü lisanslı HVAC PRO gateway URL yapılandırılana kadar devre dışıdır. Gateway internet gerektirir; çevrimdışı durumda Türkiye 81 il başlangıç profilleri kullanılabilir.
- Open-Meteo ticari API kullanım koşulları ve attribution yayından önce kontrol edilmelidir.
