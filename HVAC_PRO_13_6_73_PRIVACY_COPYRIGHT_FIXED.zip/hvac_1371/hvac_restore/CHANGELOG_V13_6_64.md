# HVAC PRO 13.6.64

- 81 il merkezi iklim profilleri 13.6.51 sürümündeki `climate-data-tr.json` dosyasından geri alındı.
- Çevrimdışı çalışan `climate-data-tr.js` üretildi ve web/Android WebView varlıklarına eklendi.
- İl seçimi rakım, yaklaşık yaz kuru termometre başlangıcı ve yaklaşık dış bağıl nemi otomatik doldurur.
- Atmosfer basıncı rakımdan standart atmosfer bağıntısıyla hesaplanır.
- Kış başlangıç değeri doğrulanmış tasarım verisi değil, rakıma dayalı yaklaşık ön kabuldür.
- Yaz/kış tasarım DB/WB değerleri doğrulanmış olmadığı için null kalır.
- Sürüm: 13.6.64 / versionCode 91.
