# HVAC PRO 13.6.62

- Removed the legacy secondary drag-to-draw duct canvas from the duct calculation page.
- Removed the redundant “Open 2D Duct Design Studio” button; entering the duct discipline opens the dedicated 2D studio directly.
- Guarded duct-only project actions so they cannot appear outside the duct panel.
- Removed generic-looking default outdoor temperature, outdoor RH, elevation and pressure values that were being reused for every selected province.
- Changing province clears site-specific climate inputs so values from one city are not carried into another.
- Added an explicit notice: verified MGM climate values for all 81 provinces are not yet bundled; users must enter verified project values. No invented city data is supplied.
- Synchronized web and Android WebView HTML assets.
- Android versionName 13.6.62 / versionCode 91.
