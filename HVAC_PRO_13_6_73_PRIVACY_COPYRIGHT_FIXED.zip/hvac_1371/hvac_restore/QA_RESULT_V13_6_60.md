# QA sonucu — HVAC PRO 13.6.60

## Bu değişiklik setinde başarılı kontroller
- Türkiye il kataloğu: 81 kayıt ve 81 benzersiz il adı.
- İlçe alanı görünür arayüzden kaldırıldı; yalnızca il merkezi seçimi var.
- Yabancı ülke/şehir arama kodu ve Photon çağrısı kaldırıldı.
- MGM resmî il istatistikleri kaynağına bağlantı mevcut.
- MGM aylık istatistiklerinin HVAC tasarım günü verisi olmadığı kullanıcıya açıklanıyor.
- Web ve Android WebView HTML varlıkları birebir eşitlendi.
- Inline JavaScript parse kontrolü ve mevcut ısıtma/soğutma/psikrometri/basınç referans vektörleri QA scriptinde geçti.
- Android XML yapısal kontrolleri geçti.

## Mevcut QA paketinde kalan başarısız kontroller
Aşağıdaki başarısızlıklar bu konum kapsamı değişikliğinden bağımsız, mevcut kaynak paketindeki eski/uyumsuz QA kontrolleridir:
- `qa_validate_project.py`: AHU kapasite ön seçim yardımcısı için beklenen `ahuSizeCheck` / `data-key="cool"` arayüzü bulunamadı.
- `qa_validate.js`: tek 2D kanal çizim alanı / eski editör kaldırma beklentileri, dinamik zon ekle-sil kontrolleri ve AHU kapasite asistanı kontrolleri başarısız.

Bu nedenle tüm proje QA'sı temiz değil; bu ZIP için “tam testten geçti” denemez.

## Derleme durumu
Bu çalışma ortamında Gradle komutu ve Gradle Wrapper bulunmadığından Android APK/AAB derlemesi yapılmadı. Android cihaz kurulumu ve gerçek cihaz testi yapılmadı.

## MGM veri kapsamı
Bu sürümde MGM'nin 81 il aylık tabloları uygulamaya veri dosyası olarak henüz gömülmedi. Sadece resmî MGM kaynağına yönlendirme ve veri doğruluğu uyarısı eklendi. Bağıl nem / rakım / tasarım sıcaklığı alanları için doğrulanmamış değer üretilmedi.
