# HVAC PRO 13.6.73 – Professional access locks

## Professional package scope
The one-time Professional package is planned at TRY 349. The following tools are classified as Professional:
- Heating-load calculation
- All independent PDF reports and project/report exports
- Advanced psychrometric properties and psychrometric process calculations
- Duct sizing, pressure-loss analysis, terminal sizing, critical-path analysis and 2D duct studio
- Fan and pump power calculations, pump operating-point analysis and hydronic design
- AHU capacity/airflow checks and equipment/system tools
- VRF piping/refrigerant pre-calculation
- Project save, restore and backup management

Free access remains available for the basic cooling-load workspace and the standalone fresh-air calculation workspace. The base cooling engine still uses its normal outdoor-air inputs where configured; the advanced psychrometric workspace is separately locked.

## Access enforcement
- Release builds fail closed: Professional access is unavailable unless a verified entitlement is supplied by the native Android layer in a future Billing integration.
- Debug builds expose a QA-only Professional entitlement using `BuildConfig.DEBUG`; this is not a production purchase mechanism.
- Navigation, discipline shortcuts and calculation actions for Professional tools are guarded independently.
- PDF generation and project operations remain Professional-gated.

## Important purchase limitation
Google Play Billing has **not** been integrated in this source package. The Professional screen states the intended TRY 349 one-time price and explains that purchase cannot yet be completed. No fake purchase, local unlock switch or client-side entitlement is used. Before public release, configure the Play Console one-time product and integrate purchase verification/restore in the native Android layer.

## QA
- `node scripts/qa_validate.js` – passed, including Professional access-boundary assertions.
- `python3 scripts/qa_validate_project.py` – passed.
- Android Gradle build and physical-device purchase/PDF tests were not run in this environment.
