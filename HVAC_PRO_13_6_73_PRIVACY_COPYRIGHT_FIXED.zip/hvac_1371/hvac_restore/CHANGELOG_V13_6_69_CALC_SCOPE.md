# HVAC PRO 13.6.69 — Calculation workspace separation

- Removed the combined fan/pump/hydronic calculation card from the cooling-load workspace.
- Relocated fan power, pump power, hydronic pipe pressure-loss and pump operating-point tools into the dedicated Hydronic workspace.
- Kept existing calculation element IDs and handlers intact to preserve their calculation logic.
- Synced Android WebView index.html with web/index.html.
- Version: 13.6.69 / versionCode 96.

Validation: source QA scripts, JavaScript syntax, HTML ID uniqueness, Android/web asset equality and ZIP integrity. Actual Android device navigation still requires runtime testing.
