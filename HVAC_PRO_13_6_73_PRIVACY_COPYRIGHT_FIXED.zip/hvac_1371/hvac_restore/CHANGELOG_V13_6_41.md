# HVAC PRO 13.6.41

- Fixed the Ventilation discipline tile: it now opens the Professional tools tab and scrolls directly to the Air Distribution terminal-sizing tool.
- Routed the Equipment & Systems tile to the Professional tools section.
- Kept the separate Fresh Air bottom-navigation tab unchanged.
- Bumped Android versionCode to 71 and versionName to 13.6.41.
