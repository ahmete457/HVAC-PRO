# HVAC PRO 13.6.33

- Added preliminary fan power calculator: airflow, total pressure, fan efficiency and motor efficiency; reports air power, shaft power and estimated electrical input.
- Added preliminary pump power calculator: flow, head, fluid density, pump efficiency and motor efficiency.
- Added hydronic pipe pressure-loss calculator using Darcy-Weisbach, Swamee-Jain turbulent friction estimate, laminar friction factor, and user-entered minor-loss coefficient ΣK.
- Added Turkish and English labels.
- Engineering limits are disclosed in the UI; verify pump curves, NPSH, fluid properties, fittings and system effects before final selection.

Source-level QA only; Android Gradle build and physical-device testing are still required.
