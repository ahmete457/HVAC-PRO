# HVAC PRO 13.6.28

## New engineering tools
- Restored the standalone Fresh Air navigation panel for all builds.
- Added preliminary outdoor-air flow estimation from user-entered occupancy and area rates.
- Added outdoor-air sensible/latent/total load calculation using the existing moist-air enthalpy model and user-entered psychrometric conditions.
- Added transfer of calculated outdoor-air flow into the main cooling-load inputs.
- Added a brand/model-independent VRF piping and additional refrigerant-charge estimator. Each segment requires a user-entered manufacturer coefficient (kg/m); the tool refuses to calculate charge if any segment coefficient is missing.
- Added user-entered indoor/outdoor nominal capacities and elevation-limit comparison as review prompts, not automatic compliance approval.

## Engineering limitations
- Outdoor-air rates are user assumptions, not code/standard minimums. Verify the applicable occupancy category and local requirements.
- VRF charge estimate uses M_extra = sum(L_i × K_i), where K_i must be verified from the applicable manufacturer documentation. Factory charge, pipe sizing, branch selection, equivalent lengths and all system limits remain subject to the manufacturer installation manual.
- No manufacturer/model database or hidden correction coefficients are included.
- Android Gradle build and on-device testing are still required.

## Follow-up 13.6.29
- Added advanced psychrometric process calculations; see CHANGELOG_V13_6_29.md.
