# HVAC PRO 13.6.45

- Otomatik 2D kanal çizim alanı mobil kaydırma ve yakınlaştırma kontrolleriyle genişletildi.
- Otomatik tasarımda üfleme ve dönüş/egzoz debileri ayrı girilebilir hale getirildi.
- Üfleme ve dönüş/egzoz ana hatları ayrı şematik ağlar olarak çizilir.
- Ana kanal debisi her terminal branşından sonra kalan debiye göre kademeli düşürülür; her ana hat segmenti için ölçü, hız ve yaklaşık çizim uzunluğu gösterilir.
- Her terminal branşmanı kendi debisine göre ayrı boyutlandırılır.
- Üfleme/dönüş debi farkı denge kontrolü olarak raporlanır.
- Hesap sınırı: bu sürümde çizim yerleşiminden türetilen uzunluklar yaklaşık şematik değerlerdir; fitting, serpantin, filtre, susturucu ve terminal basınç kayıpları tam ağ çözümüne henüz bağlı değildir. Dönüş ve egzoz proje bazında ayrıca ayrıştırılmalıdır.
