# HVAC PRO V13.6.55 QA audit

- Strict city-only lookup filter added; towns, villages, hamlets, suburbs and generic locality results are excluded.
- Android SQLite cache schema stores country, city, region, coordinates, source and timestamp.
- JavaScript bridge exposes only cached-city search and city-cache insertion.
- Cached city results are available offline after a successful online lookup.
- Selected city coordinates and source are persisted in WebView local storage.
- No climate values are derived from geocoding results.
- Version: 13.6.55 / versionCode 85.

Automated script results are recorded in the build session; a device install and live Photon request still require Android-device verification.
