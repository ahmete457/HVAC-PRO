# HVAC PRO V13.6.57 — Kanal tasarım geliştirmesi

## Bu sürümde
- Otomatik kanal boyutlandırma ekranındaki 30 mahal üst sınırı kaldırıldı.
- Mahal sayısı alanı, + Mahal ekle, − Son mahali sil ve her mahal kartındaki silme kontrolü eklendi.
- Mahal kartlarında üfleme/dönüş debileri, ana kanal/branşman uzunlukları ve ayrı ΣK girdileri korunuyor.
- Her mahal için ayrı terminal girdisi kullanılıyor; hesap ve şematik çizim mahal sayısına göre dinamik büyüyor.
- Proje kaydet/aç akışındaki mahal geri yükleme sınırı da kaldırıldı.
- Sürüm 13.6.57 / versionCode 86 olarak güncellendi.

## Mühendislik kapsamı ve sınırlar
- Otomatik çizim, seri ana kanal ve yan branşman topolojisi için ön tasarım şemasıdır; keyfî çok düğümlü ağ çözücüsü değildir.
- Yerel kayıp katsayıları (ΣK) kullanıcı girdisidir; fitting geometrisinden otomatik çıkarılmaz.
- Üfleme ve dönüş ağları ayrı değerlendirilir. Dönüş hattı egzoz hattı olarak kabul edilmez.
- Nihai fan ESP ve kanal ölçüleri; gerçek güzergâh, fitting üretici verileri, terminal kayıpları, ses kriterleri ve geçerli standartlarla doğrulanmalıdır.

## Not
Mahal adedi için uygulama içinde sabit 8/30 sınırı yoktur. Pratik üst sınır cihaz belleği, tarayıcı performansı ve çizim alanının kullanılabilirliğidir.
