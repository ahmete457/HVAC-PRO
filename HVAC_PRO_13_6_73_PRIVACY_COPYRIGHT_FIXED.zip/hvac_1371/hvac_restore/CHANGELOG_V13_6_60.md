# HVAC PRO 13.6.60

- Konum seçimi Türkiye ile sınırlandırıldı; yalnızca 81 il merkezi listelenir.
- İlçe ve yabancı şehir arama arayüzü kaldırıldı; Photon / OpenStreetMap şehir arama çağrısı kaldırıldı.
- Hesap raporları il merkezi odaklı güncellendi.
- MGM'nin resmî il istatistikleri kaynağı uygulamadaki iklim verisi bilgilendirmesine eklendi.
- MGM aylık iklim normallerinin HVAC tasarım günü verisi olmadığı açıkça belirtilir.
- MGM'den doğrulanmamış nem, rakım veya tasarım sıcaklığı değerleri eklenmedi.
- Rakım-basınç bağıntısı standart atmosfer tahmini olarak kalır.

**Sürüm sınırı:** 81 ilin MGM aylık tabloları henüz uygulamaya otomatik içe aktarılmış değildir. Bu paket, Türkiye/81 il merkezi kapsamı ve kaynak/doğruluk ayrımını uygular; tam MGM iklim veri entegrasyonu olarak değerlendirilmemelidir.
