# HVAC PRO 13.6.72 – Hesaplama geliştirmesi

- Soğutma ve ısıtma yüklerine doğrusal ısı köprüsü katkısı eklendi: Q = ψ × L × ΔT.
- ψ (W/mK) ve toplam birleşim uzunluğu (m) kullanıcı tarafından girilir; varsayılan değerler 0 olduğundan mevcut projelerin sonuçları değişmez.
- Isı köprüsü katkısı soğutma ve ısıtma sonuç dökümlerine eklenir.
- Girdi aralıkları doğrulanır; bilinmeyen ψ değerinin tahmin edilmemesi için varsayılan 0 ve açıklama kullanılır.
- Web ve Android WebView varlıkları eşitlendi.

Not: Bu, ayrıntılı 2D/3D ısı köprüsü simülasyonu değildir. Noktasal köprüler, zemin kenar etkileri ve standartlara özgü düzeltmeler ayrıca değerlendirilmelidir.
