# HVAC PRO 13.6.59 – 3D Kanal Görünümü ve AHU Kapasite Hesabı

- Kanal Tasarım Stüdyosu'na 2D plan ile senkron çalışan etkileşimli 3D kanal görünümü eklendi.
- Dikdörtgen kanal segmentleri 3D koordinatlarda hacim geometrisi olarak oluşturulur; kanal genişliği, yüksekliği ve ayarlanabilir montaj kotu kullanılır.
- 3D model parmak/mouse sürükleme ile döndürülebilir; tekerlek ile yakınlaştırılabilir ve görünüm sıfırlanabilir.
- AHU kapasite çıktısı gerekli soğutma kapasitesini kW, TR ve BTU/h cinsinden verir; mahal yükleri, taze hava ilavesi, emniyet payı ve toplam üfleme debisini raporlar.
- Üretici serpantin kapasitesi ve nominal hava debisi girildiğinde uygunluk kontrolü yapılır.
- Sürüm 13.6.59 / versionCode 88; service-worker cache yenilendi.

## Sınırlar
Bu sürüm, gerçek 3B koordinat ve hacim geometrisi kullanan etkileşimli bir ön tasarım görüntüleyicisidir; henüz tam BIM/CAD motoru değildir. Otomatik tasarım ağı hâlâ şematik topoloji varsayımlarına dayanır. AHU sonucu ön kapasite hesabıdır; nihai serpantin/cihaz seçimi üretici performans verileriyle doğrulanmalıdır.
