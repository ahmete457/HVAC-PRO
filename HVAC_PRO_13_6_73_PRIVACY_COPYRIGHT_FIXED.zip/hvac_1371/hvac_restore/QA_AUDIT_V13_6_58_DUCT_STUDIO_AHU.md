# HVAC PRO 13.6.58 – QA Audit

| Kontrol | Sonuç |
|---|---|
| Tek 2D kanal çizim alanı; eski yinelenen çizim alanı kaldırıldı | PASS |
| 2D stüdyo mevcut ve tam ekran | PASS |
| Mahal listesi dinamik; sabit 30 mahal limiti yok | PASS |
| Mahal bazında soğutma yükü girdisi | PASS |
| AHU ön kapasite hesabı: mahal + taze hava + emniyet payı | PASS |
| AHU serpantin kapasitesi ve nominal debi kontrolü | PASS |
| Türkçe/İngilizce metin eşleştirmeleri | PASS |
| JavaScript ve HTML statik QA | PASS |
| Android XML / proje yapısı QA | PASS |

**Sınırlar:** APK derlenmedi; gerçek cihaz/dokunmatik test yapılmadı. AHU kapasite yardımcısı üretici kataloglarından otomatik model seçimi yapmaz ve nihai coil seçimi yerine geçmez.
