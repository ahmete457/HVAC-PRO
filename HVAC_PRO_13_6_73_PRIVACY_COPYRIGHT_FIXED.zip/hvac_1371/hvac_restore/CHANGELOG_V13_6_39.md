# HVAC PRO 13.6.39

- Added an HVAC discipline hub with separate entry points for cooling, heating, ventilation, hydronics, psychrometrics, and equipment/systems.
- Discipline cards route to the existing calculator sections; calculation engines and existing project/city workflows are retained.
- Expanded English UI dictionary for the new navigation and commonly visible form labels, actions, notices, and section headings.
- Preserved Turkish/English language selection and saved-language behavior.
- Version code: 69.

QA note: JavaScript syntax and project structural checks are run before delivery. A Gradle APK build and physical-device test are not implied unless separately reported.
