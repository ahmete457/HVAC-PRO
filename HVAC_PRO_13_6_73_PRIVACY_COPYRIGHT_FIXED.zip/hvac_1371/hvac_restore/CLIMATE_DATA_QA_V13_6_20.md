# HVAC PRO V13.6.20 – İklim veri kabul kontrolü

## Veri güvenliği kararı
- 81 il için şema hazır; tasarım yaz DB, eşzamanlı WB ve kış DB alanları doğrulanana kadar null.
- Mevcut şehir sıcaklığı/nem/rakım başlangıçları (Malatya rakımı hariç) yaklaşık/legacy kabul edilir.
- Kış tasarım sıcaklığı rakımdan türetilmez; kullanıcı kaynaklı tasarım değeri girmeden ısıtma hesabı başlatılamaz.
- Malatya rakımı 950 m MGM istasyon sayfası referansıyla girilmiştir; tasarım sıcaklıkları ayrıca doğrulanmalıdır.

## Kabul testleri
1. 81 şehir kaydı JSON içinde bulunmalı.
2. Her şehirde design_weather_status `not_verified` ve tasarım sıcaklıkları null olmalı.
3. Şehir değişiminde kış tasarım sıcaklığı otomatik bir tahminle doldurulmamalı.
4. Kış tasarım sıcaklığı boşken ısıtma hesabı başlamamalı; kullanıcı kaynaklı negatif değer girebilmeli.
5. Malatya seçildiğinde rakım 950 m olmalı.
6. Rakımdan hesaplanan basınç “standart atmosfer tahmini” olarak kalmalı; istasyon basıncı diye sunulmamalı.
7. Yaz sıcaklığı ve RH başlangıç değerleri “ön kabul/doğrulanmamış” olarak etiketlenmeli.

## Veri kaynağı ve sonraki iş
MGM MEVBİS arşivinden istasyon bazlı uzun dönem saatlik sıcaklık/nem/basınç verileri temin edilmeli. Tasarım yüzdelikleri aynı istasyon ve dönem üzerinden hesaplanıp kaynak, istasyon numarası, koordinat, rakım, dönem ve yöntem ile kaydedilmelidir.
