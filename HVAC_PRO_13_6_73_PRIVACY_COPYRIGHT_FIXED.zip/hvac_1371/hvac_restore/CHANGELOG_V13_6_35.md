# HVAC PRO 13.6.35

- Android sürüm kimliği 13.6.35 / versionCode 65 olarak güncellendi.
- Pompa çalışma noktası aracı eklendi: kullanıcı üç üretici Q-H noktası, sistem statik yüksekliği ve devir oranı girer; üç nokta arasında doğrusal enterpolasyon ve H=Hstatik+K·Q² sistem eğrisi kesişimi sayısal olarak çözülür.
- Devir değişiminde pompa eğrisi affinity laws yaklaşımıyla ölçeklenir (Q ∝ N, H ∝ N²).
- Menfez/difüzör için kullanıcı tarafından girilen standart yüz ölçüleri arasından hedef etkin alan hızını sağlayan ilk nominal ölçü önerisi eklendi.
- Türkçe/İngilizce başlık ve işlem metinleri eklendi.
- Önceki fan, pompa güç, hidronik boru, psikrometri ve kanal hesapları korunmuştur.

## Mühendislik sınırları

Pompa çalışma noktası yalnızca girilen üç Q-H noktası arasında geçerlidir; eğri dışına ekstrapolasyon yapılmaz. Doğrusal enterpolasyon gerçek üretici eğrisinin yerine geçmez. Pompa verim, NPSH, minimum debi, motor yükü ve paralel/seri pompa davranışı ayrıca üretici verileriyle kontrol edilmelidir. Sistem eğrisi H=Hstatik+K·Q² kabulüdür.

Menfez ölçü önerisi yalnızca nominal alan ve serbest alan oranına dayalı ön boyutlandırmadır; atış mesafesi, ses gücü ve basınç kaybı için üretici seçim verileri gerekir.
