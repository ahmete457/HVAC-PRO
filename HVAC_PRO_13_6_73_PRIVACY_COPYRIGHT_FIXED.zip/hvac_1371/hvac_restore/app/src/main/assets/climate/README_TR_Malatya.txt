HVAC PRO offline climate pack - Malatya-Bolge (station 171990)

Source package: TUR_ML_Malatya-Bolge.171990_TMYx.2009-2023.zip
Publisher: Climate.OneBuilding.org
TMYx attribution: Lawrie, L.K., Crawley, D.B. (2022). Development of Global Typical Meteorological Years (TMYx). https://climate.onebuilding.org

IMPORTANT QUALITY NOTE:
The EPW filename says 2009-2023, but its COMMENTS 1 line says #years=[5], Period of Record=2009-2013. Treat this dataset as provisional; it is NOT a full 15-year record and must NOT be presented as official ASHRAE design conditions.

Location: 38.35000 N, 38.31667 E, elevation 948 m; WMO station 171990.
The JSON summary is generated from the 8,760 hourly EPW rows. It is intended for preliminary climate context only.

License: Climate.OneBuilding TMYx attribution is published as CC BY 4.0. Preserve attribution and re-check upstream terms before redistribution. Attribution does not certify engineering accuracy.
