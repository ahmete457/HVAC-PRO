package com.hvacpro.engineering

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.ViewGroup
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingExportJson: String? = null
    private val CREATE_BACKUP = 4101
    private val OPEN_BACKUP = 4102

    inner class AndroidBridge {
        // PDF test access is available only in debug builds; release builds always return false.
        @JavascriptInterface
        fun isDebugBuild(): Boolean = BuildConfig.DEBUG

        @JavascriptInterface
        fun exportProjects(json: String) {
            runOnUiThread {
                pendingExportJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "HVAC_PRO_Projeler_Yedek.json")
                }
                startActivityForResult(intent, CREATE_BACKUP)
            }
        }

        @JavascriptInterface
        fun importProjects() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivityForResult(intent, OPEN_BACKUP)
            }
        }

        @JavascriptInterface
        fun printPdf() {
            runOnUiThread {
                try {
                    val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = webView.createPrintDocumentAdapter("HVAC_PRO_Rapor")
                    val attributes = PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(PrintAttributes.Resolution("hvacpro", "HVAC PRO", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build()
                    printManager.print("HVAC PRO Raporu", adapter, attributes)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "PDF oluşturma başlatılamadı: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) { pendingExportJson = null; return }
        val uri = data.data!!
        try {
            when (requestCode) {
                CREATE_BACKUP -> {
                    val payload = pendingExportJson ?: return
                    contentResolver.openOutputStream(uri)?.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "HVAC PRO proje yedeği kaydedildi.", Toast.LENGTH_LONG).show()
                    pendingExportJson = null
                }
                OPEN_BACKUP -> {
                    val payload = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("Dosya okunamadı")
                    webView.evaluateJavascript("window.onProjectsImported(${JSONObject.quote(payload)});", null)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Proje yedeği işlemi başarısız: ${e.message}", Toast.LENGTH_LONG).show()
            pendingExportJson = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
