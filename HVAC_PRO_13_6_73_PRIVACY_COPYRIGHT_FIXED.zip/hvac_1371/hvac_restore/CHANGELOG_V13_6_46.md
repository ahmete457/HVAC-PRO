# HVAC PRO 13.6.46 — Kanal uzunlukları ve okunabilir otomatik şema

## Değişiklikler
- Otomatik kanal tasarımındaki mahal girişleri mobil uyumlu kartlara dönüştürüldü; dar ekranda etiketlerin ve alanların üst üste binmesi azaltıldı.
- Her terminal için üfleme debisi, dönüş debisi, üfleme ana kanal segment uzunluğu, üfleme branşman uzunluğu, dönüş ana kanal segment uzunluğu ve dönüş branşman uzunluğu ayrı girilebilir.
- Otomatik 2D şema, kullanıcı tarafından girilen kanal uzunluklarına göre yerleşir; geniş projelerde yatay kaydırma ve yakınlaştırma desteklenir.
- Her ana kanal segmentinin kalan debisi, terminal debilerinin kümülatif toplamından hesaplanır; her branşman kendi terminal debisini taşır.
- Her segment için debi, uzunluk, önerilen ölçü, hız ve düz kanal Darcy-Weisbach sürtünme kaybı listelenir.
- Hava yoğunluğu, dinamik viskozite ve pürüzlülük düzenlenebilir.

## Mühendislik sınırları
- Kanal uzunluğu tek başına hava debisini belirlemez. Debi, terminal talepleri ve bağlantı/topoloji üzerinden belirlenir; uzunluk, çap/ölçü, hız ve pürüzlülük ile birlikte düz kanal basınç kaybını etkiler.
- Hesaplanan basınç kaybı yalnızca düz kanal sürtünme kaybıdır. Dirsek, T, redüksiyon, damper, filtre, serpantin, susturucu, panjur, menfez ve cihaz kayıpları henüz bu toplamda yoktur.
- Bu sürümde dönüş hattı ayrı modellenir; taze hava ve egzoz akışları dönüş havasıyla aynı kabul edilmez. Ayrı hava akışlarının santral şeması ve kütle dengesi sonraki geliştirme kapsamındadır.
- Sonuçlar ön boyutlandırmadır; nihai fan seçimi ve uygulama projesi için standartlar, üretici verileri ve mühendislik kontrolü gerekir.

## Sürüm
- versionCode: 76
- versionName: 13.6.46
