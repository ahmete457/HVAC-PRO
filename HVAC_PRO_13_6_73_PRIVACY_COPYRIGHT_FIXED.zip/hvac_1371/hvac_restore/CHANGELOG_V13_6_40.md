# HVAC PRO 13.6.40

## Hava Dağıtım Tasarımı
- Ana HVAC uzmanlık ekranına ayrı Hava Dağıtım Tasarımı girişi eklendi; alt navigasyon kalabalıklaştırılmadı.
- Ayrı hava dağıtım ağı paneli eklendi.
- Segment bazında kaynak/hedef düğümü, debi, hedef hız, kanal şekli, en-boy oranı, uzunluk ve toplam yerel kayıp katsayısı girilebilir.
- Dairesel ve dikdörtgen kanal kesitleri hedef hıza göre ön boyutlandırılır.
- Hidrolik çap, Reynolds sayısı, Darcy sürtünme faktörü, düz kanal kaybı ve ΣK yerel kaybı hesaplanır.
- Kaynak düğümünden terminal düğümlerine yollar taranır ve en yüksek hesaplanan basınç kayıplı yol kritik hat olarak raporlanır.
- Hava özellikleri ve terminal/cihaz ek kaybı kullanıcı tarafından düzenlenebilir.
- Yeni modülün arayüz metinleri ve sonuçları Türkçe/İngilizce destekler.

## Mühendislik kapsamı ve sınırlar
- Her segment debisi kullanıcı tarafından girilir; ağın otomatik debi dağıtımı/denge çözümü bu sürümde yoktur.
- Ortak hat, filtre, serpantin, susturucu, damper ve terminal cihaz kayıpları ayrıca modellenmeli veya terminal/cihaz ek kaybına girilmelidir.
- Kanal ölçüleri hedef hızdan türetilen teorik ön boyutlandırma ölçüleridir; ticari standart ölçülere yuvarlama ve hızın yeniden kontrolü gerekir.
- Menfez/difüzör atış mesafesi, ses gücü, akustik kriterler ve üretici seçim verileri bu sürümde otomatik hesaplanmaz.
- Sonuçlar nihai proje onayı yerine geçmez.

## Sürüm
- versionName: 13.6.40
- versionCode: 70
