# HVAC PRO 13.6.58 – 2D Kanal Stüdyosu ve AHU Ön Kapasite Kontrolü

## Değişiklikler
- Kanallar sayfasındaki ikinci/tekrarlı eski kanal çizim alanı kaldırıldı. Tek çizim yüzeyi tam ekran 2D Kanal Tasarım Stüdyosu olarak bırakıldı.
- 2D stüdyo çalışma alanı, araç çubukları, kartlar, ızgara ve kanal çizgi görselliği yenilendi.
- Otomatik mahal kartlarına mahal soğutma yükü (kW) girişi eklendi; mevcut proje yedekleme/kaydetme mekanizması bu girdiyi de saklar.
- AHU ön kapasite yardımcısı eklendi: mahal soğutma yükleri + ilave taze hava soğutma yükü + ayarlanabilir emniyet payından kW, TR ve BTU/h hedefi üretir; toplam mahal üfleme debisini ayrıca raporlar.
- Kullanıcının seçtiği AHU serpantin kapasitesi ve nominal hava debisi girilerek ön uygunluk kontrolü yapılabilir.
- Yeni metinler için İngilizce karşılıklar eklendi.
- Uygulama sürümü 13.6.58 / versionCode 87 olarak güncellendi; service-worker cache sürümü artırıldı.

## Mühendislik sınırı
AHU aracı ön kapasite kontrolüdür; üretici modelini otomatik seçmez. Nihai seçimde duyulur/gizli yük, dış hava oranı, giriş/çıkış hava koşulları, nem alma, coil performansı, basınç kayıpları ve üretici seçim tabloları doğrulanmalıdır. Soğutma kapasitesi ile hava debisi ayrı kontrollerdir.

## QA
- `node scripts/qa_validate.js` başarılı.
- `python scripts/qa_validate_project.py` başarılı.
- Bu teslimatta APK derlemesi ve fiziksel cihaz testi yapılmadı.
