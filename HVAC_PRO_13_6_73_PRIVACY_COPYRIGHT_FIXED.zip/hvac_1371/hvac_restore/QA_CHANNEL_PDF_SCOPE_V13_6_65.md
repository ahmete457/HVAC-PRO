# QA – 13.6.65 Kanal PDF görünürlük düzeltmesi

- [x] Tek `data-module-tools=duct` kartı bulundu.
- [x] Kartın DOM'a yükleme sonrası `#airDesign` içine taşınmasını sağlayan kod eklendi.
- [x] Kanallar dışındaki panellerde kartı göstermeyen mevcut CSS kuralı artık doğru DOM yapısıyla uygulanır.
- [x] Web ve Android `index.html` dosyaları birebir eşitlendi.
- [x] ZIP bütünlük kontrolü ayrıca çalıştırılacak.
- [ ] Android cihaz üzerinde görsel/etkileşim testi yapılmadı.
