# HVAC PRO 13.6.47 — Kanal çizim görsel iyileştirmesi

## Değişiklikler
- Otomatik kanal şemasında ana kanal ve branşmanlar gölgeli, çift tonlu ve yuvarlatılmış teknik kanal çizgileriyle gösterilir.
- Branşman birleşimlerinde bağlantı düğümleri belirginleştirildi; hava akış yönünü gösteren oklar eklendi.
- Santral, üfleme/dönüş başlıkları, ana kanal debileri ve terminal etiketleri daha okunaklı rozetler halinde düzenlendi.
- Terminal adı ve debisi çizimde gösterilir; ayrıntılı segment tablosu ve mevcut hesaplar korunmuştur.
- Izgaraya ana referans çizgileri eklendi. Hesaplama yöntemleri ve mühendislik sınırları değiştirilmedi.

## Kontrol notu
Bu güncelleme görsel sunumu iyileştirir; gerçek bağlantı topolojisi, fitting kayıpları ve tam fan ESP hesabı eklemez.

## Sürüm
- versionCode: 77
- versionName: 13.6.47
