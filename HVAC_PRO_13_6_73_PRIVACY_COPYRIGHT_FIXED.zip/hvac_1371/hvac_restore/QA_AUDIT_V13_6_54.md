# HVAC PRO V13.6.54 – QA Denetim Özeti

## Yapılan kontroller
- `node scripts/qa_validate.js`: **31 PASS, 0 FAIL**. Hesaplama referans vektörleri, HTML ID bütünlüğü, inline JavaScript parse, proje kaydı, modül navigasyonu ve sayfa ayrımı kontrolleri geçti.
- `python3 scripts/qa_validate_project.py`: **71 PASS, 0 FAIL**. Android XML, manifest, sürüm, ülke/şehir seçimi, navigasyon, native PDF/JSON yedek köprüleri ve GitHub Actions kontrolleri geçti.
- ZIP bütünlüğü ayrıca kontrol edildi.

## Uygulama davranışı
- Ana menüde hesaplama formu artık doğrudan gösterilmez. Menü seçimi ilgili çalışma sayfasını açar.
- Taze hava ve kanal tasarımı farklı menü seçenekleridir. Diğer çalışma sayfalarında ana menüye dönüş bağlantısı vardır.
- Türkiye şehirleri çevrimdışı 81 il listesiyle seçilir. Diğer ülkelerde Photon konum araması internet bağlantısıyla çalışır; sonuçlar seçili ülkenin ISO ülke koduna göre filtrelenir.
- Uygulamada global iklim veri servisi, ERA5 arşiv çağrısı veya gömülü iklim profili yoktur. Şehir seçimi yalnızca konum bilgisidir; tasarım iklim değerleri kullanıcı tarafından girilir.

## Bilinen sınırlamalar
- Photon araması canlı internet servisine bağlıdır. Kamuya açık demo sunucusu makul kullanım içindir; yoğun kullanım kısıtlanabilir ve hizmet garantisi verilmez. Ürün büyüdüğünde kendi Photon sunucusu veya SLA sunan bir geocoding sağlayıcısı kullanılmalıdır. Farklı ülkelerdeki yer adlarının kapsaması APK üzerinde ayrıca test edilmelidir.
- Konum servisi şehir adı ve ülke kodunu alır; proje hesapları veya bina girdileri gönderilmez.
- APK derlenmedi. Ortamda Gradle/Android SDK/ADB olmadığı için cihaz üzerinde gerçek UI, PDF ve geri yükleme testleri yapılmadı.
- Hesaplama motorlarının statik/reference QA testleri, tüm gerçek projelerde mühendislik doğrulaması yerine geçmez.
