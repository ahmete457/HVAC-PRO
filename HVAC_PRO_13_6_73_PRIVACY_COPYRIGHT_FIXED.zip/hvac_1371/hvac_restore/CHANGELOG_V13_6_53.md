# HVAC PRO 13.6.53

- Replaced the flat city selector with a country-first selector and a dependent province/city selector. Türkiye exposes the 81 existing province profiles; other countries use the global geocoding result selector and inherit the selected country.
- Reorganized bottom navigation into separate Loads, Fresh Air, Ducts, Hydronic and Projects destinations.
- Added separate local project collections for load, fresh-air, hydronic and duct workspaces, including independent open/delete actions in each module.
- Added discipline-specific PDF print scopes: load report, fresh-air report, hydronic report and duct report. Reports no longer append unrelated discipline results.
- Included each discipline workspace in the JSON backup/restore format while retaining compatibility with older backups.
- Existing legacy all-in-one project storage remains intact for backward compatibility.

## Validation limits

This update has not been compiled into an APK in this environment. Global country/city coverage outside Türkiye depends on the configured licensed HVAC PRO climate gateway; no country city catalog is fabricated.

See `QA_AUDIT_V13_6_53.md` for validation results and deployment limitations.
