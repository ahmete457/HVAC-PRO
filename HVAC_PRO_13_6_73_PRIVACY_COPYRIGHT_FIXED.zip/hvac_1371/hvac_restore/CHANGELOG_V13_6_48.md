# HVAC PRO 13.6.48 — Branşman yerel kayıpları ve kritik hat

## Değişiklikler
- Otomatik kanal terminal kartlarına üfleme/dönüş ana kanal ve branşman için ayrı ΣK girişleri eklendi.
- Her ana kanal segmenti ve branşman için Darcy-Weisbach düz kanal kaybı ile yerel kayıp ayrı, toplam kayıp birlikte gösterilir.
- Yerel kayıp ΔP = ΣK × ρ × v² / 2 bağıntısıyla hesaplanır.
- Her terminale kadar ortak ana kanal kayıpları ve ilgili branşman kaybı toplanarak tahmini kritik hat belirlenir.
- Negatif/bozuk ΣK girdileri engellenir; önceki kanal ölçülendirme ve çizim akışı korunur.

## Mühendislik sınırı
- ΣK değerleri fitting geometrisinden otomatik türetilmez; kullanıcı uygun üretici/standart değerini girmelidir.
- Filtre, serpantin, susturucu, menfez, AHU, panjur ve cihaz kayıpları henüz fan basıncına dahil değildir. Bu sonuç nihai fan seçimi değildir.
- Ağ sıralaması mevcut otomatik şemadaki terminal sırasına bağlıdır; serbest düğüm/kenar topolojisi henüz yoktur.

## Sürüm
- versionCode: 78
- versionName: 13.6.48
