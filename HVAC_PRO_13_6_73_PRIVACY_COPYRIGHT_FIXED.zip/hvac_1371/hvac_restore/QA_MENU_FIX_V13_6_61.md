# HVAC PRO 13.6.61 — Menu / JavaScript initialization fix

## Root cause found
The HTML loaded two separate inline JavaScript blocks that each declared the top-level lexical constant `TURKISH_PROVINCES`. Browsers share the global lexical declaration environment across classic script tags. The second declaration therefore raised `SyntaxError: Identifier 'TURKISH_PROVINCES' has already been declared`. That stopped the main application initialization script from executing, so navigation listeners and other UI handlers were never registered. This explains why all menus appeared unresponsive.

## Correction
- Removed the redundant first province-list script; retained the single canonical 81-province list.
- Kept the Türkiye-only province selector and no-district/no-foreign-city behavior.
- Mirrored the corrected web interface into Android WebView assets.
- Version updated to 13.6.61 / versionCode 90.

## Checks completed
- Combined inline JavaScript parse check: PASS.
- Exactly one `TURKISH_PROVINCES` declaration: PASS.
- Android `assets/index.html` equals `web/index.html` byte-for-byte: PASS.
- Android XML structural checks: PASS.
- Existing project QA: NOT CLEAN. Legacy AHU capacity preselection expectation fails.
- Existing JS QA: NOT CLEAN. Legacy 2D editor / zone editor / AHU assistant assertions fail; other listed menu, navigation, calculation and hydronic assertions pass.
- ZIP integrity: checked after packaging.

## Not claimed
- No Gradle APK/AAB build was run.
- No physical Android device test was run.
- No live Chromium test was completed in this environment; browser navigation was blocked by the execution environment.
