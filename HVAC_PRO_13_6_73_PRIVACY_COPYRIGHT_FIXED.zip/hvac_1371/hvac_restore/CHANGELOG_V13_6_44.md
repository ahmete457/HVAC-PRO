# HVAC PRO 13.6.44 — 2D Kanal Tasarım Stüdyosu

## Yeni özellikler
- Hava Dağıtım Tasarımı ekranına ayrı, tam ekran 2D Kanal Tasarım Stüdyosu eklendi.
- Manuel tasarım araçları: seçim, kanal segmenti çizimi, klima santrali, hava terminali/menfez, dirsek, T parçası, redüksiyon, damper ve silme.
- Kanal/ekipman özellik paneli: ad, debi, genişlik, yükseklik, uzunluk ve yerel K değeri düzenlenebilir.
- Izgara yakalama, dik açılı kanal çizimi, geri alma, temizleme ve cihaz üzerinde yerel çizim kaydı eklendi.
- Otomatik tasarım: santral debisi, terminal/mahal sayısı, terminal başına debi, ana kanal ve branşman hedef hızları ile kanal şekli/aspect ratio girdileri.
- Otomatik şematik ana hat ve branşman çizimi, terminal debi toplamı kontrolü ve hız kriterine göre ön kanal boyutlandırması eklendi.
- Türkçe/İngilizce arayüz sözlüğüne yeni stüdyo metinleri eklendi.

## Mühendislik kapsamı ve sınırlar
- Otomatik mod bu sürümde debi girdilerinden şematik bir ana hat/branşman ağı üretir; gerçek bina planına göre güzergâh optimizasyonu yapmaz.
- Boyutlar hedef hava hızına göre ön boyutlandırılır ve 25 mm artımla yuvarlanır. Basınç kaybı, ses, çakışma, terminal atış mesafesi, fitting detay geometrisi ve fan seçimi otomatik çözülmez.
- Manuel çizimde fittingler sembolik tasarım nesneleridir; otomatik bağlantı topolojisi ve debi dengeleme henüz yoktur.
- Nihai tasarım; proje standardı, üretici verileri ve yetkin mühendis kontrolü gerektirir.

## Sürüm
- versionCode: 74
- versionName: 13.6.44
