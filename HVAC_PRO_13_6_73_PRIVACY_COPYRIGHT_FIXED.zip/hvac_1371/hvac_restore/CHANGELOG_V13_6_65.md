# HVAC PRO 13.6.65

- Kanal proje işlemleri kartı DOM içinde yalnızca `#airDesign` (Kanallar) çalışma alanına taşındı.
- Önceki HTML kapanış yapısı nedeniyle kart `main` altında panel dışına düşüyor ve tüm sayfalarda görünüyordu.
- Web ve Android WebView varlıkları eşitlendi.
- Android versionCode 92 / versionName 13.6.65.
