# HVAC PRO 13.6.73 — Consolidated Release Candidate

This is the consolidated Android source project at versionName 13.6.73 / versionCode 100.

## Included
- Cooling and heating load calculation engines, including the linear thermal-bridge contribution.
- Separate report actions for cooling, heating, fresh air, duct design, hydronic, psychrometric process, fan/pump, pump operating point, equipment capacity, multi-zone summary and VRF pre-check.
- Turkish 81 province-centre offline selector. Missing official design data is disclosed; starter profiles are not represented as verified MGM design conditions.
- Duct studio, AHU capacity pre-check, hydronic pressure-loss tools, psychrometric process checks, project save/restore and JSON backup.
- Android native PDF print bridge and JSON document pickers.
- GitHub Actions workflow configured to run source QA, Android structural QA, debug APK build and lint; release APK/AAB build is conditional on upload-signing secrets.

## Automated checks run for this handoff
- `node scripts/qa_validate.js` — PASS.
- `python3 scripts/qa_validate_project.py` — PASS.
- Web UI and Android packaged WebView asset are byte-for-byte synchronized — PASS.
- Version name/code, workflow artifact label and README build instructions aligned to 13.6.73 / 100 — PASS.
- Source ZIP integrity (`unzip -t`) — PASS.

## Not certified / still required before public release
- No fresh APK/AAB was built in this environment because Gradle/Android SDK are unavailable here. Use the included GitHub Actions workflow.
- The separately uploaded APK inspected during this conversation is version 13.6.72, not this source version.
- Real Android-device testing is still required for every independent PDF print/save flow, navigation, backup/restore and representative calculations.
- Engineering outputs remain preliminary design aids and require project-specific inputs, applicable standards and manufacturer data validation.
- Ground-floor heat transfer remains a simplified temperature-difference model, not a full ISO 13370 ground-coupled slab calculation.
- A layer-by-layer U-value builder and full manufacturer-validated fan/pump curves and fitting catalogues are not implemented in this candidate.
- Google Play Billing / one-time Professional purchase flow is not integrated or validated.
- Package ID remains `com.hvacpro.engineering`; do not change it without confirming the Play Console package decision.

This is a consolidated source release candidate, not a claim that the app is already Play-Store-ready. Build a new APK/AAB and complete device and Play Console validation before publishing.
