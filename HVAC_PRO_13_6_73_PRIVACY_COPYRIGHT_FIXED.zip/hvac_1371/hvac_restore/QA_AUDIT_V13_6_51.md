# HVAC PRO 13.6.51 — Genişletilmiş mühendislik güncellemesi

## Paket bilgisi
- Kaynak paket: `HVAC_PRO_13_6_51_ENGINEERING_UPDATE.zip`
- Android versionName: `13.6.51`
- Android versionCode: `81`
- Paket uygulama adı: HVAC PRO
- Desteklenen arayüz dilleri: Türkçe / İngilizce

## Bu turda yapılan geliştirmeler

### 1. Proje çalışma alanının kalıcı kaydı
- Proje kaydı artık kimlikli input, select, textarea ve checkbox durumlarını saklar.
- Hidronik boru segmentleri ve kullanıcı girdileri proje kaydına eklenir.
- Otomatik kanal tasarımındaki mahal/terminal girdileri proje kaydına eklenir.
- Manuel 2D kanal çizimi proje kaydına dahil edilir.
- Isıtma hesabı çalıştırılmışsa proje yeniden açıldığında mevcut girdilerle tekrar hesaplanır.
- Önceki sürümlerde oluşturulmuş `workspace` alanı olmayan projeler için geriye dönük açma desteği korunur.

### 2. Çok disiplinli PDF/çıktı raporu
Mevcut soğutma/ısıtma raporuna ek olarak, rapor hazırlanırken ekranda sonuç üretmiş modüllerin metin özetleri eklenir:
- Taze hava yükü
- Psikrometrik prosesler
- Fan/pompa araçları ve pompa çalışma noktası
- Menfez/terminal ön boyutlandırma
- Kanal güzergâhı ve basınç kaybı
- Rakım/basınç hesabı
- Otomatik kanal ağı, kritik hat ve fan ESP
- Hidronik boru ağı
- Kapasite/zon ve VRF ön kontrolleri

Modül sonuçları HTML olarak içeri alınmaz; metin olarak rapora aktarılır. Sonuç üretmemiş modüller rapora eklenmez.

### 3. Sürüm / otomasyon
- `versionName` 13.6.51, `versionCode` 81 yapıldı.
- GitHub Actions artifact adı 13.6.51 olarak güncellendi.
- Debug APK ve lint, release imzalama anahtarı bulunmasa da çalışacak şekilde ayrıldı.
- İmzalı release APK/AAB yalnızca imzalama sırları yapılandırıldığında oluşturulur.

## Otomatik QA
- JavaScript QA: 28 PASS, 0 FAIL
- Android yapısal QA: 58 PASS, 0 FAIL
- HTML içindeki JavaScript parse kontrolü ve DOM referans denetimleri geçti.
- Psikrometri, rakım-basınç, taze hava yükü ve karışım havası referans vektörleri geçti.
- Girdi doğrulama ve resmi meteoroloji kaynağı metaverisi kontrolleri geçti.
- Hidronik Darcy-Weisbach / Swamee-Jain ve kritik yol kontrolleri geçti.
- Kanal boyutlandırma, yerel kayıplar, kritik yol ve fan ESP guardrail kontrolleri geçti.
- Proje çalışma alanı kaydetme/geri yükleme yapısal kontrolleri geçti.
- Çok disiplinli rapor eki kontrolleri geçti.
- Android manifest ve XML kaynak kontrolleri geçti.

## Önemli: Bu testlerin kapsamadığı alanlar
- Bu ortamda Android SDK/Gradle/ADB bulunmadığı için yeni APK/AAB derlenmedi.
- Gerçek telefonda kurulum, ekran dokunma akışı, PDF kaydetme ve dosya yedekleme testleri yapılmadı.
- Testler kaynak kod ve otomatik hesap referansları üzerindedir; mühendislik hesaplarının bütün standartlar ve üretici verileriyle saha kabulü değildir.
- İklim veri dosyasındaki 81 il profili ön kabul olarak kalır. Doğrulanmamış yaz/kış tasarım koşulları bilerek boş bırakılır.
- Otomatik kanal modeli seri ana kanal + yan branşman şemasıdır; keyfî çok düğümlü ağ çözümü değildir.
- Hidronik modül kritik yol ön hesabıdır; gerçek ağ dengeleme ve vana ön ayarı değildir.
- Fan/pompa ve cihaz seçimleri üretici eğrileri/katalogları ile teyit edilmelidir.
- Google Play Billing entegrasyonu tamamlanmış değildir. Debug Professional erişimi QA içindir; yayın sürümünde ödeme doğrulaması yapılmadan ücretli hak verilmemelidir.

## Gönderilen APK hakkında
Kullanıcının yüklediği `app-debug.apk`, başlangıç ZIP'indeki 13.6.49 varlıklarıyla eşleşir. Bu dosya yeni 13.6.51 geliştirmelerini içermez. Yeni APK'yı GitHub Actions üzerinden oluşturup telefonda test etmek gerekir.

## Sonraki yüksek değerli geliştirmeler
1. Gerçek düğüm/kenar tabanlı kanal ağı ve ağ basınç dengeleme.
2. Hidronik ağ debi dağılımı, vana ön ayarı ve pompa çalışma noktası bağlantısı.
3. Üretici kataloglarından AHU/fan/pompa/VRF kapasite seçimi.
4. Tasarım iklim verileri için kaynak, istasyon, dönem ve rakım izlenebilirliği.
5. Mahal bazlı yükleri tek proje modelinde toplama ve oda/kat bazlı rapor.
6. Gerçek Android cihaz üzerinde PDF ve proje yedeği regresyon testleri.
