# HVAC PRO V20 – Teknik denetim ve düzeltme kaydı

**Kaynak tabanı:** `HVAC_PRO_V13_6_20.zip`  
**Hazırlanan bakım sürümü:** `13.6.21`  
**Android versionCode:** `53`  
**Derleme yöntemi:** GitHub Actions (`build-apk.yml`)

## Yapılan düzeltmeler

1. **Merkezi soğutma girdisi doğrulaması:** Boş, sayısal olmayan, negatif veya belirlenen fiziksel aralıkların dışındaki değerler hesaplamayı durdurur. Özellikle SHGC ve gölgeleme katsayısı 0–1 ile sınırlandırılmıştır. Kişi sayısı tam sayı olmalıdır.
2. **Isıtma girdisi doğrulaması:** Kış tasarım sıcaklığı -60…25 °C aralığında ve iç ortam sıcaklığından düşük olmalıdır. Zemin sıcaklığı, HRV verimi ve emniyet payı için boş giriş kontrolü eklendi.
3. **Taze hava hesaplayıcısı:** Negatif/boş kişi, alan ve birim debi girdileri sessizce sıfırlanmaz; geçersiz girişte sonuç uygulanmaz.
4. **Taze hava psikrometrik yükü:** Uygulamanın kullandığı entalpi, kuru hava kütlesel debisi, duyulur yük ve gizli yük hesabı `calculateOutdoorAirLoad()` fonksiyonunda birleştirildi ve doğrudan bu fonksiyon için referans testleri eklendi.
5. **Eski sonuç güvenliği:** Geçersiz girişte son hesap temizlenir. Girdi değiştiğinde önceki ısıtma sonucu ekranda kalmaz. Geçersiz veya eski soğutma sonucu üzerinden PDF raporu oluşturma ve proje kaydetme engellenir.
6. **İklim veri kaynağı:** 81 il profilinin tek kaynak dosyası `climate-data-tr.json` oldu. `generate_climate_js.js` bu JSON'dan Android WebView'ın çevrimdışı yüklediği `climate-data-tr.js` dosyasını üretir. Uygulama şehir seçimini bu üretilmiş veriden oluşturur.
7. **İklim verisi kaynağı kaydı:** Resmî tasarım meteoroloji verisi veya saha ölçümü seçildiğinde istasyon/konum, dönem/tarih, kaynak/cihaz bilgisi ve koordinatlar zorunludur. İlgili bilgiler proje kaydına ve PDF rapor üst bilgisine eklenir. Rakım alanına istasyon rakımının girilmesi istenir.
8. **Tavan yüksekliği:** Mevcut soğutma yükü formülünde kullanılmadığı arayüzde açıkça belirtilmiştir; kullanıcıya hesapta kullanılıyormuş izlenimi verilmez.
9. **GitHub Actions QA:** İklim varlığı üretimi, JavaScript/HTML ve hesap referans testleri, Android XML/Gradle/CSV kontrolleri APK/AAB derlemesinden önce çalışacak şekilde eklendi. Derleme sonrasında Android lint çalıştırılır.
10. **Sürüm ve dokümantasyon:** `versionName 13.6.21`, `versionCode 53`; test planı, kurulum notu ve GitHub Artifact adı güncellendi.

## Bu ortamda geçen kontroller

- HTML kimlikleri benzersiz; JavaScript'in sabit DOM referansları mevcut.
- Uygulama içi JavaScript sözdizimi geçerli.
- 81 il JSON, CSV ve uygulama profilleri eşleşiyor.
- Doğrulanmamış şehir tasarım sıcaklıkları JSON/CSV'de boş/null kalıyor.
- Psikrometrik referans vektörü (25 °C, %50 RH, 101325 Pa): nem oranı yaklaşık 0.009858 kg/kg, entalpi yaklaşık 50.263 kJ/kg, kuru hava yoğunluğu yaklaşık 1.16545 kg/m³.
- 950 m standart atmosfer basınç tahmini yaklaşık 90,421 Pa.
- 120 m³/h, 35 °C/%40 RH dış hava; 24 °C/%50 RH iç hava; 90,500 Pa için hava yükü yaklaşık 838.64 W. Duyulur yaklaşık 376.95 W + gizli yaklaşık 461.68 W = toplam entalpi yükü.
- Sıfır debi testi sıfır yük veriyor; daha serin dış hava için işaretli serbest soğutma katkısı korunuyor.
- Gerçek giriş doğrulayıcısı; varsayılan girdiler, SHGC=1.2, negatif taze hava debisi, eksik resmî kaynak metaverisi ve geçersiz boylam senaryolarıyla test edildi.
- Android XML kaynakları ve manifest sözdizimi geçerli.
- Gradle sürüm/SDK/version yapılandırması ve GitHub Actions adımları statik olarak kontrol edildi.

## Açık kalan yayın ve mühendislik kapıları

- **Gradle derlemesi ve Android lint bu çalışma ortamında çalıştırılmadı.** GitHub Actions'a yüklenip çalıştırılmalı; başarılı run sonucu görülmeden APK/AAB derlemesi başarılı kabul edilmemelidir.
- **Gerçek Android cihaz testi yapılmadı.** PDF/PrintManager, Türkçe karakterler, A4 sayfa taşmaları, Android sürüm uyumu, uygulama arka plana alınıp açıldığında proje depolaması cihazda test edilmelidir.
- **81 ilin mevcut yaz sıcaklığı, nem ve rakım başlangıçları yaklaşık/legacy ön kabuldür.** JSON'da tasarım yaz DB/WB ve kış DB değerleri bilerek null tutulur. Bu çalışma resmî MGM tasarım veri seti sağlamaz.
- **Soğutma/ısıtma motoru hâlâ ön boyutlandırma modelidir.** Duvar/çatı/zemin iletimi basitleştirilmiştir; zemin-temaslı döşeme, ısı köprüleri, saatlik güneş geometrisi/gölgeleme, termal kütle ve üreticiye özgü performans eğrileri tam modellenmez. Tam mühendislik onayı için kabul edilen standart ve bağımsız örnek projelerle ek doğrulama gerekir.
- **Google Play Billing henüz yoktur.** Release sürümünde Professional/ısıtma/proje/PDF erişimi satın alma doğrulaması olmadan kilitli kalır. Debug APK'daki erişim yalnızca QA amaçlıdır.
- **Release AAB imzalama yapılandırması yoktur.** Upload keystore ve GitHub Secrets ile güvenli imzalama ayrıca yapılmalıdır.
- **Bu çalışma mevcut GitHub deposuna push edilmedi.** Güncellenmiş kaynak ZIP'i GitHub deposuna aktarılmalı; Actions çalıştırması ve Artifact kontrolü kullanıcı deposunda tamamlanmalıdır.

## GitHub çıktısı

Workflow başarılı olursa Artifact adı: `HVAC-PRO-v13.6.21-packages`  
İçerik: debug APK (cihaz testi) ve release AAB (imzalama/yayın hazırlığı; şu an imzasız).
