# HVAC PRO 13.6.49

## Kanal tasarım – ekipman kayıpları ve fan ESP ön hesabı
- Üfleme ve dönüş tarafı için filtre, serpantin, ısı geri kazanım, susturucu ve diğer ekipman basınç kaybı girişleri eklendi.
- Üfleme ve dönüş kritik kanal yolu kayıpları, ekipman basınç kayıplarıyla birleştirilerek ayrı ayrı ön fan ESP değerleri hesaplanıyor.
- Kullanıcı emniyet payı girebiliyor; değerler Pa olarak raporlanıyor.
- Negatif/taşan ekipman kaybı ve emniyet payı girdileri doğrulanıyor.
- Üfleme/dönüş ayrımı ve model kapsamı sınırlamaları sonuç ekranında açıkça belirtiliyor.

## Mühendislik sınırları
- Taze hava ve egzoz henüz bağımsız bağlı kanal ağı olarak çözülmüyor.
- Otomatik ağ, seri ana kanal ve yan branşman varsayımıyla çalışır; keyfî çok düğümlü ağ dengelemesi değildir.
- ΣK değerleri kullanıcı tarafından girilir; fitting geometrisi otomatik tanınmaz.
- Fan ESP bir ön seçim hesabıdır; fan eğrisi/çalışma noktası ve üretici verileriyle doğrulanmalıdır.
- Gerçek Android APK derlemesi ve cihaz testi bu pakette yapılmamıştır.
