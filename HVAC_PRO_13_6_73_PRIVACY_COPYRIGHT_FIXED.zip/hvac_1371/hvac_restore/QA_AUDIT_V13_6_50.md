# HVAC PRO 13.6.50 — Kaynak Kod ve APK Denetim Raporu

## İncelenen dosyalar
- Kaynak paket: `HVAC_PRO_13_6_49_FULL_ENGINEERING_UPDATE.zip`
- APK: `app-debug.apk`
- Kaynak paketin başlangıç sürüm bilgisi: Android `versionName 13.6.49`, `versionCode 79`
- APK içindeki `index.html`, iklim JSON/JS, kılavuz ve gizlilik varlıklarının SHA-256 içerikleri başlangıç kaynak paketindeki karşılıklarıyla birebir eşleşti. Dolayısıyla gönderilen APK, 13.6.49 kaynak varlıklarını içeriyor; bu denetim sırasında yapılan 13.6.50 geliştirmelerini içermez.

## Başlangıç durumunda mevcut mühendislik modülleri
- Soğutma yükü ön hesabı ve ısıtma yükü ön hesabı
- Taze hava yükü ve nemli hava/psikrometri hesapları
- Psikrometrik prosesler: karışım, duyulur ısıtma, soğutma/nem alma ve nemlendirme
- Fan/pompa güç hesabı ve pompa çalışma noktası ön hesabı
- Hidronik boru segmentleri, Darcy-Weisbach ve Swamee-Jain ile kritik yol ön hesabı
- Kanal kesiti, basınç kaybı, menfez/difüzör ön boyutlandırması
- Manuel 2D kanal stüdyosu ve otomatik şematik kanal tasarımı
- Üfleme/dönüş tarafı ekipman kayıpları ve fan ESP ön hesabı
- Proje kaydı, JSON yedekleme ve Android yazdırma/PDF köprüsü
- Çevrimdışı 81 il iklim veri altyapısı

## Yapılan geliştirmeler — 13.6.50
1. Proje kaydı, ana soğutma girdilerinin ötesine genişletildi.
2. Kimlikli input/select/textarea alanları, checkbox durumları ve seçimleri çalışma alanı durumuna ekleniyor.
3. Hidronik devrenin dinamik boru segmentleri saklanıyor ve proje açılırken geri yükleniyor.
4. Otomatik kanal tasarımındaki mahal/terminal satırları saklanıyor ve geri yükleniyor.
5. Manuel 2D kanal çizimi proje çalışma alanına dahil ediliyor.
6. Isıtma hesabı daha önce çalıştırılmışsa proje açıldığında girdilerden yeniden hesaplanıyor.
7. Eski proje kayıtları için `workspace` alanı bulunmadığında önceki açma yöntemi korunuyor.
8. Android sürümü `13.6.50`, `versionCode 80` olarak artırıldı.
9. GitHub Actions artifact adı `HVAC-PRO-v13.6.50-packages` olarak güncellendi.
10. İmzalama anahtarı tanımlı değilse de debug APK ve Android lint çalışabiliyor. İmzalı release APK/AAB yalnızca imzalama sırları yapılandırılmışsa üretiliyor.

## Otomatik test sonuçları
- JavaScript kaynak/hesap QA: **27 PASS, 0 FAIL**
- Android proje yapısal QA: **56 PASS, 0 FAIL**
- Tarayıcı etkileşim testleri: 320, 360, 390, 430 ve 768 px genişliklerde çalıştırıldı.
- Test edilen ekran akışları: hesaplama, taze hava, hidronik örnek devre, kanal boyutlandırma ve kanal basınç kaybı.
- Tarayıcı konsolunda JavaScript hatası görülmedi.
- Proje kaydet/aç regresyonunda taze hava girdisi, hidronik segmentleri, otomatik kanal mahal bilgileri ve ısıtma hesabı geri yüklendi.

## Kritik mühendislik ve yayın sınırlamaları
- 81 il verisinin bazı alanları ön kabul niteliğindedir. Resmî yaz/kış tasarım koşulları doğrulanmadığı için doğrulanmamış tasarım sıcaklıkları boş bırakılmıştır. Bu yaklaşım korunmalıdır.
- Otomatik kanal ağı mevcut haliyle seri ana kanal ve yan branşman varsayımıyla çalışır; serbest çok düğümlü ağ çözümü ve otomatik hidronik debi dengelemesi değildir.
- Fan ESP hesabı ön seçimdir; gerçek fan eğrisi, çalışma noktası, sistem etkileri ve üretici verileriyle doğrulanmalıdır.
- Isıtma/soğutma modelleri ayrıntılı dinamik bina simülasyonu, tüm ısı köprüleri, zemin etkileşimi ve her standardın otomatik uygulanması yerine geçmez.
- Google Play Billing henüz entegre değildir. Uygulama ödeme almaz. Debug Professional erişimi yalnızca QA amaçlıdır; release sürümünde gerçek satın alma doğrulaması olmadan ücretli özellikler açılmamalıdır.
- PDF köprüsü kaynakta mevcut olsa da gerçek Android cihazda sayfa taşması, Türkçe karakterler ve çıktı kaydetme testi gereklidir.

## Derleme sınırı
Bu çalışma ortamında Gradle, Android SDK ve ADB bulunmadığından yeni 13.6.50 APK/AAB derlenmedi ve gerçek Android cihaz kurulumu yapılmadı. Gönderilen APK eski 13.6.49 varlıklarıyla eşleşmektedir. Güncellenmiş kaynak paket GitHub'a aktarıldığında Actions üzerinden yeni debug APK oluşturulabilir. Release APK/AAB için ayrıca upload signing secrets gerekir.

## Önerilen sonraki mühendislik geliştirmeleri
1. Proje bazlı birleşik rapor: soğutma, ısıtma, taze hava, psikrometri, kanal, hidronik ve cihaz sonuçlarının tek teknik raporda birleştirilmesi.
2. Serbest düğüm/kenar tabanlı kanal ağı ve otomatik debi/direnç dengelemesi.
3. Hidronik ağda otomatik debi dağılımı, vana ön ayarı ve pompa çalışma noktası entegrasyonu.
4. Doğrulanmış tasarım iklim veri kaynakları ve kaynak/istasyon izlenebilirliği.
5. AHU, fan, pompa, terminal ve VRF için üretici katalog verileriyle cihaz seçimi.
6. Standart/şartname seçilebilir taze hava ve iç ortam tasarım kriterleri.
7. Gerçek Android cihazda PDF, proje yedeği, ekran ölçeklenmesi ve performans regresyonu.

**Sonuç:** 13.6.50 kaynak paketi üzerinde kaynak ve tarayıcı QA kontrolleri geçti. Bu rapor, Android cihaz ve yayın doğrulamasının yerine geçmez.
