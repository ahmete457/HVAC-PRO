# HVAC PRO 13.6.66 — Hesaplama QA

## Yeni referans testleri
- Darcy faktörü laminer referans: Re=1000 → f=0.064.
- Düz boru türbülanslı referans: Re=100000, pürüzsüz boru → f≈0.0179.
- Geçiş rejiminde Churchill korelasyonu pozitif ve sonlu sonuç veriyor.
- Pürüzlü boru referansı: Re=100000, ε/D=0.001 → f≈0.02234.

## Regresyon kontrolleri
- Soğutma ve ısıtma bağımsız referans vektörleri geçti.
- Psikrometri, yaş termometre, basınç-rakım ve taze hava yükü referansları geçti.
- 81 il veri dosyası tam 81 kayıt içeriyor.
- JavaScript sözdizimi, HTML ID bütünlüğü ve Android XML kontrolleri geçti.

## Açık kalan QA
- Mevcut legacy kanal çizim, sınırsız mahal editörü ve AHU kapasite asistanı kontrolleri başarısız; bu sürümde değiştirilmedi.
- Gerçek Android cihaz testi ve Gradle APK derlemesi yapılmadı.
- Şehir iklim profilleri eski yaklaşık başlangıç değerleridir; doğrulanmış MGM tasarım günü verisi değildir.
