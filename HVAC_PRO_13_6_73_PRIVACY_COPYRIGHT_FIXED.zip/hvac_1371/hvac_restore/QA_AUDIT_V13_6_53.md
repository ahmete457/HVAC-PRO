# HVAC PRO 13.6.53 — UI / Module Separation QA Audit

## Delivered changes

1. **Country-first location selection**
   - The location form now asks for a country first, then a province/city.
   - The country list is based on ISO 3166-1 country/territory codes and uses localized region names where the device supports `Intl.DisplayNames`.
   - Türkiye exposes the existing 81-province offline selector.
   - For other countries, the city selector is populated from the configured global geocoding gateway results. This gateway is not configured in the current package, so international geocoding remains unavailable until the licensed HVAC PRO service is deployed and configured. No fake city/climate records are generated.

2. **Separate main navigation**
   - Loads (cooling/heating)
   - Fresh air
   - Ducts
   - Hydronic
   - Projects
   - Turkish and English navigation labels are supported.

3. **Independent module project records**
   - Separate localStorage namespaces for loads, fresh air, ducts and hydronic.
   - Each module captures its own inputs and dynamic rows/drawing data where applicable.
   - Each module has its own saved-record list with open/delete actions.
   - JSON backup now includes each module collection. Older backup files with only the legacy project list remain importable.

4. **Independent PDF report scopes**
   - Loads: heating/cooling report.
   - Fresh air: outdoor-air flow and load report.
   - Ducts: duct sizing, route/drawing and pressure-loss report.
   - Hydronic: pipe circuit and critical-path report.
   - Each print scope hides unrelated discipline panels and no longer appends all module results to one combined report.

## Automated QA

- `node scripts/qa_validate.js`: **32 PASS, 0 FAIL**.
- `python3 scripts/qa_validate_project.py`: **72 PASS, 0 FAIL**.
- HTML IDs checked for uniqueness; inline JavaScript parsed successfully.
- Existing calculation reference vectors remain passing.
- Android XML structural checks passed.
- ZIP archive integrity checked separately.

## Important limitations / not claimed as complete

- This environment does not contain a usable Gradle / Android SDK build toolchain. The updated source has **not** been compiled into an APK or AAB here.
- No physical Android device regression test, native PDF save dialog test, or Android storage persistence test was performed.
- The current uploaded APK from earlier work is not this version. A fresh APK must be built by GitHub Actions after committing this source.
- Türkiye's 81 province entries remain preliminary city profiles, not verified ASHRAE/MGM station design conditions. Their design DB/WB/winter values remain unverified/null where applicable.
- International city lookup and global climate archive retrieval require the licensed HVAC PRO gateway URL and backend to be deployed. Country options alone do not constitute climate data coverage.
- Project save/PDF actions retain the existing Professional entitlement gate. Google Play Billing is not integrated; debug QA entitlement must not be mistaken for production purchase verification.
- Static QA does not validate the engineering suitability of each design result or manufacturer equipment selection.

## Version

- `versionName`: 13.6.53
- `versionCode`: 83
