# HVAC PRO 13.6.36

- Pompa çalışma noktası hesabında sistem eğrisi artık pompa eğrisinin bir noktasından türetilmiyor.
- Kullanıcı tasarım debisini (m³/h), bu debideki dinamik basınç kaybını (mSS) ve statik yüksekliği (mSS) bağımsız giriyor.
- Sistem katsayısı K = H_dinamik,tasarım / Q_tasarım² olarak hesaplanıyor; H_sistem = H_statik + K·Q² kullanılıyor.
- Pompa üretici Q-H noktaları, devir oranı ile affinity laws yaklaşımında ölçekleniyor; pompa eğrisi üç nokta arasında doğrusal enterpole ediliyor.
- Kesişim yalnızca girilen pompa eğrisi aralığında bisection yöntemiyle aranıyor; aralık dışında ekstrapolasyon yapılmıyor.
- TR/EN açıklamalar güncellendi. Sürüm 13.6.36, versionCode 66.

## Sınırlamalar
Bu araç ön analiz içindir. Tasarım dinamik kaybı kullanıcı tarafından hesaplanıp girilmelidir. Kapalı devre hidronik sistemlerde statik yükseklik çoğu durumda pompa diferansiyel basınç gereksinimine eklenmez; yalnızca gerçekten statik yük farkı bulunan sistemlerde kullanılmalıdır. Üretici pompa eğrisi, verim, NPSH, minimum debi ve çalışma zarfı ayrıca doğrulanmalıdır.
