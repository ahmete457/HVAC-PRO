# HVAC PRO 13.6.37 — Proje Bazlı Hidronik Devre Tasarımı

## Eklenenler
- Yeni Hidronik sekmesi; mevcut Hesaplama, Taze Hava, Projeler, Professional ve Kılavuz ekranları korunmuştur.
- Proje/devre adı ve kaynak düğümü tanımlama.
- İstenildiği kadar boru segmenti ekleme/silme; başlangıç-bitiş düğümü, debi, iç çap, uzunluk, mutlak pürüzlülük ve toplam yerel kayıp katsayısı girdileri.
- Darcy–Weisbach ile boru sürtünme kaybı; laminer akışta 64/Re, türbülanslı akışta Swamee–Jain yaklaşımı.
- Her segment için hız, Reynolds sayısı, boru kaybı, yerel kayıp ve toplam kayıp çıktısı.
- Kaynak düğümünden terminale giden yolların taranması ve en yüksek basınç kayıplı kritik yolun raporlanması.
- Örnek dallanmış devre yükleme ve İngilizce arayüz metinleri.

## Mühendislik sınırları
- Debiler kullanıcı tarafından her segmente girilir; ağ debi dağılımı, otomatik hidronik dengeleme, vana ön ayarı ve kontrol otoritesi çözülmez.
- Model tek fazlı, dairesel boru ve sabit akışkan özellikleri varsayar. Glikol karışımlarında yoğunluk ve viskozite tasarım sıcaklığında kullanıcı tarafından girilmelidir.
- ΣK fitting/armatür toplamıdır; aynı kaybı eşdeğer uzunluk ve ΣK ile çift saymayın.
- Pompa ön seçimi için kritik yol basınç kaybına terminal/cihaz ve kontrol elemanı üretici kayıpları ayrıca eklenmelidir.
- Kapalı devre sistemlerde statik bina yüksekliği normalde pompa diferansiyel basınç gereksinimine eklenmez.
- Bu modül ön boyutlandırma aracıdır; saha/proje onayı ve bağımsız mühendislik doğrulaması gerektirir.

## Sürüm
- versionName: 13.6.37
- versionCode: 67
- applicationId: com.hvacpro.app
