# HVAC PRO 13.6.38 – Başlangıç ve şehir verisi dayanıklılık düzeltmesi

- 81 il iklim verisi artık ana HTML içine gömülü; WebView yerel dosya yüklemesine bağımlılık kaldırıldı.
- İklim verisi doğrulama hatası artık uygulamanın tüm JavaScript başlangıcını durdurmuyor.
- Şehir seçimi ve alt menülerin başlangıç akışının tek bir harici veri dosyası yükleme hatasıyla kilitlenmesi önlendi.
- 13.6.37 hidronik devre modülü korunmuştur.
