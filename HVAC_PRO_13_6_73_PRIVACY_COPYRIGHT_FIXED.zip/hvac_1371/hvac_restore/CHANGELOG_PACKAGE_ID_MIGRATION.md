# Package ID migration

- Previous unpublished package ID: `com.hvacpro.app`
- New package ID: `com.hvacpro.engineering`
- Updated Android `namespace`, `applicationId`, Kotlin package declaration/source path, QA references, and release instructions.
- App version remains 13.6.73 (versionCode 100); this app has not been published under the old ID.
- Before creating the Play Console app, verify that `com.hvacpro.engineering` is available. Package IDs are globally unique and cannot be renamed after app creation.
