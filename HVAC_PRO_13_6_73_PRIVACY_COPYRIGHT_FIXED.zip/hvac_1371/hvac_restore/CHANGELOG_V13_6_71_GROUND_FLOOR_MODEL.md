# HVAC PRO 13.6.71 – Zemin ısı geçişi iyileştirmesi

- Toprak / komşu hacim sıcaklığı girişi ortak yapı elemanları bölümüne taşındı; aynı değer soğutma ve ısıtma ön hesaplarında kullanılır.
- Soğutma zemin iletimi artık dış hava sıcaklığı farkını kullanmıyor. Zemin kaynaklı pozitif soğutma kazancı `A × U × max(0, Tground − Tin)` ile hesaplanıyor.
- Isıtma zemin iletimi mevcut `A × U × max(0, Tin − Tground)` yaklaşımını koruyor.
- Toprakla temas eden döşemelerde gerçek çevre/kenar etkileri için özel zemin yöntemi gerekliliği arayüz notunda açıklandı.
- Bağımsız soğutma referans vektörü yeni zemin davranışına göre güncellendi.
- Web ve Android WebView varlıkları eşitlendi. Paket adı değiştirilmedi.

## Doğrulama kapsamı

- `node scripts/qa_validate.js`: başarılı.
- `python3 scripts/qa_validate_project.py`: başarılı.
- Android gerçek cihaz testi ve APK/AAB yeniden derlemesi bu kaynak paketi için yapılmadı.
