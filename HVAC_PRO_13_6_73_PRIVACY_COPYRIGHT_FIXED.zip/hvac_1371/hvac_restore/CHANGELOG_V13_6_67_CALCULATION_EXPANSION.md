# HVAC PRO 13.6.67 – Calculation expansion

## Calculation-related changes
- Added per-zone cooling-load input to the automatic duct/AHU workspace.
- Added AHU preliminary cooling-capacity assistant: sums zone cooling loads, calculates outdoor-air enthalpy load from airflow, outdoor/indoor dry-bulb and RH plus barometric pressure, applies configurable safety margin, and compares selected unit capacity and airflow against the required values.
- Added input validation for the AHU assistant and explicit notes against double-counting outdoor-air load and for manufacturer selection checks.
- Added add/remove-last-zone controls and removed the former 30-zone limit from new and restored project workspaces (bounded to 500 for practical UI safety).
- Added an independent numerical reference test for AHU capacity sizing.
- Preserved existing cooling/heating, psychrometric, outdoor-air, altitude-pressure, duct Churchill friction, hydronic Darcy-Weisbach/Swamee-Jain and critical-path calculations.
- Updated Android WebView assets and service-worker cache version.
- Android versionCode 94, versionName 13.6.67.

## QA
- `node scripts/qa_validate.js`: PASS (all checks)
- `python3 scripts/qa_validate_project.py`: PASS (all checks)
- Combined inline JavaScript `node --check`: PASS
- Web and Android packaged `index.html`/assets synchronized.
- ZIP integrity: verified after packaging.

## Limitations / not claimed complete
- AHU result is preliminary: it does not replace manufacturer selection software, coil entering/leaving air calculations, water-side selection, fan heat, altitude/capacity correction or acoustic checks.
- Existing room cooling/heating engine remains a simplified preliminary model; it is not an hourly dynamic building simulation and does not implement a full thermal-mass/time-series solar model.
- Duct auto-layout remains a branched schematic and not a general graph/network solver; fittings are represented by entered ΣK.
- Climate starter profiles are not certified design-day data.
- Android Gradle build, lint and real-device execution were not run in this environment.
