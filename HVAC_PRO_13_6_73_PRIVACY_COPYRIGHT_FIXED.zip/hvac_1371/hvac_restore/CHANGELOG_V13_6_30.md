# HVAC PRO 13.6.30

## Psychrometric mixing correction
- Replaced the ambiguous second-air percentage with an independent second-air volumetric flow input (m³/h).
- First and second inlet dry-air mass flows are calculated from each inlet state and its own dry-air density at the shared atmospheric pressure.
- Mixed humidity ratio and enthalpy are mass-weighted on a dry-air basis.
- Results show inlet volume flows, each dry-air mass flow, total dry-air mass flow and equivalent volume flow at the mixed state.
- Updated Turkish and English labels and QA assertions.

This remains a moist-air balance / preliminary engineering calculation; real duct leakage, fan heat, pressure differences and measurement uncertainty are not included.
