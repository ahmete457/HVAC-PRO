# HVAC PRO 13.6.61

## Critical navigation fix
- Removed a duplicate global `TURKISH_PROVINCES` declaration that caused a browser JavaScript parse error.
- The parse error prevented the main application initialization script from running, so navigation buttons and other controls were unresponsive.
- Kept the single canonical 81-province list used by the Türkiye-only location selector.
- Synchronized the corrected web interface and supporting assets into the Android WebView assets.
- Increased Android versionCode to 90 and versionName to 13.6.61.

## Validation
- All inline JavaScript blocks parse individually.
- Combined inline JavaScript parses without duplicate top-level declarations.
- Android WebView `index.html` is byte-identical to the web interface.
- ZIP integrity and project XML checks are run separately.
- A live Chromium/WebView device test and APK build are not claimed in this environment.
