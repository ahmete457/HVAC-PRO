# QA 13.6.64

- Kaynak JSON: 81 kayıt, 81 benzersiz il merkezi.
- Her kayıtta rakım, legacy yaz DB başlangıcı ve legacy dış RH başlangıcı mevcut mu? Kontrol edilmelidir; null olan alanlar boş kalır.
- Basınç rakımdan standart atmosfer bağıntısıyla hesaplanır; ölçülmüş MGM basıncı olarak sunulmaz.
- Tasarım DB/WB ve kış tasarım sıcaklıkları null bırakılır; yaklaşık kış başlangıcı açıkça ön kabul olarak işaretlenir.
- Android/Web iklim JS ve HTML dosyaları eşitlenmiştir. Gerçek Android cihaz testi yapılmadı.
