# HVAC PRO 13.6.52 — Global climate + calculation QA

- Added global city/region search adapter through the licensed HVAC PRO climate gateway.
- Added gateway contract for 1991–2020 ERA5 daily archive retrieval by selected coordinates; the feature remains disabled until the licensed gateway URL is configured.
- Added explicit model-derived screening labels and source/period/coordinate provenance; no claim of ASHRAE-equivalent design data.
- Added Android INTERNET permission for HTTPS gateway requests; no free non-commercial API endpoint is called directly.
- Refactored cooling and heating calculations into pure calculation functions for independent reference-vector QA.
- Ceiling height now drives room volume and air-change-rate display and is included in print report metadata; it does not silently alter load equations.
- Tightened ceiling-height validation (1.5–20 m). Existing SHGC/shading/temperature/negative-flow validation retained.
- Version bumped to 13.6.52 / versionCode 82; CI artifact name updated.

Limitations: Android APK build/device test is still required. Global ERA5 values are daily model-derived screening estimates, not hourly ASHRAE design conditions. ASHRAE station data requires licensed integration. Open-Meteo historical/climate API requires a commercial Professional-or-higher plan; the app does not embed API keys.
