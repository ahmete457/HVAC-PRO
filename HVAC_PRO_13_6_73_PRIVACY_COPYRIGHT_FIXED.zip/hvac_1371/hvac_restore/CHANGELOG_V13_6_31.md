# HVAC PRO 13.6.31

## Psychrometric mixing fix
- Added mixed-state dry-air density to the psychrometric state reconstructed from temperature and humidity ratio.
- Prevented invalid or non-positive mixed-state density from propagating into the equivalent volume-flow result.
- Added regression checks for finite mixed-state equivalent airflow and approximate conservation of inlet volume flow for the 30 °C / 50% RH at 1000 m³/h plus 20 °C / 50% RH at 300 m³/h reference case.

This is a source-level fix. Android Gradle build and physical-device verification are still required.
