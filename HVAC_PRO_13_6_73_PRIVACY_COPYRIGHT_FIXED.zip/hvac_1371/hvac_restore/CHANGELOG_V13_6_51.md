# HVAC PRO 13.6.51

- Android versionCode: 81
- Added a unified multi-discipline report appendix to the existing print/PDF report.
- The appendix includes currently calculated outputs from fresh air, psychrometric processes, fan/pump, air terminals, duct paths, pressure/altitude, automatic duct network, hydronic network, capacity and VRF modules when those outputs are present.
- Module outputs are captured as plain text at report time to avoid injecting module HTML into the print report.
- Retained V13.6.50 project workspace save/restore: controls, hydronic segments, automatic duct room inputs, manual duct drawing, and heating calculation state.
- Existing old project records continue to load through the legacy values path.
- This is a source update; APK must be built and tested through GitHub Actions and on a real Android device.
