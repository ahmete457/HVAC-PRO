# HVAC PRO — Türkiye / MGM kapsam güncellemesi (13.6.60)

## Yapılan değişiklikler
- Konum seçimi Türkiye ile sınırlandırıldı.
- İl seçimi yalnızca 81 il merkezini içerir; ilçe ve yabancı şehir araması arayüzden kaldırıldı.
- Photon / OpenStreetMap şehir arama bağımlılığı kaldırıldı.
- Hesap raporlarında ülke/ilçe yerine il merkezi gösterilir.
- MGM'nin resmî il istatistikleri bağlantısı tasarım koşulları bilgilendirmesine eklendi.
- Rakımdan basınç hesabı standart atmosfer tahmini olarak korunur; ölçülmüş istasyon basıncı gibi sunulmaz.

## Veri doğruluğu notu
MGM'nin kamuya açık il istatistikleri aylık ortalama sıcaklık, aylık ortalama en yüksek/en düşük sıcaklık, güneşlenme ve yağış gibi iklim özetlerini yayımlar. Bunlar HVAC tasarım günü sıcaklıkları değildir. Bu sürüm, 81 il için doğrulanmış tasarım sıcaklığı / bağıl nem / istasyon rakımı veri seti içerdiğini iddia etmez. MGM'de kamuya açık olmayan veya aynı formatta yayımlanmayan alanlar uydurulmamış; mevcut tasarım sıcaklığı ve nem girişleri kullanıcı tarafından kaynak gösterilerek doldurulacak şekilde bırakılmıştır.

Resmî kaynak: https://www.mgm.gov.tr/veridegerlendirme/il-ve-ilceler-istatistik.aspx

## Kontroller
- [x] Kaynakta il listesi 81 kayıt.
- [x] Yabancı şehir arama / Photon çağrısı kaldırıldı.
- [x] İlçe girişi kullanıcı arayüzünden kaldırıldı (eski kayıt uyumluluğu için gizli alan korundu).
- [x] Rapor metadatasında il merkezi kullanılıyor.
- [ ] Android APK derlemesi ve cihaz testi bu ortamda yapılmadı.
- [ ] MGM'nin 81 il aylık istatistik tablosu henüz uygulama içine veri seti olarak gömülmedi.
