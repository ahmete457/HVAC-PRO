# HVAC PRO 13.6.70

- Soğutma/ısıtma hesaplama çalışma alanındaki “Menfez/difüzör standart ölçü önerisi” kartı kaldırıldı.
- Kartın yalnızca bu ekrana ait JavaScript olayları, dil güncellemesi ve rapor eki bağlantısı temizlendi.
- Kanal ve hava dağıtımı tasarım araçlarının diğer bölümleri korunmuştur.
- Android WebView asset dosyası web kaynak dosyasıyla eşitlendi.
- Sürüm: versionCode 97, versionName 13.6.70.

Doğrulama: `node scripts/qa_validate.js`, `python3 scripts/qa_validate_project.py` ve ZIP bütünlük kontrolü başarılıdır. Gerçek Android cihazında ekran testi ve APK derlemesi bu kontrolde yapılmamıştır.
