# HVAC PRO 13.6.29

## Advanced psychrometric processes
- Added a dedicated process calculator within the existing psychrometric analysis panel.
- Supports dry-air-mass-weighted mixing of two user-defined air streams. The user enters total airflow and the second stream volume-flow fraction.
- Supports ideal sensible heating at constant humidity ratio.
- Supports cooling/dehumidification to a user-defined leaving dry-bulb temperature and relative humidity.
- Supports humidification and dehumidification state changes with calculated water transfer rate.
- Reports outlet dry-bulb temperature, relative humidity, humidity ratio, enthalpy, enthalpy change, thermal duty and water transfer where applicable.
- Added Turkish/English labels and input-range/process-direction validation.

## Engineering assumptions and limits
- Dry-air mass flow is estimated from the moist-air state and entered volumetric flow. Mixing is weighted by dry-air mass, not by simple temperature averaging.
- Heating is ideal and sensible at constant humidity ratio. Cooling/dehumidification is a state-to-state enthalpy balance; no coil bypass factor or apparatus dew point is inferred.
- Humidification water demand assumes the specified outlet state is achieved; it does not model steam energy or spray efficiency.
- This is a preliminary engineering calculator. Validate psychrometric properties, equipment performance, process limits and applicable standards for final design.
- Google Play Billing remains unintegrated. Professional tools remain available only in Debug QA builds.
