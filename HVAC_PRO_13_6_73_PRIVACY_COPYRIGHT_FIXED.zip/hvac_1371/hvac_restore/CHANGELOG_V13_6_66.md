# HVAC PRO 13.6.66 — Hesap motoru iyileştirmesi

- Kanal basınç kaybı, otomatik kanal ağı ve fan/pompa boru aracında ortak Darcy sürtünme faktörü fonksiyonu kullanıldı.
- Churchill tüm rejim korelasyonu eklendi; çok düşük Reynolds sayısında laminer 64/Re yaklaşımı korunuyor.
- Geçiş bölgesindeki akışlar için fiziksel olarak sınırlı ve sürekli sürtünme faktörü hesabı sağlandı.
- 81 il iklim başlangıç verisi Android çevrimdışı paketinde korunuyor; tasarım koşullarının doğrulanmadığı uyarısı devam ediyor.
- Service Worker önbelleğine iklim JS dosyası eklendi ve önbellek sürümü artırıldı.
- Android versionName 13.6.66, versionCode 93.
