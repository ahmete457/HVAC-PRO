# HVAC PRO 13.6.62 QA Notes

## Source-level checks performed
- Legacy duplicate `airRouteEditor` markup removed.
- Legacy `airRouteCanvas` event script removed.
- Dedicated 2D Duct Design Studio remains and is opened when the duct discipline is entered from the discipline hub or top navigation.
- Redundant studio launch button removed.
- Duct-only project actions are CSS-scoped to the duct panel.
- Province selection clears prior site-specific weather inputs.
- Shared placeholder climate defaults (35 C, 45% RH, 938 m, 90500 Pa) removed from the main project form.
- Explicit notice states that verified MGM values for all 81 provinces are not bundled yet.
- Web and Android asset HTML files are byte-identical.

## Validation results
- Inline JavaScript syntax: passed.
- Main source structural checks: passed except pre-existing AHU capacity assistant assertion.
- Runtime HVAC QA script: existing AHU capacity assistant and unlimited-zone editor assertions remain failing; these were not changed as part of this correction.
- Android APK build: not run; this archive does not contain a Gradle wrapper (`gradlew`).

## Not verified
- No full 81-province MGM dataset is bundled; this release does not claim city-specific automatic climate loading.
- Android APK build and physical-device UI test were not run in this environment.
- Full HVAC engineering QA remains required before Play Store release.
