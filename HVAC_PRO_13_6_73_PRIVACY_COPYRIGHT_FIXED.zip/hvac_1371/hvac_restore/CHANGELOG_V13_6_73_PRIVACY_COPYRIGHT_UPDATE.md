# HVAC PRO 13.6.73 – Privacy and Copyright Update

- Rewrote the privacy policy in Turkish and English to reflect the current Android source: local project processing, no developer-operated project upload endpoint, no location permission/GPS collection, Android document picker backup, Android print/PDF flow, and current non-integrated Billing status.
- Removed the dormant SQLite Photon/OpenStreetMap city-cache bridge from `MainActivity.kt`; current release uses the Türkiye 81-province offline selector and makes no Photon geocoding request.
- Added bilingual `third-party-notices.html` and `THIRD_PARTY_NOTICES.txt`.
- Added Climate.OneBuilding TMYx attribution and the Malatya EPW five-year (2009–2013) quality limitation; it is explicitly not represented as official ASHRAE design weather.
- Clarified that OSM/Photon is not used by the current release; documented the ODbL attribution requirements if OSM is reintroduced.
- Added legal-notices link to the app footer and PWA cache; synchronized web and Android assets.
- Updated project QA to check privacy/legal text parity and removal of dormant Photon bridge.

## Validation
- `node scripts/qa_validate.js`: PASS
- `python3 scripts/qa_validate_project.py`: PASS
- Web/Android HTML asset SHA-256 parity: PASS
- Android build and runtime/device privacy inspection: NOT RUN in this environment.
