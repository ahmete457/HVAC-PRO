# HVAC PRO 13.6.34

## Kanal tasarımı ve hava dağıtımı
- Kanal ağı için çoklu hat basınç kaybı karşılaştırması ve kritik hat belirleme aracı eklendi. Her hat için Darcy-Weisbach düz kanal kaybı ve toplam yerel kayıp katsayısı kullanılır. Ortak kanal bölümleri her kola tekrar girilmemelidir.
- Menfez/difüzör ön boyutlandırma aracı eklendi: toplam debi, eleman adedi, hedef etkin alan hızı ve serbest alan oranından gerekli etkin/nominal alan hesaplanır; kullanıcı yüz alanı girerse gerçekleşen etkin alan hızı kontrol edilir.
- Mevcut kanal boyutlandırma ve basınç kaybı araçları korundu.
- Sürüm etiketleri 13.6.34 / versionCode 64 olarak güncellendi.

## Mühendislik sınırları
Bu araçlar ön boyutlandırma içindir. Terminal cihaz atış mesafesi, ses gücü, gerçek basınç kaybı ve üretici performans verileri kataloglardan doğrulanmalıdır. Kanal ağı karşılaştırması ortak hat kayıplarını otomatik birleştirmez; her yol için ortak bölümler yalnızca bir kez ve uygun şekilde hesaba katılmalıdır. Fan seçimi için filtre, serpantin, susturucu, damper ve terminal cihaz kayıpları da eklenmelidir.
