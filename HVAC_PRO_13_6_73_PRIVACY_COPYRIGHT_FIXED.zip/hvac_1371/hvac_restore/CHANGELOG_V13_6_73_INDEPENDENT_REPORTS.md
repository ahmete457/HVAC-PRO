# HVAC PRO 13.6.73 — Bağımsız hesap raporları

- Soğutma ve ısıtma yükleri artık ayrı PDF raporları üretir.
- Psikrometrik proses, fan/pompa, pompa çalışma noktası, cihaz kapasite kontrolü, çoklu mahal ve VRF hesapları için ayrı PDF rapor aksiyonları eklendi.
- Her rapor yalnızca seçilen modülün mevcut girdilerini ve hesap sonucunu içerir; başka disiplinlerin sonuçları rapora karıştırılmaz.
- Raporlar Android yerel Print/PDF köprüsünü kullanır; Android'de PDF olarak kaydetme akışı korunur.
- Önceden bulunan soğutma/ısıtma, taze hava, kanal ve hidronik bağımsız raporları korunmuştur.
- Sürüm: versionCode 100, versionName 13.6.73.

## Doğrulama sınırı
Bu sürümün kaynak ve statik QA kontrolleri çalıştırılmalıdır. Android APK/AAB derlemesi ve gerçek cihazda PDF kaydetme testi bu teslimatın parçası değildir.
