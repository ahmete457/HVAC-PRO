# HVAC PRO 13.6.42

## Dedicated Air Distribution Design panel
- Moved duct sizing, duct pressure loss, air-terminal preliminary sizing, and critical duct-path comparison out of the hidden Professional panel into a dedicated `airDesign` panel.
- Ventilation discipline tile now opens this standalone panel directly; it no longer scrolls to a Professional-only element.
- Added a return-to-main-HVAC-menu action.
- Removed Professional gating only from these four dedicated air-distribution tools. Other Professional features remain unchanged.
- Kept existing calculation implementations and element IDs so calculation handlers continue to work.

## Validation
- JavaScript syntax and project QA checks run. APK build and on-device testing are still required.
