# V13.6.73 – All modules unlocked build

- Enabled HVAC PRO Professional entitlement in this package for all app builds.
- Removed lock badges from the main HVAC discipline tiles.
- Heating, advanced psychrometrics, duct design, hydronic, fan/pump, equipment/AHU, VRF, project save/restore, and module PDF flows now pass the entitlement checks.
- Updated the Professional screen to state that all tools are open in this build.
- Kept Google Play Billing disabled; this package does not process purchases.
- Bumped the service-worker cache key so the updated interface is refreshed.
- Synchronized `web/index.html` with the Android WebView asset.
- QA: `node scripts/qa_validate.js` PASS; `python3 scripts/qa_validate_project.py` PASS.

Note: This is an all-features-unlocked source build for testing/use. It is not a billing-enabled commercial release.
