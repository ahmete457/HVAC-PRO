#!/usr/bin/env python3
"""Offline structural checks for the HVAC PRO Android source package."""
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def require(condition, message):
    if not condition:
        raise SystemExit(f"FAIL  {message}")
    print(f"PASS  {message}")

# Parse all Android XML resources and manifest.
xml_files = list((ROOT / "app/src/main").rglob("*.xml"))
require(bool(xml_files), "Android XML resources exist")
for path in xml_files:
    ET.parse(path)
require(True, f"All {len(xml_files)} Android XML files are well-formed")

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
ns = {"a": "http://schemas.android.com/apk/res/android"}
app = manifest.find("application")
require(app is not None, "Android manifest contains application")
activity = app.find("activity")
require(activity is not None and activity.attrib.get("{http://schemas.android.com/apk/res/android}exported") == "true", "Launcher activity is explicitly exported")

# Check Android/Gradle compatibility and version alignment.
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
require('versionCode = 91' in gradle and 'versionName = "13.6.62"' in gradle, "Android versionCode/versionName match V13.6.62")
require('compileSdk = 36' in gradle and 'targetSdk = 36' in gradle and 'minSdk = 23' in gradle, "Android SDK targets are explicitly configured")
root_gradle = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
require('com.android.application") version "8.10.1"' in root_gradle and 'org.jetbrains.kotlin.android") version "2.0.21"' in root_gradle, "Android Gradle Plugin and Kotlin plugin versions are present")

# Ensure winter design temperature remains editable for all users while heating stays Professional-gated.
html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
require('id="winterTout"' in html and 'min="-60"' in html and 'max="25"' in html and 'step="0.1"' in html, "Winter design temperature accepts negative values from -60 to 25 C")
require("$('winterTout').disabled=!HVAC_PRO_ENTITLED;" not in html and "requireProfessional('Isıtma hesabı')" in html, "Winter temperature input is editable while heating calculation remains Professional-gated")

# Validate advanced psychrometric process UI and calculations are included.
require('id="psychroProcessCard"' in html and all(f'id="{x}"' in html for x in ["psychroProcess", "psychroProcessCalc", "psychroSourceT", "psychroMixFlow"]), "Advanced psychrometric process controls are present")
require("function psychroSolveTemperature(h,w)" in html and "m1*a.w+m2*c.w" in html and "heatKW=mdot*(b.h-a.h)" in html, "Psychrometric mixing and process energy balances are implemented")
require(all(f'id="{x}"' in html for x in ["airDistributionTool", "adFlow", "adCalculate", "ductPathTool", "dpAdd", "dpCalculate"]), "Air-terminal sizing and duct critical-path tools are present")
require("const critical=results.reduce" in html and "required=q/v*1e4" in html, "Air distribution area and duct path pressure-loss calculations are implemented")
require('id="airDesign"' in html and 'id="airDesignBack"' in html, "Dedicated air distribution design panel is present")
require(all(x in html for x in ['id="daDensity"','id="daRough"','id="daVisc"','id="daSegmentResults"','data-key="sm"','data-key="sb"','data-key="rm"','data-key="rb"']), "Automatic duct design includes editable main/branch lengths and friction inputs")
require(all(x in html for x in ['data-key="skm"','data-key="skb"','data-key="rkm"','data-key="rkb"','function makeRowsTable(rows,kind)','const local=(sz,K)=>','sRows.critical.dp','rRows.critical.dp']), "Automatic ducts include local fitting-loss coefficients and critical-path aggregation")
require("target==='ventilation'" in html and "setActivePanel('fresh')" in html, "Ventilation hub opens the dedicated fresh-air workspace page")
require("requireProfessional('Kanal boyutlandırma')" not in html and "requireProfessional('Hava dağıtım elemanı')" not in html, "Dedicated air design sizing tools are accessible without the hidden Professional panel")

# Validate country/city selection without bundled climate datasets or a climate API.
require('const TURKISH_PROVINCES=' in html and 'id="country"' in html and 'id="city"' in html, "Country selector and offline Turkish province list are present")
require('const TURKISH_PROVINCES=' in html and 'https://www.mgm.gov.tr/veridegerlendirme/il-ve-ilceler-istatistik.aspx' in html and '81 il merkezi' in html and 'photon.komoot.io' not in html, 'Türkiye-only 81 province-centre selection uses MGM as the public reference and has no foreign lookup')
require('81 il için doğrulanmış MGM iklim değerleri' in html and 'aynı varsayımsal değer gösterilmez' in html, 'Missing per-province MGM data is disclosed and shared defaults are not represented as city climate')
require('globalPlaceSearch' not in html and 'HVAC_PRO_CLIMATE_API_BASE' not in html and 'globalClimatePanel' not in html, "Global climate gateway UI and API calls are removed")
require(not (ROOT / 'app/src/main/assets/climate-data-tr.json').exists() and not (ROOT / 'app/src/main/assets/climate-provider-config.js').exists(), "Bundled climate datasets and global climate configuration are removed")
require('id="calcWorkspace" hidden' in html and 'id="calcWorkspaceBack"' in html and 'function showCalcHub()' in html, "Main menu opens a separate calculation workspace page with back navigation")
require("openCalcWorkspace(target)" in html and "$('disciplineHub').hidden=true" in html, "Discipline selection hides the hub and opens its workspace view")
require('data-hvac-jump="duct"' in html and "target==='duct'" in html and "setActivePanel('airDesign')" in html, "Duct design has its own main-menu page")
require('window.hvacOpenDuctStudio=open' in html and 'id="openDuctStudio"' not in html and 'id="airRouteEditor"' not in html, "Duct page opens the dedicated 2D studio directly without duplicate drawing UI")
require('data-return-hub' in html and "document.addEventListener('click',e=>{if(e.target.closest('[data-return-hub]'))showCalcHub();})" in html, "Dedicated workspaces include a return-to-main-menu action")

# Native bridge safeguards and GitHub Actions workflow checks.
kotlin = (ROOT / "app/src/main/java/com/hvacpro/app/MainActivity.kt").read_text(encoding="utf-8")
require("BuildConfig.DEBUG" in kotlin, "Professional debug test bridge is tied to BuildConfig.DEBUG")
require("class CityCache" in kotlin and "CREATE TABLE cities" in kotlin and "searchCachedCities" in kotlin and "cacheCity" in kotlin, "Native SQLite city cache and JavaScript bridge are implemented")
require("const TURKISH_PROVINCES=" in html and "populateCountryCities('TR')" in html and 'worldCitySearchButton' not in html, 'Offline Turkish province-centre selector is used without global city search')
require("const HVAC_PRO_ENTITLED = HVAC_PRO_DEBUG_BUILD" in html, "Professional QA entitlement is enabled only for native debug builds")
require("function calculateHeatingLoad(x)" in html and "window.lastHeating={" in html, "Heating calculation implementation is active for QA")
require("PrintManager" in kotlin and "createPrintDocumentAdapter" in kotlin, "Native Android PDF print bridge is present")
require("Intent.ACTION_CREATE_DOCUMENT" in kotlin and "Intent.ACTION_OPEN_DOCUMENT" in kotlin, "Native Android JSON backup save/open pickers are present")
require("contentResolver.openOutputStream(uri)" in kotlin and "contentResolver.openInputStream(uri)" in kotlin, "Native JSON backup writes and reads selected document URIs")
require("window.Android.exportProjects(json)" in html and "window.Android.importProjects()" in html, "Web UI invokes Android JSON backup bridge")
require("function captureWorkspaceState()" in html and "function restoreWorkspaceState(workspace)" in html, "Complete engineering workspace capture/restore is implemented")
require("hydronicSegments" in html and "airRooms" in html and "manualDuctDrawing" in html, "Project state includes hydronic segments, automatic duct terminals and manual duct drawing")
require("workspace.heatingCalculated" in html and "runHeatingProfessional()" in html, "Saved heating calculation is recalculated when a project is restored")
require("HVACPRO_PROJECT_BACKUP" in html and "mergeImportedProjects" in html and "keys.has(k)" in html, "JSON import validates format and skips duplicate projects")
require("localStorage.setItem('hvacpro_projects'" in html and "localStorage.getItem('hvacpro_projects'" in html, "Project records persist in WebView local storage")
require('file:///android_asset/index.html' in kotlin, "Android WebView loads the packaged local app asset")
require(any(x.attrib.get('{http://schemas.android.com/apk/res/android}name') == 'android.permission.INTERNET' for x in manifest.findall('uses-permission')), 'Android INTERNET permission is present for app network functions')
require('function calculateRoomCoolingLoads(x)' in html and 'function calculateHeatingLoad(x)' in html, "Cooling and heating calculation engines are isolated for reference QA")
require('roomVolumeInfo' in html and "roomVolume=n('area')*n('height')" in html, "Ceiling height is used for room volume and ACH reporting")
require("climate-provider-config.js" not in (ROOT / 'app/src/main/assets/sw.js').read_text(), 'Service worker does not load an external climate provider config')
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
for token in ["scripts/qa_validate.js", "assembleDebug", "bundleRelease", "lint", "actions/upload-artifact@v4"]:
    require(token in workflow, f"GitHub Actions workflow includes {token}")
require("id: signing" in workflow and "steps.signing.outputs.available == 'true'" in workflow, "Release signing is optional and conditional; debug build is independent")
require("if-no-files-found: warn" in workflow, "Debug artifact can be uploaded when release signing is not configured")
print("\nAndroid project structural checks completed.")

duct_html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
for equipment_id in ["daSFilter","daRFilter","daSCoil","daRCoil","daSHru","daRHru","daSSilencer","daRSilencer","daSOther","daROther","daSSafety","daRSafety"]:
    require(f'id="{equipment_id}"' in duct_html, f"duct equipment loss input {equipment_id} exists")
require("sFanBase=sRows.critical.dp+sEq" in duct_html and "rFanBase=rRows.critical.dp+rEq" in duct_html, "separate supply and return fan ESP preselection includes equipment pressure drops")

require('id="engineeringReportAppendix"' in html, "Unified multi-discipline report appendix is present")
require("function buildEngineeringReportAppendix()" in html and "buildEngineeringReportAppendix();" in html, "Unified engineering report is generated from current module results")

require('id="country"' in html and 'id="city"' in html and 'populateCountryCities' in html and 'photon.komoot.io' not in html, 'Türkiye-only province-centre selector is present; foreign city lookup is removed')
require(all(x in html for x in ['data-tab="airDesign"','data-tab="hydronic"','data-module-save="duct"','data-module-save="hydronic"','data-module-pdf="duct"','data-module-pdf="hydronic"']), "Duct and hydronic modules have dedicated navigation, save and PDF actions")
require("hvacpro_module_projects_" in html and "print-module-hydronic" in html and "print-module-duct" in html, "Discipline-specific project storage and PDF print scopes are implemented")

require('data-module-save="fresh"' in html and 'data-module-pdf="fresh"' in html and 'id="freshSavedList"' in html, "Fresh-air module has independent save, open list and PDF report controls")
require("moduleProjects:{loads:getModuleProjects('loads'),fresh:getModuleProjects('fresh'),hydronic:getModuleProjects('hydronic'),duct:getModuleProjects('duct')}" in html, "JSON project backup includes separate discipline workspaces")

require('id="ahuSizeCheck"' in html and 'data-key="cool"' in html, "AHU capacity preselection uses per-room cooling loads and airflow")
require('id="airRouteEditor"' not in html and 'id="airRouteCanvas"' not in html, "Duplicate legacy duct drawing editor is removed")
require('id="daAddRoom"' in html and 'id="daRemoveLastRoom"' in html and 'da-remove-room' in html and "Math.min(30" not in html and not re.search(r'id="daCount"[^>]*max=', html), "Duct design supports dynamically added and removed zones without a fixed 30-zone cap")
