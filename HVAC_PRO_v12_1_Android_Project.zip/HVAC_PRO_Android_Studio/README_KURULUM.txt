HVAC PRO — Android Studio kaynak projesi
==========================================

Bu paket derlenmiş APK değildir; Android Studio kaynak projesidir.
Bu çalışma sürümünde:
- Türkçe / İngilizce dil seçimi için ilk arayüz desteği
- Ücretsiz temel hesaplama ekranları
- Professional özellik tanıtım ekranı (ödeme henüz bağlı değildir)
- Soğutma yükü, taze hava, proje kaydetme ve yazdırma/PDF akışı

ÖNEMLİ:
Professional ekranı şu an yalnızca ürün taslağıdır. Google Play Billing,
abonelik/tek seferlik satın alma, gizlilik politikası, imzalama anahtarı,
Play Console kaydı ve mağaza gereklilikleri henüz entegre edilmemiştir.
Hesaplama sonuçları ön boyutlandırma içindir; mühendislik doğrulaması gerekir.

APK oluşturma:
1. Android Studio kurulu bir bilgisayarda bu klasörü aç.
2. Gradle Sync tamamlandıktan sonra Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk

Telefon-only kullanıcı için:
Bu projeye GitHub Actions derleme akışı eklenerek telefondan GitHub web arayüzüyle
APK derlemek mümkün hale getirilebilir. Google Play yayını için ayrıca Play Console
geliştirici hesabı gerekir.


V5 NOTU: Yapı elemanları için U değeri seçenekleri sadeleştirilmiştir. Listeden yalıtım seviyesini seçebilir veya Manuel değer gir seçeneğini kullanabilirsiniz. Ön seçimler yaklaşık değerlerdir; kesin proje değerleri yapı detaylarından doğrulanmalıdır.


V6 NOTU: Türkiye'nin 81 ili için yaklaşık dış hava sıcaklığı başlangıç değerleri eklendi. Bu değerler resmî/standart tasarım koşulu değildir; proje bazında meteoroloji veya kabul edilen tasarım iklim verileriyle doğrulanmalıdır. Cam güneş kazancı yön ve gölgeleme katsayısıyla yaklaşık düzeltilir. Taze hava yükü, entalpi kuru hava kütlesi bazında hesaplanacak şekilde güncellendi. Sıcaklık girişlerinde negatif değer desteği eklendi.

V9: Android WebView native PrintManager bridge eklendi. Raporu yazdır/PDF butonu Android yazdırma ekranını açar; hedef olarak 'PDF olarak kaydet' seçilerek dosya kaydedilebilir. Android cihazda gerçek çıktı testi yapılmalıdır.


V10: Yaz/kış tasarım koşulu alanları, ilçe/proje konumu, tasarım verisi kaynağı seçimi ve basınç kaynağı seçimi eklendi. Şehir profilleri ön kabul niteliğindedir; resmî meteorolojik tasarım verisi değildir. Kış sıcaklığı V10’da kayıt/raporlama girdisidir; ısıtma yükü hesabı henüz eklenmemiştir.

V11: Kış tasarım dış hava sıcaklığı girildiğinde yaklaşık ısıtma yükü ön hesabı gösterilir. Bu hesap; duvar, çatı, zemin, cam iletimi ve taze hava/infiltrasyon duyulur kaybını içerir. Zemin için dış hava farkı kullanımı basitleştirilmiştir; profesyonel proje hesabında döşeme/zemin ve komşu hacim koşulları ayrıca doğrulanmalıdır.

V11.1 düzeltmesi: Kış tasarım dış hava sıcaklığı alanı metin girişi olarak değiştirildi; negatif değerler ve virgüllü ondalık girişler (ör. -8,5) desteklenir.


V11.2 DÜZELTMELERİ
- Ekranda görünen hatalı \\n metni kaldırıldı.
- Kış tasarım sıcaklığı boş bırakıldığında önceki ısıtma sonucu kayıt hafızasından temizlenir.


V12.0 – GOOGLE PLAY HAZIRLIK AŞAMASI
- compileSdk ve targetSdk 36 olarak güncellendi.
- Android Gradle Plugin 8.10.1 ve Gradle 8.11.1 kullanılır.
- GitHub Actions artık test için debug APK ve yayın hazırlığı için release AAB üretir.
- Üretilen release AAB henüz imzalı değildir; Google Play'e yüklemek için güvenli upload keystore/signing yapılandırması ayrıca yapılmalıdır.
- Google Play Billing henüz eklenmedi. Professional/ısıtma kilidi satın alma doğrulaması tamamlanana kadar etkinleştirilmemelidir.
- Ürün kimliği planı: hvac_pro_professional_lifetime (tek seferlik, tüketilmeyen ürün). Fiyat hedefi 349 TL; Play Console'da ayrıca tanımlanacaktır.


HVAC PRO V12.1
- Isıtma hesabı ücretsiz sürümde Professional kilidi arkasına alındı.
- Şehir değişince kış dış hava sıcaklığı için rakıma dayalı yaklaşık ön kabul değeri doldurulur.
- Bu değer resmî tasarım meteoroloji verisi değildir; mühendislik projesinde doğrulanmalıdır.
- Google Play Billing henüz entegre değildir; uygulama şu anda ödeme almaz.
- Version code: 15, version name: 12.1.
