#!/usr/bin/env python3
"""Offline structural checks for the HVAC PRO Android source package."""
import csv
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def require(condition, message):
    if not condition:
        raise SystemExit(f"FAIL  {message}")
    print(f"PASS  {message}")

# Parse all Android XML resources and manifest.
xml_files = list((ROOT / "app/src/main").rglob("*.xml"))
require(bool(xml_files), "Android XML resources exist")
for path in xml_files:
    ET.parse(path)
require(True, f"All {len(xml_files)} Android XML files are well-formed")

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
ns = {"a": "http://schemas.android.com/apk/res/android"}
app = manifest.find("application")
require(app is not None, "Android manifest contains application")
activity = app.find("activity")
require(activity is not None and activity.attrib.get("{http://schemas.android.com/apk/res/android}exported") == "true", "Launcher activity is explicitly exported")

# Check Android/Gradle compatibility and version alignment.
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
require('versionCode = 83' in gradle and 'versionName = "13.6.53"' in gradle, "Android versionCode/versionName match V13.6.53")
require('compileSdk = 36' in gradle and 'targetSdk = 36' in gradle and 'minSdk = 23' in gradle, "Android SDK targets are explicitly configured")
root_gradle = (ROOT / "build.gradle.kts").read_text(encoding="utf-8")
require('com.android.application") version "8.10.1"' in root_gradle and 'org.jetbrains.kotlin.android") version "2.0.21"' in root_gradle, "Android Gradle Plugin and Kotlin plugin versions are present")

# Ensure winter design temperature remains editable for all users while heating stays Professional-gated.
html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
require('id="winterTout"' in html and 'min="-60"' in html and 'max="25"' in html and 'step="0.1"' in html, "Winter design temperature accepts negative values from -60 to 25 C")
require("$('winterTout').disabled=!HVAC_PRO_ENTITLED;" not in html and "requireProfessional('Isıtma hesabı')" in html, "Winter temperature input is editable while heating calculation remains Professional-gated")

# Validate advanced psychrometric process UI and calculations are included.
require('id="psychroProcessCard"' in html and all(f'id="{x}"' in html for x in ["psychroProcess", "psychroProcessCalc", "psychroSourceT", "psychroMixFlow"]), "Advanced psychrometric process controls are present")
require("function psychroSolveTemperature(h,w)" in html and "m1*a.w+m2*c.w" in html and "heatKW=mdot*(b.h-a.h)" in html, "Psychrometric mixing and process energy balances are implemented")
require(all(f'id="{x}"' in html for x in ["airDistributionTool", "adFlow", "adCalculate", "ductPathTool", "dpAdd", "dpCalculate"]), "Air-terminal sizing and duct critical-path tools are present")
require("const critical=results.reduce" in html and "required=q/v*1e4" in html, "Air distribution area and duct path pressure-loss calculations are implemented")
require('id="airDesign"' in html and 'id="airDesignBack"' in html, "Dedicated air distribution design panel is present")
require(all(x in html for x in ['id="daDensity"','id="daRough"','id="daVisc"','id="daSegmentResults"','data-key="sm"','data-key="sb"','data-key="rm"','data-key="rb"']), "Automatic duct design includes editable main/branch lengths and friction inputs")
require(all(x in html for x in ['data-key="skm"','data-key="skb"','data-key="rkm"','data-key="rkb"','function makeRowsTable(rows,kind)','const local=(sz,K)=>','sRows.critical.dp','rRows.critical.dp']), "Automatic ducts include local fitting-loss coefficients and critical-path aggregation")
require("target==='ventilation'" in html and "x.id==='airDesign'" in html, "Ventilation hub opens the dedicated air design panel")
require("requireProfessional('Kanal boyutlandırma')" not in html and "requireProfessional('Hava dağıtım elemanı')" not in html, "Dedicated air design sizing tools are accessible without the hidden Professional panel")

# Validate the canonical JSON and its CSV companion.
climate = json.loads((ROOT / "app/src/main/assets/climate-data-tr.json").read_text(encoding="utf-8"))
require(climate.get("country") == "TR" and len(climate.get("cities", [])) == 81, "Canonical climate JSON contains 81 Turkish provinces")
with (ROOT / "weather-data/turkiye_81_il_on_kabul.csv").open(encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
require(len(rows) == 81, "Climate CSV contains 81 province rows")
by_city = {x["city"]: x for x in climate["cities"]}
all_city_data_matches = True
all_winter_values_unverified = True
for row in rows:
    city = row["il"]
    item = by_city.get(city)
    if item is None:
        all_city_data_matches = False
        all_winter_values_unverified = False
        continue
    all_city_data_matches &= (
        int(row["yaz_dis_hava_on_kabul_C"]) == item["legacy_summer_start_value_c"]
        and int(row["yaklasik_il_merkezi_rakimi_m"]) == item["elevation_m"]
        and int(row["dis_bagil_nem_on_kabul_pct"]) == item["legacy_outdoor_rh_start_value_pct"]
    )
    all_winter_values_unverified &= row["kis_tasarim_C"] == "" and item["winter_design_db_c"] is None
require(all_city_data_matches, "CSV summer, elevation and RH values match JSON for all 81 provinces")
require(all_winter_values_unverified, "Unverified winter design temperatures remain blank for all 81 provinces")

# Native bridge safeguards and GitHub Actions workflow checks.
kotlin = (ROOT / "app/src/main/java/com/hvacpro/app/MainActivity.kt").read_text(encoding="utf-8")
require("BuildConfig.DEBUG" in kotlin, "Professional debug test bridge is tied to BuildConfig.DEBUG")
require("const HVAC_PRO_ENTITLED = HVAC_PRO_DEBUG_BUILD" in html, "Professional QA entitlement is enabled only for native debug builds")
require("function calculateHeatingLoad(x)" in html and "window.lastHeating={" in html, "Heating calculation implementation is active for QA")
require("PrintManager" in kotlin and "createPrintDocumentAdapter" in kotlin, "Native Android PDF print bridge is present")
require("Intent.ACTION_CREATE_DOCUMENT" in kotlin and "Intent.ACTION_OPEN_DOCUMENT" in kotlin, "Native Android JSON backup save/open pickers are present")
require("contentResolver.openOutputStream(uri)" in kotlin and "contentResolver.openInputStream(uri)" in kotlin, "Native JSON backup writes and reads selected document URIs")
require("window.Android.exportProjects(json)" in html and "window.Android.importProjects()" in html, "Web UI invokes Android JSON backup bridge")
require("function captureWorkspaceState()" in html and "function restoreWorkspaceState(workspace)" in html, "Complete engineering workspace capture/restore is implemented")
require("hydronicSegments" in html and "airRooms" in html and "manualDuctDrawing" in html, "Project state includes hydronic segments, automatic duct terminals and manual duct drawing")
require("workspace.heatingCalculated" in html and "runHeatingProfessional()" in html, "Saved heating calculation is recalculated when a project is restored")
require("HVACPRO_PROJECT_BACKUP" in html and "mergeImportedProjects" in html and "keys.has(k)" in html, "JSON import validates format and skips duplicate projects")
require("localStorage.setItem('hvacpro_projects'" in html and "localStorage.getItem('hvacpro_projects'" in html, "Project records persist in WebView local storage")
require('file:///android_asset/index.html' in kotlin, "Android WebView loads the packaged local app asset")
require(any(x.attrib.get('{http://schemas.android.com/apk/res/android}name') == 'android.permission.INTERNET' for x in manifest.findall('uses-permission')), "Global climate API has Android INTERNET permission")
require('globalPlaceSearch' in html and 'HVAC_PRO_CLIMATE_API_BASE' in html and '/geocode?q=' in html and '/climate?' in html, "Global geocoding and ERA5 climate archive gateway UI are present")
require('archive-api.open-meteo.com' not in html and 'geocoding-api.open-meteo.com' not in html, "Commercial app avoids non-commercial free API endpoints")
require("globalPlaceSearch').disabled=!globalClimateConfigured" in html and "HVAC_PRO_CLIMATE_API_BASE = ''" in (ROOT / "app/src/main/assets/climate-provider-config.js").read_text(), "Global climate search is disabled until licensed gateway is configured")
require('function calculateRoomCoolingLoads(x)' in html and 'function calculateHeatingLoad(x)' in html, "Cooling and heating calculation engines are isolated for reference QA")
require('roomVolumeInfo' in html and "roomVolume=n('area')*n('height')" in html, "Ceiling height is used for room volume and ACH reporting")
require((ROOT / 'weather-data/GLOBAL_CLIMATE_DATA_POLICY.md').exists(), "Global climate source, licensing and quality policy is documented")
require((ROOT / 'weather-data/GLOBAL_CLIMATE_GATEWAY_CONTRACT.md').exists() and (ROOT / 'app/src/main/assets/climate-provider-config.js').exists(), "Licensed global climate gateway contract/config are present")
require("hvac-pro-v13-6-53" in (ROOT / 'app/src/main/assets/sw.js').read_text() and "climate-provider-config.js" in (ROOT / 'app/src/main/assets/sw.js').read_text(), "Service worker cache version and global climate config are updated")
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
for token in ["scripts/generate_climate_js.js", "scripts/qa_validate.js", "assembleDebug", "bundleRelease", "lint", "actions/upload-artifact@v4"]:
    require(token in workflow, f"GitHub Actions workflow includes {token}")
require("id: signing" in workflow and "steps.signing.outputs.available == 'true'" in workflow, "Release signing is optional and conditional; debug build is independent")
require("if-no-files-found: warn" in workflow, "Debug artifact can be uploaded when release signing is not configured")
print("\nAndroid project structural checks completed.")

duct_html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
for equipment_id in ["daSFilter","daRFilter","daSCoil","daRCoil","daSHru","daRHru","daSSilencer","daRSilencer","daSOther","daROther","daSSafety","daRSafety"]:
    require(f'id="{equipment_id}"' in duct_html, f"duct equipment loss input {equipment_id} exists")
require("sFanBase=sRows.critical.dp+sEq" in duct_html and "rFanBase=rRows.critical.dp+rEq" in duct_html, "separate supply and return fan ESP preselection includes equipment pressure drops")

require('id="engineeringReportAppendix"' in html, "Unified multi-discipline report appendix is present")
require("function buildEngineeringReportAppendix()" in html and "buildEngineeringReportAppendix();" in html, "Unified engineering report is generated from current module results")

require('id="country"' in html and 'id="city"' in html and 'populateCountryCities' in html, "Country-first cascading country / province selector is present")
require(all(x in html for x in ['data-tab="airDesign"','data-tab="hydronic"','data-module-save="duct"','data-module-save="hydronic"','data-module-pdf="duct"','data-module-pdf="hydronic"']), "Duct and hydronic modules have dedicated navigation, save and PDF actions")
require("hvacpro_module_projects_" in html and "print-module-hydronic" in html and "print-module-duct" in html, "Discipline-specific project storage and PDF print scopes are implemented")

require('data-module-save="fresh"' in html and 'data-module-pdf="fresh"' in html and 'id="freshSavedList"' in html, "Fresh-air module has independent save, open list and PDF report controls")
require("moduleProjects:{loads:getModuleProjects('loads'),fresh:getModuleProjects('fresh'),hydronic:getModuleProjects('hydronic'),duct:getModuleProjects('duct')}" in html, "JSON project backup includes separate discipline workspaces")
