/* Set this to the HTTPS base URL of the HVAC PRO climate gateway. Keep provider API keys on the server, never in the APK. */
window.HVAC_PRO_CLIMATE_API_BASE = '';
