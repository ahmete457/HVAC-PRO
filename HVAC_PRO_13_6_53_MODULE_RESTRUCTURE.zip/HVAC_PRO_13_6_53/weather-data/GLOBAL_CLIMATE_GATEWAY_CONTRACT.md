# HVAC PRO Global Climate Gateway contract

The Android app deliberately does not call Open-Meteo's free endpoints: the free service is non-commercial only. HVAC PRO needs a commercial Open-Meteo subscription with access to Historical Weather API (Professional tier or higher), or an equivalent licensed/self-hosted provider.

Configure `app/src/main/assets/climate-provider-config.js` with the HTTPS gateway base URL, e.g. `https://climate-api.your-domain.tld`. Do not put the Open-Meteo API key in the app.

## Endpoints
- `GET /geocode?q={search}` returns `{ "results": [{"name":"Tokyo","admin1":"Tokyo","country":"Japan","latitude":35.68,"longitude":139.69,"elevation":40}] }`.
- `GET /climate?latitude=35.68&longitude=139.69&start_date=1991-01-01&end_date=2020-12-31` returns `{ "elevation":40,"timezone":"Asia/Tokyo","daily":{"time":[...],"temperature_2m_max":[...],"temperature_2m_min":[...],"relative_humidity_2m_mean":[...]},"source":"Open-Meteo Historical Weather API / ERA5","source_url":"https://open-meteo.com/en/docs/historical-weather-api" }`.

The gateway must call the licensed customer API server-side, validate coordinates/date ranges, enforce rate limits, cache responses, and return CORS headers for the Android WebView origin. The app computes daily Tmax P99 and Tmin P01 as screening values only. Do not label these as ASHRAE station design conditions.
