# HVAC PRO — Küresel iklim verisi politikası

## Veri kaynakları ve lisans

1. **ASHRAE 2025 Climatic Design Data**: 12.424 küresel istasyon için tasarım verisi. HVAC PRO içinde ticari kullanım için ASHRAE geliştirici lisansı/veri lisansı alınmadan tasarım tabloları veya istasyon tasarım değerleri gömülmez. İstasyon verisi ve yıllık tasarım koşulları, doğrulanmış mühendislik kaynağı olarak kullanılacak birincil hedeftir.
2. **Open-Meteo Historical Weather API / ERA5**: küresel koordinat tabanlı tarihsel model verisi. Open-Meteo'nun ücretsiz API'si yalnızca ticari olmayan kullanım içindir; HVAC PRO ticari ürün olduğundan ücretsiz API uç noktaları uygulama içinde çağrılmaz. Ticari kullanım için uygun lisans/Professional plan gerekir; tarihsel, iklim ve ensemble API'leri Professional veya üzeri plan gerektirir.
3. **Climate.OneBuilding TMYx**: 17.300+ konum için tipik meteorolojik yıl (EPW) dosyaları. Saatlik enerji simülasyonu/ileri analiz için ayrı veri içe aktarma ve lisans/atıf incelemesiyle sonraki entegrasyon hedefidir; TMY dosyası doğrudan tasarım sıcaklık persentili yerine geçmez.
4. **WMO 1991–2020 normals**: ulusal meteoroloji kurumlarından toplanan istasyon normalleri; ülke ve istasyon bazında kapsam farklılıkları olabilir. İstasyon kaynak ve dönem metaverisi korunmalıdır.

## Uygulama davranışı
- Türkiye'nin 81 il profili çevrimdışı başlangıç seçeneği olarak kalır; mevcut yaz/kış ön kabulleri resmî tasarım verisi olarak sunulmaz.
- Küresel konum arama ve iklim arşivi, `climate-provider-config.js` içindeki `HVAC_PRO_CLIMATE_API_BASE` ile tanımlanan HVAC PRO HTTPS gateway üzerinden çalışır. Varsayılan değer boştur; gateway kurulmadan dış servise istek gönderilmez.
- Gateway API anahtarları APK içine konmaz. Open-Meteo müşteri API anahtarı yalnızca sunucu tarafında saklanır.
- Gateway sözleşmesi: `GET /geocode?q=...` -> `{results:[{name,admin1,country,latitude,longitude,elevation}]}`; `GET /climate?latitude=...&longitude=...&start_date=1991-01-01&end_date=2020-12-31` -> `{elevation,timezone,daily:{temperature_2m_max:[],temperature_2m_min:[],relative_humidity_2m_mean:[]},source,source_url}`. Gateway, lisanslı Open-Meteo müşteri API'sinden veri çeker.
- Günlük maksimum sıcaklık P99, günlük minimum sıcaklık P01 ve günlük ortalama bağıl nem medyanı yalnızca **model tabanlı ön tasarım taraması** olarak etiketlenir; bunlar saatlik ASHRAE tasarım yüzdeleri, eşzamanlı yaş termometre veya resmî istasyon tasarım koşulu değildir.
- Küresel model değerleri `weatherSource=manual` altında, kaynak, tarih aralığı ve koordinat metaverisiyle kaydedilir. Mühendislik nihai tasarımında yerel meteoroloji istasyonu, yürürlükteki standart ve lisanslı tasarım veri kaynağıyla doğrulama gerekir.
- Arayüzde Open-Meteo atıf bağlantısı gösterilir; API verisi CC BY 4.0 kapsamındadır. Ticari API kullanım hakkı, kullanım kotası ve attribution koşulları yayına çıkmadan önce teyit edilmelidir.

## Referans bağlantıları
- https://www.ashrae.org/technical-resources/bookstore/weather-data-center
- https://open-meteo.com/en/docs/historical-weather-api
- https://open-meteo.com/en/pricing
- https://open-meteo.com/en/terms
- https://climate.onebuilding.org/
- https://www.ncei.noaa.gov/products/wmo-climate-normals
