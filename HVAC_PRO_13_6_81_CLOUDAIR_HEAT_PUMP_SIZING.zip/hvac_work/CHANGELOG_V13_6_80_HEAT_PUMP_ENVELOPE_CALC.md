# HVAC PRO 13.6.80 – Hava-Su Isı Pompası Isı Kaybı Motoru

## Değişiklik
- Sabit W/m² varsayımına dayalı `alan × özgül yük` yaklaşımı, yapı elemanı bazlı iletim + hava değişimi hesabıyla değiştirildi.
- Girdiler: net dış duvar alanı/U, çatı-tavan alanı/U, zemin alanı/U, pencere alanı/U, dış kapı alanı/U, hava değişim sayısı, zemin eşdeğer sıcaklığı, ısıl köprü payı ve hesap payı.
- Hesap: Q = Σ(U·A·ΔT) + 0.33·n·V·ΔT + ısıl köprü ilavesi; zemin için ayrı eşdeğer zemin sıcaklığı kullanılır.
- Tasarım yükü, radyatör metre hesabı, yerden ısıtma kontrolü ve su debisi bu hesaplanan yükü kullanır.
- Boyler günlük enerji ve şarj gücü ayrı gösterilir; ısıtma yüküne otomatik eklenmez.
- İlçe tasarım sıcaklığı bulunmadığında il merkezinden gelen sıcaklık korunur.
- Eski sabit W/m² ve yalıtım seviyesi alanları kaldırıldı; hesaplama artık yüzey girdilerine dayanıyor.

## Varsayımlar / sınırlar
- U değerleri örnek başlangıç değerleridir; kullanıcı yapı detayına göre değiştirmelidir.
- Net dış duvar alanı, pencere ve kapılar düşüldükten sonra girilmelidir.
- Hava değişim sayısı, sızıntı/havalandırmanın basitleştirilmiş ön kabulüdür.
- Zemin iletimi U·A·(Ti−Tground) basitleştirmesidir; TS EN ISO 13370 detaylı hesabı değildir.
- Güneş ve iç kazançlar, oda bazlı ısı kaybı, ısı geri kazanımı, değişken komşu mahal sıcaklıkları ve detaylı lineer ısıl köprü hesabı dahil değildir.
- Isı pompası cihaz modeli seçilmez. Tasarım noktasında gerekli bina tarafı ısı çıkışı hesaplanır; cihazın gerçek kapasite/COP değeri üretici performans tablosundan kontrol edilmelidir.
- Radyatör metre sonucu, kullanıcının girdiği katalog ΔT50 kapasitesi ve n=1.3 yaklaşımına bağlı ön boyutlandırmadır.
- Yerden ısıtma yüzey W/m² değeri ve boru aralığı kullanıcı girdisidir; gerçek döşeme tasarımı ayrıca doğrulanmalıdır.

## QA
- `scripts/qa_validate.js`: PASS
- Inline JavaScript syntax: PASS
- ZIP integrity: pending archive creation
- Android APK build: not run in this environment.
- versionCode 107 / versionName 13.6.80
