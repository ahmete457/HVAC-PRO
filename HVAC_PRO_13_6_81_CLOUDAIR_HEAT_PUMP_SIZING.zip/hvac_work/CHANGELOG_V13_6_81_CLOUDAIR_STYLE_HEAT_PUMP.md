# HVAC PRO 13.6.81 – CloudAir yaklaşımında katalog bazlı ısı pompası boyutlandırma

## Değişiklikler
- Isı pompası boyutlandırmasına üç üretici katalog çalışma noktası eklendi: soğuk, orta ve ılık dış hava sıcaklıklarında kapasite ve COP.
- Üç nokta aynı gidiş suyu sıcaklığında girilmek zorunda; örnek cihaz eğrisi veya uydurma katalog verisi yoktur.
- Tasarım dış hava sıcaklığında cihaz kapasitesi ve COP doğrusal parçalı enterpolasyonla hesaplanır; veri aralığı dışında uç segment ekstrapolasyonu kullanılır.
- Bina yükü ile cihaz kapasite eğrisi karşılaştırılarak termodinamik denge noktası bulunur.
- Tasarım sıcaklığındaki yardımcı ısıtıcı ihtiyacı hesaplanır; kullanıcı isterse sabit yardımcı ısıtıcı kapasitesi girebilir.
- 0°C kapasite farkı ve denge noktasındaki COP raporlanır.
- Isıtma kapasitesi seçiminde soğutma yükü kullanılmaz.

## Önemli sınırlar
- Katalog verileri kullanıcı tarafından girilmelidir; marka/model performans verisi uygulamaya gömülmemiştir.
- Üç nokta arasında doğrusal enterpolasyon, uçlarda ekstrapolasyon yapılır. Defrost, kısmi yük, kompresör sınırları ve üreticiye özgü kapasite kontrolü modellenmez.
- Üç noktanın aynı gidiş suyu sıcaklığı ve aynı cihaz çalışma koşullarına ait olması gerekir.
- Mevcut bina ısı kaybı motorundaki basitleştirilmiş zemin/ısıl köprü kabulleri devam etmektedir; bu sürüm TS EN 12831 tam oda bazlı hesap değildir.

## QA
- Web ve Android HTML eşitliği kontrol edildi.
- JavaScript syntax ve proje QA sonuçları aşağıda doğrulanacaktır.
- Android APK build bu işlemde çalıştırılmamıştır.
