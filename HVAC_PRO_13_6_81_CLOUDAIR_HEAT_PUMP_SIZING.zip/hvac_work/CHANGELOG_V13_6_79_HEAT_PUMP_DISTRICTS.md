# HVAC PRO 13.6.79 – İlçe seçimi

- Isı Pompası modülüne ilçe seçimi eklendi.
- İlçe listeleri TurkiyeAPI 2025 idari veri setinden il bazında yüklenir (81 il / 973 ilçe).
- İndirilen her ilin ilçe listesi WebView localStorage önbelleğine alınır; aynı il tekrar seçildiğinde çevrimdışı kullanılabilir.
- İlçe için doğrulanmış ayrı kış tasarım sıcaklığı olmadığı için ilçe seçimi il sıcaklığını değiştirmez. İl merkezi tasarım sıcaklığı aynen korunur.
- İlçe verisi ilk kez yüklenirken internet gerekir. Bağlantı yoksa il sıcaklığı kullanılmaya devam eder ve kullanıcı bilgilendirilir.
- Hesaplama raporuna il/ilçe konumu eklendi.
- Sürüm: versionCode 106, versionName 13.6.79.
- Veri kaynağı: https://github.com/ubeydeozdmr/turkiye-api (MIT; 2025 district dataset).
