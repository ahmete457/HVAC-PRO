# HVAC PRO 13.6.75 – Standalone Air-to-Water Heat Pump Sizing

- Added a separate **Heat Pump / Isı Pompası** bottom-navigation menu and independent page.
- Added preliminary building heat-demand sizing from heated area and editable specific heat-loss density.
- Added radiator length estimate using entered catalogue output at ΔT50 and a stated exponent assumption (n=1.3).
- Added underfloor heating surface-output check and preliminary pipe-length estimate from active area and pipe spacing.
- Added hydronic design flow estimate from heating load and water-side ΔT.
- Added Turkish and English labels.
- Existing HVAC calculation modules and navigation remain separate.

## Engineering limitations shown in the UI

- City name does not automatically supply winter design temperature; user must enter a verified value.
- Area × W/m² is a preliminary sizing method, not a room-by-room transmission/ventilation heat-loss calculation.
- Radiator output must be replaced/verified with the selected radiator manufacturer's catalogue data.
- Underfloor output depends on floor construction, covering, pipe depth, spacing and water temperatures; the entered W/m² is an explicit assumption.
- No heat-pump COP, electrical input or manufacturer capacity curve is fabricated. Actual unit selection requires manufacturer performance data at the selected outdoor and leaving-water temperatures.
