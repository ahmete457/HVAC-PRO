# HVAC PRO 13.6.76 – Optional DHW cylinder sizing

- Added an optional domestic-hot-water / cylinder section inside the standalone Air-to-Water Heat Pump menu.
- Inputs: occupants, daily hot-water use per person, mains cold-water temperature, cylinder setpoint, recovery time and optional manually selected cylinder volume.
- Outputs: estimated daily DHW demand, daily energy (without tank/distribution losses), estimated cylinder volume, full-cylinder reheat energy and average charging output for the entered recovery time.
- DHW charging load is displayed separately and is not automatically added to the space-heating design load. Heat-pump DHW priority, coil output, hygiene control and backup strategy require project/manufacturer verification.
- Turkish and English labels added. Existing modules unchanged.
