# HVAC PRO 13.6.77 – Isı Pompası Şehir Seçimi

- Isı Pompası modülündeki serbest metin şehir alanı, Türkiye'nin 81 il merkezini içeren seçim listesine dönüştürüldü.
- Şehir seçimi proje konumunu tanımlar. Bu sürümde 81 il için doğrulanmış kış tasarım sıcaklığı bulunmadığından, seçim kış tasarım sıcaklığını otomatik olarak uydurmaz veya değiştirmez; kullanıcı proje için doğrulanmış değeri manuel girer.
- Şehir alanı Türkçe/İngilizce dil değişiminde güncellenir.
- Web ve Android WebView arayüz dosyaları eşitlendi.
- Sürüm: 13.6.77, versionCode 104.

## Doğrulama
- Inline JavaScript sözdizimi `node --check` ile kontrol edildi.
- Şehir seçicinin HTML alanı doğrulandı; eski serbest metin alanı kalmadı.
- Web ve Android asset HTML dosyalarının aynı olduğu doğrulandı.
- Android APK derlemesi bu pakette yapılmadı.
