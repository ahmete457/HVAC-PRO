# HVAC PRO 13.6.78 – Şehre bağlı kış tasarım sıcaklığı

- Isı Pompası menüsündeki il seçimi artık 81 ilin her biri için kış tasarım dış hava sıcaklığını otomatik doldurur.
- Değerler MGM 2024 il merkezi kış tasarım sıcaklıkları tablosundan alınmıştır (Gazi Üniversitesi tezindeki Çizelge 5.2).
- Kullanıcı, ilçe rakımı/proje koşulları nedeniyle gerekirse sıcaklığı manuel değiştirebilir.
- Bu tablo il merkezi referansıdır; belirli bir ilçe, rakım veya proje için kesin tasarım koşulu garantisi değildir.
- Diğer iklim modülünün doğrulanmamış iklim kayıtları değiştirilmemiştir.
- Sürüm: versionCode 105, versionName 13.6.78.
