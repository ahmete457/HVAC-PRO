#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'app/src/main/assets/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const jsonPath = path.join(root, 'app/src/main/assets/climate-data-tr.json');
const climate = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const climateJsPath = path.join(root, 'app/src/main/assets/climate-data-tr.js');
const climateJs = fs.readFileSync(climateJsPath, 'utf8');
const csv = fs.readFileSync(path.join(root, 'weather-data/turkiye_81_il_on_kabul.csv'), 'utf8').replace(/^\uFEFF/, '');

function pass(message) { console.log(`PASS  ${message}`); }
function near(actual, expected, tolerance, label) {
  assert.ok(Number.isFinite(actual), `${label}: result is not finite`);
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: expected ${expected} ± ${tolerance}, got ${actual}`);
}

// HTML structure and JavaScript syntax.
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const duplicateIds = ids.filter((id, i) => ids.indexOf(id) !== i);
assert.deepStrictEqual([...new Set(duplicateIds)], [], `Duplicate HTML IDs: ${[...new Set(duplicateIds)].join(', ')}`);
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
assert.ok(scripts.length > 0, 'No inline application script found');
for (const script of scripts) new vm.Script(script, { filename: 'index.html:inline-script' });
const allScript = scripts.join('\n');
const literalRefs = [...allScript.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(m => m[1]);
const missingRefs = [...new Set(literalRefs.filter(id => !ids.includes(id)))];
assert.deepStrictEqual(missingRefs, [], `JavaScript references missing DOM IDs: ${missingRefs.join(', ')}`);
pass('HTML IDs are unique; inline JavaScript parses; literal DOM references exist');

// City profiles are retained in the UI for offline WebView use. Keep them synchronized
// with the maintained JSON dataset until the native asset bridge is migrated.
new vm.Script(climateJs, { filename: 'climate-data-tr.js' });
const climateSandbox = { window: {} };
vm.runInNewContext(climateJs, climateSandbox);
assert.ok(climateSandbox.window.HVAC_CLIMATE_DATA, 'Generated climate data asset did not initialize');
assert.strictEqual(JSON.stringify(climateSandbox.window.HVAC_CLIMATE_DATA), JSON.stringify(climate), 'Generated JS climate data is stale; regenerate it from the JSON source');
const cityProfiles = Object.fromEntries(climate.cities.map(c => [c.city, [c.legacy_summer_start_value_c, c.elevation_m, c.legacy_outdoor_rh_start_value_pct]]));
assert.ok(allScript.includes('const cityProfiles=Object.fromEntries(climateRecords.map'), 'Application must derive city profiles from the generated climate data asset');
assert.ok(html.includes('<script src=\"climate-data-tr.js\"></script>'), 'Application must load the generated climate data asset');
assert.strictEqual(climate.schema_version, 1, 'Unexpected climate schema version');
assert.strictEqual(climate.country, 'TR', 'Climate country must be TR');
assert.strictEqual(climate.cities.length, 81, 'Climate JSON must contain 81 provinces');
assert.strictEqual(Object.keys(cityProfiles).length, 81, 'UI city profiles must contain 81 provinces');
const cityMap = new Map(climate.cities.map(c => [c.city, c]));
for (const [city, values] of Object.entries(cityProfiles)) {
  const record = cityMap.get(city);
  assert.ok(record, `City missing from JSON: ${city}`);
  assert.strictEqual(JSON.stringify(values), JSON.stringify([record.legacy_summer_start_value_c, record.elevation_m, record.legacy_outdoor_rh_start_value_pct]), `City profile mismatch: ${city}`);
  assert.strictEqual(record.design_weather_status, 'not_verified', `Unverified climate status changed: ${city}`);
  assert.strictEqual(record.summer_design_db_c, null, `Unverified summer DB must remain null: ${city}`);
  assert.strictEqual(record.summer_design_wb_c, null, `Unverified summer WB must remain null: ${city}`);
  assert.strictEqual(record.winter_design_db_c, null, `Unverified winter DB must remain null: ${city}`);
}
const csvRows = csv.trim().split(/\r?\n/);
assert.strictEqual(csvRows.length, 82, 'Climate CSV must contain header + 81 provinces');
pass('81-city JSON, CSV and offline UI profiles are consistent; unverified design values remain null');

// Extract the exact pure calculation functions used by the app and run reference vectors.
const functionNames = ['satPressure', 'moist', 'dewPoint', 'wetBulb', 'calculateOutdoorAirLoad', 'pressureFromAltitude'];
const lines = allScript.split(/\r?\n/);
const functionLines = [];
for (const name of functionNames) {
  const line = lines.find(l => l.startsWith(`function ${name}(`));
  assert.ok(line, `Calculation function missing: ${name}`);
  functionLines.push(line);
}
const sandbox = {};
vm.runInNewContext(`${functionLines.join('\n')}\nglobalThis.api={satPressure,moist,dewPoint,wetBulb,calculateOutdoorAirLoad,pressureFromAltitude};`, sandbox);
const api = sandbox.api;
const state = api.moist(25, 50, 101325);
near(state.w, 0.0098579061, 1e-8, 'Humidity ratio at 25°C / 50% RH');
near(state.h, 50.2630159, 1e-5, 'Enthalpy at 25°C / 50% RH');
near(state.rhoDry, 1.1654536, 1e-5, 'Dry-air density at 25°C / 50% RH');
near(api.wetBulb(25, state.w, 101325), 17.82206, 0.02, 'Wet-bulb temperature');
near(api.pressureFromAltitude(0), 101325, 0.1, 'Standard pressure at sea level');
near(api.pressureFromAltitude(950), 90420.98, 0.1, 'Standard pressure at 950 m');
const air = api.calculateOutdoorAirLoad(120, 35, 24, 40, 50, 90500);
near(air.total, 838.6374, 0.02, 'Outdoor-air total enthalpy load');
near(air.sensible + air.latent, air.total, 1e-8, 'Outdoor-air sensible + latent energy balance');
const zeroFlow = api.calculateOutdoorAirLoad(0, 35, 24, 40, 50, 90500);
near(zeroFlow.total, 0, 1e-12, 'Zero-flow air load');
const freeCooling = api.calculateOutdoorAirLoad(120, 20, 24, 40, 50, 101325);
assert.ok(freeCooling.total < 0, 'Cooler outdoor air should retain signed free-cooling contribution');
pass('Psychrometric, pressure-altitude and outdoor-air load reference vectors pass');

// Critical guardrails must remain present in the app source.
for (const token of ['function validateCoolingInputs()', 'function readStrictNumber(id)', 'winterT< -60||winterT>25', "['official','measured'].includes(source)", "const meta=[['stationName'", 'shgc:{min:0,max:1', 'shade:{min:0,max:1', 'if(!validateCoolingInputs())return;', 'Correct invalid inputs before creating the report.']) {
  assert.ok(allScript.includes(token), `Missing input/report safety guard: ${token}`);
}
assert.ok(html.includes('Bilgi amaçlıdır; mevcut soğutma yükü modelinde kullanılmaz.'), 'Ceiling-height limitation must be visible');
for (const id of ['stationName','stationPeriod','stationSource','stationLat','stationLon']) assert.ok(ids.includes(id), `Missing weather provenance field: ${id}`);
pass('Input validation and stale-report prevention guards are present');

// Execute the real shared input validator against a minimal DOM test double.
const validationStart = allScript.indexOf('const $=id=>document.getElementById(id)');
const validationEnd = allScript.indexOf('function syncUPreset', validationStart);
assert.ok(validationStart >= 0 && validationEnd > validationStart, 'Could not isolate shared input validator');
const validationSource = allScript.slice(validationStart, validationEnd);
const elementMap = new Map();
for (const match of html.matchAll(/<input\b([^>]*)>/g)) {
  const attrs = Object.fromEntries([...match[1].matchAll(/([\w-]+)=["']([^"']*)["']/g)].map(m => [m[1], m[2]]));
  if (attrs.id) elementMap.set(attrs.id, { value: attrs.value || '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
for (const id of ['weatherSource','glassOrientation','totalKW','totalBTU','sensible','latent','breakdown','heatingBreakdown','heatingKW']) {
  if (!elementMap.has(id)) elementMap.set(id, { value: id === 'weatherSource' ? 'preliminary' : (id === 'glassOrientation' ? '1' : ''), textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
elementMap.get('weatherSource').value = 'preliminary';
elementMap.get('glassOrientation').value = '1';
const testWindow = { __hvacLang: 'tr', lastCalc: { total: 123 }, lastHeating: { total: 456 } };
const validationContext = {
  document: { getElementById: id => elementMap.get(id) || { value: '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } }, querySelector: () => ({ style: {} }) },
  window: testWindow,
  updateLoadComparison() {}
};
vm.runInNewContext(`${validationSource}\nglobalThis.validationApi={validateCoolingInputs,readStrictNumber};`, validationContext);
const validator = validationContext.validationApi;
assert.strictEqual(validator.validateCoolingInputs(), true, 'Default cooling inputs should validate');
elementMap.get('shgc').value = '1.2';
assert.strictEqual(validator.validateCoolingInputs(), false, 'SHGC above 1 must be rejected');
assert.ok(elementMap.get('shgc').validationMessage, 'SHGC validation message should be set');
elementMap.get('shgc').value = '0.7';
elementMap.get('freshAir').value = '-10';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Negative fresh-air flow must be rejected');
elementMap.get('freshAir').value = '120';
elementMap.get('weatherSource').value = 'official';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Official source without provenance must be rejected');
elementMap.get('stationName').value = 'Test Station 123';
elementMap.get('stationPeriod').value = '1991-2020';
elementMap.get('stationSource').value = 'Official climate record';
elementMap.get('stationLat').value = '39.9';
elementMap.get('stationLon').value = '32.8';
assert.strictEqual(validator.validateCoolingInputs(), true, 'Complete official source metadata should validate');
elementMap.get('stationLon').value = '181';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Longitude outside valid range must be rejected');
pass('Live input-validator tests pass: defaults, SHGC, negative airflow and official weather provenance');
