HVAC PRO — Android Studio kaynak projesi
==========================================

Bu paket derlenmiş APK değildir; Android Studio kaynak projesidir.
Bu çalışma sürümünde:
- Türkçe / İngilizce dil seçimi için ilk arayüz desteği
- Ücretsiz temel hesaplama ekranları
- Professional özellik tanıtım ekranı (ödeme henüz bağlı değildir)
- Soğutma yükü, taze hava, proje kaydetme ve yazdırma/PDF akışı

ÖNEMLİ:
Professional ekranı şu an yalnızca ürün taslağıdır. Google Play Billing,
abonelik/tek seferlik satın alma, gizlilik politikası, imzalama anahtarı,
Play Console kaydı ve mağaza gereklilikleri henüz entegre edilmemiştir.
Hesaplama sonuçları ön boyutlandırma içindir; mühendislik doğrulaması gerekir.

APK oluşturma:
1. Android Studio kurulu bir bilgisayarda bu klasörü aç.
2. Gradle Sync tamamlandıktan sonra Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk

Telefon-only kullanıcı için:
Bu projeye GitHub Actions derleme akışı eklenerek telefondan GitHub web arayüzüyle
APK derlemek mümkün hale getirilebilir. Google Play yayını için ayrıca Play Console
geliştirici hesabı gerekir.
