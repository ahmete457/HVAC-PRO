# HVAC PRO ikon rehberi
- Ana renk: lacivert #061A35
- Teknik mavi: #087CE8
- Soğutma vurgusu: buz mavisi
- Isıtma vurgusu: turuncu
- Google Play ikonu: HVAC_PRO_Play_Icon_512.png (512×512)
- Android launcher için mipmap, adaptive, round ve monochrome kaynakları eklendi.
- Açılış ekranı teması koyu lacivert ve uygulama ikonunu kullanır.
