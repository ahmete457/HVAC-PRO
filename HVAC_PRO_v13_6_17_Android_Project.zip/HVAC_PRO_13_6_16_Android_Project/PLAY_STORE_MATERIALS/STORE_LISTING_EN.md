# Google Play listing – English draft

## App name
HVAC PRO – HVAC Engineering Calculator

## Short description
HVAC preliminary sizing, cooling load, fresh air and engineering tools.

## Full description
HVAC PRO is an assistant for preliminary HVAC and ventilation calculations. Tools include cooling-load estimate, fresh-air airflow estimate, heating estimate, psychrometric properties, duct sizing and velocity, duct pressure-loss estimate, equipment capacity comparison, multi-zone load summary, local project records and PDF report.

Results are preliminary estimates, not a substitute for applicable standards, verified design-weather data, manufacturer selection software, site measurements or qualified engineering review. Prices are shown by Google Play for the user's region.
