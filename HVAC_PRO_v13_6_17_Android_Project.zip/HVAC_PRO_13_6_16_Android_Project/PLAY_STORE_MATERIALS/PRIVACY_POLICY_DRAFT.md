# Gizlilik politikası – yayın öncesi taslak

Uygulama: HVAC PRO
Geliştirici: [GELİŞTİRİCİ/İŞLETME ADI]
E-posta: [İLETİŞİM E-POSTASI]

Uygulama, kullanıcı tarafından girilen HVAC proje ve hesap girdilerini cihaz üzerinde işler. Proje kayıtları WebView yerel depolamasında saklanabilir; uygulama verisi temizlenirse kaybolabilir. Bu kaynak sürümünde geliştirici sunucusuna veri gönderen API tanımlı değildir. Nihai APK'ya eklenecek Billing, SDK ve servisler veri akışını değiştirebilir. Nihai derleme incelenmeden mağazada yayımlamayın.

Google Play Billing etkinleştirildiğinde ödeme Google Play tarafından işlenir. Bu taslağı gerçek veri akışına göre güncelleyin, iletişim bilgilerini doldurun ve HTTPS üzerinden yayımlayın.
