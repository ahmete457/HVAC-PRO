# Google Play Data safety – hazırlık

Bu liste otomatik beyan değildir. Nihai APK/AAB, manifest, SDK ve ağ davranışı incelenerek yanıtlanmalıdır.
- [ ] Nihai APK izinleri ve bağımlılıkları kontrol edildi.
- [ ] Billing eklendiyse satın alma/veri akışı beyan edildi.
- [ ] Analitik/reklam/crash SDK eklendiyse veri türleri yeniden değerlendirildi.
- [ ] Yerel proje verisi ve silme davranışı açıklandı.
- [ ] Aktarım şifrelemesi ve veri silme soruları gerçek uygulamaya göre yanıtlandı.
- [ ] Gizlilik politikası HTTPS URL'sinde yayımlandı.
- [ ] İletişim ve geliştirici bilgileri dolduruldu.
