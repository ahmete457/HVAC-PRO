# HVAC PRO Professional — Billing Preparation

## Current state (13.6.8)
- Professional entitlement is intentionally locked (`HVAC_PRO_ENTITLED = false`).
- No payment is collected and no local flag can unlock paid features.
- Professional price target: one-time purchase, 349 TL (localized Play prices must be configured in Play Console).
- PDF printing is gated as a Professional feature. Its report title and metadata now follow the selected Turkish/English language.

## Required before enabling purchases
1. Complete Google Play developer identity verification.
2. Create the one-time in-app product in Play Console (suggested product ID: `hvac_pro_professional_lifetime`; confirm ID before implementation).
3. Add Google Play Billing Library using a current supported version and implement purchase, pending, acknowledged, cancelled, refunded/revoked, and restore flows.
4. Verify purchase tokens with a trusted backend / Google Play Developer API; never unlock based only on a client-side boolean or a local preference.
5. Test with Play license testers and an internal testing track, including reinstall and restore on another device.
6. Enable entitlement only after verified active purchase; keep all paid actions behind the same entitlement check.

## PDF language verification
- Select English, create/print report: title and metadata should be English.
- Select Turkish, create/print report: title and metadata should be Turkish.
- Check date locale, city/district, design temperatures, RH, data source, and pressure.
- The PDF flow cannot be fully exercised in the free build because Professional remains locked until a verified purchase/test entitlement is available.

## Safety
Do not add a debug bypass or hard-coded `true` entitlement to production. Billing integration and Play Console product configuration are still pending.
