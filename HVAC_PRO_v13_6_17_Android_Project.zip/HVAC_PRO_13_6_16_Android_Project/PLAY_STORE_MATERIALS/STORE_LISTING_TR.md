# Google Play mağaza metni – Türkçe taslak

## Uygulama adı
HVAC PRO – HVAC Hesaplama

## Kısa açıklama
HVAC ön boyutlandırma, soğutma yükü, taze hava ve mühendislik araçları.

## Uzun açıklama
HVAC PRO, iklimlendirme ve havalandırma projelerinde ön boyutlandırma ve hızlı mühendislik kontrolleri için geliştirilmiş yardımcı uygulamadır.

Araçlar: soğutma yükü ön hesabı, taze hava debisi tahmini, ısıtma yükü ön hesabı, psikrometrik hava özellikleri, kanal kesiti ve hız hesabı, kanal basınç kaybı tahmini, cihaz kapasite karşılaştırması, çoklu mahal yük özeti, proje kayıtları ve PDF raporu.

Sonuçlar ön boyutlandırma niteliğindedir. Nihai tasarım için geçerli standartlar, doğrulanmış iklim verileri, üretici tabloları ve yetkin mühendis kontrolü gerekir. Professional fiyatı bölgesel Play fiyatlandırmasıyla gösterilir; 349 TL Türkiye hedef fiyatı Play Console'da doğrulanmalıdır.
