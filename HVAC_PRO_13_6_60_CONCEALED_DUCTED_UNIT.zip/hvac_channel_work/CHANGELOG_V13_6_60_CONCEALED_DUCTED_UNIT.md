# HVAC PRO 13.6.60 – Gizli Tavan Kanallı Cihaz Tasarımı

- Otomatik kanal tasarım sekmesi gizli tavan kanallı cihaz senaryosuna göre yeniden adlandırıldı ve açıklamaları netleştirildi.
- Cihaz toplam üfleme debisi, menfez/mahal hedef debileri ve her mahal için girilen ana kanal/branşman uzunluklarından kesit, hız, sürtünme kaybı ve yerel kayıp hesabı yapılır.
- Otomatik şema oluşturulduktan sonra Manuel tasarım sekmesindeki 2D çizimde düzenlenebilir; mevcut 3D önizleme aynı çizim geometrisini kullanır.
- Mahal/terminal sayısı dinamik ekle/sil akışıyla devam eder; sabit 8 mahal sınırı yoktur.
- Kanal proje kaydetme/PDF/kayıt listesi kontrolleri yalnızca Kanallar paneli aktifken görünür olacak şekilde kapsamlandı.
- Kanal projesi kaydı kanal modülünün kendi kayıt alanında tutulur.

## Mühendislik sınırları

Bu sürüm mevcut seri ana kanal + yan branşman şematik topolojisini kullanır. Uzunluklar kullanıcı girdisidir; otomatik güzergâh yerleşimi ölçülü CAD rota optimizasyonu değildir. Dirsek/branşman yerel kayıpları ilgili ΣK alanlarına girilmelidir. Son cihaz seçimi, gerçek üretici ESP/terminal basınç kayıpları ve saha güzergâhı ile doğrulanmalıdır.
