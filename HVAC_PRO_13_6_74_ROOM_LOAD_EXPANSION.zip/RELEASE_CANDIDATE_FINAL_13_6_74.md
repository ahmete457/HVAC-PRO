# HVAC PRO 13.6.74 — Room Load Expansion Candidate

Consolidated Android source project: versionName `13.6.74`, versionCode `101`.

This release builds on 13.6.73 and adds room-use presets, selectable standard-split/mechanical-outdoor-air modes, upper-adjacent-space conditions, and an eight-direction multi-facade editor. Existing modules, project backup, PDF bridge, and package ID are retained.

## Validation
- `node scripts/qa_validate.js` — PASS.
- `python3 scripts/qa_validate_project.py` — PASS.
- Multi-facade sensible/solar reference vectors — PASS.
- Standard split excludes mechanical outdoor-air load — PASS.
- Mechanical outdoor-air mode includes psychrometric outdoor-air load — PASS.
- Conditioned upper-space ceiling load is zero — PASS.
- Web and Android packaged HTML assets are byte-identical — PASS.
- ZIP integrity — PASS.

## Not certified
- No APK/AAB was built in this environment because Gradle and Android SDK are unavailable.
- Real Android-device regression tests remain required for UI, project save/restore, language switching, PDF and representative projects.
- Orientation factors and occupancy defaults are preliminary editable estimates, not a substitute for applicable standards, hourly solar calculations or project-specific engineering inputs.
- Existing release limitations and Play Billing status from 13.6.73 remain unchanged.
