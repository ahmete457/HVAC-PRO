#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'app/src/main/assets/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');

function pass(message) { console.log(`PASS  ${message}`); }
function near(actual, expected, tolerance, label) {
  assert.ok(Number.isFinite(actual), `${label}: result is not finite`);
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: expected ${expected} ± ${tolerance}, got ${actual}`);
}

// HTML structure and JavaScript syntax.
const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
const duplicateIds = ids.filter((id, i) => ids.indexOf(id) !== i);
assert.deepStrictEqual([...new Set(duplicateIds)], [], `Duplicate HTML IDs: ${[...new Set(duplicateIds)].join(', ')}`);
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
assert.ok(scripts.length > 0, 'No inline application script found');
for (const script of scripts) new vm.Script(script, { filename: 'index.html:inline-script' });
const allScript = scripts.join('\n');
const literalRefs = [...allScript.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(m => m[1]);
const missingRefs = [...new Set(literalRefs.filter(id => !ids.includes(id)))];
assert.deepStrictEqual(missingRefs, [], `JavaScript references missing DOM IDs: ${missingRefs.join(', ')}`);
pass('HTML IDs are unique; inline JavaScript parses; literal DOM references exist');

// Country/city selector and clean page-based navigation checks.
assert.ok(html.includes('const TURKISH_PROVINCES=') && html.includes('id="country"') && html.includes('id="city"'), 'Country selector and offline Turkish province list exist');
assert.ok(html.includes('https://www.mgm.gov.tr/veridegerlendirme/il-ve-ilceler-istatistik.aspx') && html.includes('const TURKISH_PROVINCES=') && !html.includes('photon.komoot.io') && !html.includes('worldCitySearchButton'), 'Türkiye-only 81 province-centre selector uses MGM as public reference; foreign city search is removed');
assert.ok(html.includes('81 il için doğrulanmış MGM iklim değerleri') && html.includes('aynı varsayımsal değer gösterilmez'), 'MGM monthly climate summaries are not misrepresented as HVAC design-day data');
assert.ok(!html.includes('globalPlaceSearch') && !html.includes('HVAC_PRO_CLIMATE_API_BASE') && !html.includes('globalClimatePanel'), 'Global climate search/API UI is removed');
assert.ok(html.includes('id="calcWorkspace" hidden') && html.includes('id="calcWorkspaceBack"') && html.includes('function showCalcHub()'), 'Calculation workspace is a separate page with back navigation');
assert.ok(!html.includes('id="airRouteEditor"') && !html.includes('id="airRouteCanvas"') && html.includes('id="openDuctStudio"'), 'Legacy duplicate drawing UI removed; dedicated 2D studio entry retained');
assert.ok(html.includes('window.hvacOpenDuctStudio=open') && html.includes('b.dataset.tab') && html.includes('airDesign'), 'Dedicated 2D studio opens on duct menu entry');
assert.ok(html.includes('id="tout" step="0.1" type="number" value=""') && html.includes('id="altitude" step="1" type="number" value=""'), 'Unverified shared climate defaults are removed');
pass('Country/city selection and page-based discipline navigation checks pass');

// Extract the exact pure calculation functions used by the app and run reference vectors.
const functionNames = ['satPressure', 'moist', 'dewPoint', 'wetBulb', 'calculateOutdoorAirLoad', 'calculateRoomCoolingLoads', 'calculateHeatingLoad', 'pressureFromAltitude', 'darcyFrictionFactor', 'psychroSolveTemperature', 'psychroStateFromTW'];
const lines = allScript.split(/\r?\n/);
const functionLines = [];
for (const name of functionNames) {
  const line = lines.find(l => l.startsWith(`function ${name}(`));
  assert.ok(line, `Calculation function missing: ${name}`);
  functionLines.push(line);
}
const sandbox = {};
vm.runInNewContext(`${functionLines.join('\n')}\nglobalThis.api={satPressure,moist,dewPoint,wetBulb,calculateOutdoorAirLoad,calculateRoomCoolingLoads,calculateHeatingLoad,pressureFromAltitude,darcyFrictionFactor,psychroSolveTemperature,psychroStateFromTW};`, sandbox);
const api = sandbox.api;
near(api.darcyFrictionFactor(1000,0),0.064,1e-12,'Darcy factor laminar reference');
near(api.darcyFrictionFactor(100000,0),0.01799,0.00015,'Darcy factor smooth turbulent reference');
const f2300=api.darcyFrictionFactor(2300,0.0001),f4000=api.darcyFrictionFactor(4000,0.0001);
assert.ok([f2300,f4000].every(x=>Number.isFinite(x)&&x>0)&&f2300<0.06&&f4000<0.06,'Darcy factor must remain finite and physically bounded across transitional flow');
near(api.darcyFrictionFactor(100000,0.001),0.0223,0.001,'Darcy factor rough-pipe reference');
pass('Unified Churchill Darcy friction model passes laminar, transitional, smooth and rough-pipe reference checks');
const state = api.moist(25, 50, 101325);
near(state.w, 0.0098579061, 1e-8, 'Humidity ratio at 25°C / 50% RH');
near(state.h, 50.2630159, 1e-5, 'Enthalpy at 25°C / 50% RH');
near(state.rhoDry, 1.1654536, 1e-5, 'Dry-air density at 25°C / 50% RH');
near(api.wetBulb(25, state.w, 101325), 17.82206, 0.02, 'Wet-bulb temperature');
near(api.pressureFromAltitude(0), 101325, 0.1, 'Standard pressure at sea level');
near(api.pressureFromAltitude(950), 90420.98, 0.1, 'Standard pressure at 950 m');
const air = api.calculateOutdoorAirLoad(120, 35, 24, 40, 50, 90500);
near(air.total, 838.6374, 0.02, 'Outdoor-air total enthalpy load');
near(air.sensible + air.latent, air.total, 1e-8, 'Outdoor-air sensible + latent energy balance');
const coolRef=api.calculateRoomCoolingLoads({area:100,tout:35,tin:24,groundT:10,rhOut:40,rhIn:50,pressure:101325,wallA:80,wallU:0.6,roofA:100,roofU:0.4,floorA:100,floorU:0.5,glassA:20,glassU:2.7,shgc:0.5,solar:500,orientation:1,shade:0.6,people:5,personS:75,personL:55,light:8,equipment:500,freshAir:300,infiltration:50,margin:10});
near(coolRef.wall,528,1e-9,'Independent cooling wall transmission reference');
near(coolRef.roof,440,1e-9,'Independent cooling roof transmission reference');
near(coolRef.floor,0,1e-9,'Cooling floor gain is zero when ground is cooler than room');
near(coolRef.glassSolar,3000,1e-9,'Independent cooling solar gain reference');
near(coolRef.total,9996.026008537874,1e-6,'Independent full cooling load reference including outdoor-air enthalpy and 10% margin');
near(coolRef.total,coolRef.subtotal+coolRef.safety,1e-9,'Cooling total and safety margin balance');
const heatRef=api.calculateHeatingLoad({tin:20,winterT:-10,groundT:10,hrv:70,wallA:80,wallU:.6,roofA:100,roofU:.4,floorA:100,floorU:.5,glassA:20,glassU:2.7,freshAir:300,infiltration:50,margin:10});
near(heatRef.dt,30,1e-12,'Independent heating design delta-T reference');
near(heatRef.transmission,4760,1e-9,'Independent heating transmission reference');
near(heatRef.freshLoss,891,1e-9,'Independent heating heat-recovery fresh-air reference');
near(heatRef.infiltrationLoss,495,1e-9,'Independent heating infiltration reference');
near(heatRef.total,6760.6,1e-9,'Independent heating total reference');
pass('Cooling/heating load engines pass independent engineering reference vectors');
// V13.6.74: multi-facade solar/transmission, outdoor-air mode and adjacent-space checks.
const facadeRef=api.calculateRoomCoolingLoads({area:20,tout:34,tin:24,groundT:24,rhOut:60,rhIn:50,pressure:101325,wallA:0,wallU:.5,roofA:0,roofU:.3,floorA:0,floorU:.3,glassA:0,glassU:2.7,shgc:.7,solar:500,orientation:1,shade:1,facades:[{direction:'W',wallA:10,glassA:2},{direction:'S',wallA:8,glassA:1}],people:0,personS:0,personL:0,light:0,equipment:0,freshAir:120,infiltration:0,oaMode:'none',upperBoundary:'conditioned',upperTemp:30,margin:0});
near(facadeRef.wall,90,1e-9,'Multi-facade wall transmission sums each facade');
near(facadeRef.glassCond,81,1e-9,'Multi-facade glazing transmission sums each facade');
near(facadeRef.glassSolar, (2*1.15+1*1.0)*.7*500,1e-9,'West and south glazing use separate orientation factors');
near(facadeRef.air.total,0,1e-9,'Standard split mode excludes unconnected mechanical outdoor air');
near(facadeRef.roof,0,1e-9,'Conditioned adjacent upper space has no ceiling transmission load');
const mechanicalRef=api.calculateRoomCoolingLoads({area:20,tout:34,tin:24,groundT:24,rhOut:60,rhIn:50,pressure:101325,wallA:0,wallU:.5,roofA:0,roofU:.3,floorA:0,floorU:.3,glassA:0,glassU:2.7,shgc:0,solar:0,orientation:1,shade:1,people:0,personS:0,personL:0,light:0,equipment:0,freshAir:120,infiltration:0,oaMode:'mechanical',upperBoundary:'unconditioned',upperTemp:30,margin:0});
assert.ok(mechanicalRef.air.total>0,'Mechanical outdoor-air mode includes the entered outdoor-air load');
near(mechanicalRef.roof,0,1e-9,'Unconditioned upper space at room temperature creates no ceiling load');
assert.ok(html.includes('id="roomUse"')&&html.includes('id="oaMode"')&&html.includes('id="upperBoundary"')&&html.includes('id="facadeRows"')&&['N','NE','E','SE','S','SW','W','NW'].every(d=>html.includes(`'${d}'`)), 'Room use, ventilation mode, upper-space and eight-direction multi-facade controls are present');
pass('Multi-facade, outdoor-air mode and upper-space cooling references pass');
const coolBridge=api.calculateRoomCoolingLoads({area:100,tout:35,tin:24,groundT:10,rhOut:40,rhIn:50,pressure:101325,wallA:0,wallU:0,roofA:0,roofU:0,floorA:0,floorU:0,glassA:0,glassU:0,shgc:0,solar:0,orientation:1,shade:1,people:0,personS:0,personL:0,light:0,equipment:0,freshAir:0,infiltration:0,margin:0,thermalBridgePsi:0.25,thermalBridgeLength:40});
near(coolBridge.thermalBridge,110,1e-9,'Cooling linear thermal-bridge reference');
const heatBridge=api.calculateHeatingLoad({tin:20,winterT:-10,groundT:10,hrv:0,wallA:0,wallU:0,roofA:0,roofU:0,floorA:0,floorU:0,glassA:0,glassU:0,freshAir:0,infiltration:0,margin:0,thermalBridgePsi:0.25,thermalBridgeLength:40});
near(heatBridge.thermalBridge,300,1e-9,'Heating linear thermal-bridge reference');
pass('Linear thermal-bridge cooling/heating contributions pass independent ψ·L·ΔT vectors');
const zeroFlow = api.calculateOutdoorAirLoad(0, 35, 24, 40, 50, 90500);
near(zeroFlow.total, 0, 1e-12, 'Zero-flow air load');
const freeCooling = api.calculateOutdoorAirLoad(120, 20, 24, 40, 50, 101325);
assert.ok(freeCooling.total < 0, 'Cooler outdoor air should retain signed free-cooling contribution');
const wMix=(stateA,stateB,frac)=>((1-frac)*stateA.rhoDry*stateA.w+frac*stateB.rhoDry*stateB.w)/((1-frac)*stateA.rhoDry+frac*stateB.rhoDry);
const hMix=(stateA,stateB,frac)=>((1-frac)*stateA.rhoDry*stateA.h+frac*stateB.rhoDry*stateB.h)/((1-frac)*stateA.rhoDry+frac*stateB.rhoDry);
const hot=api.moist(30,50,101325), cool=api.moist(20,50,101325), wm=wMix(hot,cool,0.3), hm=hMix(hot,cool,0.3), tm=api.psychroSolveTemperature(hm,wm);
near(api.psychroStateFromTW(tm,wm,101325).h,hm,1e-8,'Psychrometric mixed-air enthalpy balance');
const mixedState=api.psychroStateFromTW(tm,wm,101325);
assert.ok(Number.isFinite(mixedState.rhoDry)&&mixedState.rhoDry>0,'Mixed-air dry-air density must be calculated and positive');
const mixedMass=(1000/3600*hot.rhoDry)+(300/3600*cool.rhoDry);
const mixedFlow=mixedMass/mixedState.rhoDry*3600;
assert.ok(Number.isFinite(mixedFlow)&&mixedFlow>0,'Mixed-state equivalent volume flow must be finite');
near(mixedFlow,1300,10.0,'Mixed-state equivalent volume flow should be approximately conserved');
const heated=api.psychroStateFromTW(40,hot.w,101325);
near(heated.w,hot.w,1e-12,'Constant-humidity-ratio heating');
assert.ok(heated.h>hot.h,'Heating must increase moist-air enthalpy');
pass('Psychrometric, pressure-altitude, outdoor-air and new process reference vectors pass');

assert.ok(html.includes('id="thermalBridgePsi"' && html.includes('id="thermalBridgeLength"') && html.includes('id="thermalBridgePsi"') && html.includes('id="thermalBridgeLength"') && html.includes('id="psychroMixFlow"')), 'Separate second-air volumetric flow input must exist');
assert.ok(!html.includes('psychroMixFraction'), 'Legacy airflow percentage input must be removed');
assert.ok(allScript.includes("m1=flow/3600*a.rhoDry,m2=flow2/3600*c.rhoDry"), 'Mixing must use each inlet volumetric flow and its own dry-air density');
assert.ok(allScript.includes('const mixedVolume=mdot/b.rhoDry*3600'), 'Mixed-state equivalent volume flow must be reported');
const flow1=1000,flow2=300;
const m1=flow1/3600*hot.rhoDry,m2=flow2/3600*cool.rhoDry,mt=m1+m2;
const wActual=(m1*hot.w+m2*cool.w)/mt,hActual=(m1*hot.h+m2*cool.h)/mt;
const tActual=api.psychroSolveTemperature(hActual,wActual);
const mixedActual=api.psychroStateFromTW(tActual,wActual,101325);
near(mixedActual.h,hActual,1e-8,'Independent-volume-flow mixing enthalpy balance');
near(mixedActual.w,(m1*hot.w+m2*cool.w)/mt,1e-12,'Independent-volume-flow mixing humidity balance');
assert.ok(Math.abs((m1/mt)-0.7)>0.001, 'Different inlet densities must alter dry-air mass split from simple 70/30 volume split');
pass('Separate inlet volume-flow inputs, mixed-state dry-air density and mass/enthalpy balances are present');

// Critical guardrails must remain present in the app source.
for (const token of ['function validateCoolingInputs()', 'function readStrictNumber(id)', 'winterT< -60||winterT>25', "['official','measured'].includes(source)", "const meta=[['stationName'", 'shgc:{min:0,max:1', 'shade:{min:0,max:1', 'if(!validateCoolingInputs())return;', 'Correct invalid inputs before creating the report.']) {
  assert.ok(allScript.includes(token), `Missing input/report safety guard: ${token}`);
}
assert.ok(html.includes('function calculateRoomCoolingLoads(x)') && html.includes('function calculateHeatingLoad(x)') && allScript.includes('thermalBridge=(x.thermalBridgePsi||0)*(x.thermalBridgeLength||0)*dt'), 'Cooling/heating engines and linear thermal-bridge term must exist');
assert.ok(html.includes("roomVolume=n('area')*n('height')") && html.includes('roomVolumeInfo'), 'Ceiling height must drive room volume and air-change-rate reporting');
for (const id of ['stationName','stationPeriod','stationSource','stationLat','stationLon']) assert.ok(ids.includes(id), `Missing weather provenance field: ${id}`);
pass('Input validation and stale-report prevention guards are present');

// Execute the real shared input validator against a minimal DOM test double.
const validationStart = allScript.indexOf('const $=id=>document.getElementById(id)');
const validationEnd = allScript.indexOf('function syncUPreset', validationStart);
assert.ok(validationStart >= 0 && validationEnd > validationStart, 'Could not isolate shared input validator');
const validationSource = allScript.slice(validationStart, validationEnd);
const elementMap = new Map();
for (const match of html.matchAll(/<input\b([^>]*)>/g)) {
  const attrs = Object.fromEntries([...match[1].matchAll(/([\w-]+)=["']([^"']*)["']/g)].map(m => [m[1], m[2]]));
  if (attrs.id) elementMap.set(attrs.id, { value: attrs.value || '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
for (const id of ['weatherSource','glassOrientation','totalKW','totalBTU','sensible','latent','breakdown','heatingBreakdown','heatingKW']) {
  if (!elementMap.has(id)) elementMap.set(id, { value: id === 'weatherSource' ? 'preliminary' : (id === 'glassOrientation' ? '1' : ''), textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } });
}
elementMap.get('weatherSource').value = 'manual';
elementMap.get('glassOrientation').value = '1';
// Supply explicit manual climate inputs for the validation vector; the app intentionally no longer invents shared city values.
for (const [id,value] of Object.entries({tout:'35',rhout:'45',altitude:'938',pressure:'90500'})) elementMap.get(id).value=value;
const testWindow = { __hvacLang: 'tr', lastCalc: { total: 123 }, lastHeating: { total: 456 } };
const validationContext = {
  document: { getElementById: id => elementMap.get(id) || { value: '', textContent: '', style: {}, setCustomValidity(message) { this.validationMessage = message; } }, querySelector: () => ({ style: {} }) },
  window: testWindow,
  updateLoadComparison() {}
};
vm.runInNewContext(`${validationSource}\nglobalThis.validationApi={validateCoolingInputs,readStrictNumber};`, validationContext);
const validator = validationContext.validationApi;
assert.strictEqual(validator.validateCoolingInputs(), true, 'Default cooling inputs should validate');
elementMap.get('shgc').value = '1.2';
assert.strictEqual(validator.validateCoolingInputs(), false, 'SHGC above 1 must be rejected');
assert.ok(elementMap.get('shgc').validationMessage, 'SHGC validation message should be set');
elementMap.get('shgc').value = '0.7';
elementMap.get('freshAir').value = '-10';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Negative fresh-air flow must be rejected');
elementMap.get('freshAir').value = '120';
elementMap.get('weatherSource').value = 'official';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Official source without provenance must be rejected');
elementMap.get('stationName').value = 'Test Station 123';
elementMap.get('stationPeriod').value = '1991-2020';
elementMap.get('stationSource').value = 'Official climate record';
elementMap.get('stationLat').value = '39.9';
elementMap.get('stationLon').value = '32.8';
assert.strictEqual(validator.validateCoolingInputs(), true, 'Complete official source metadata should validate');
elementMap.get('stationLon').value = '181';
assert.strictEqual(validator.validateCoolingInputs(), false, 'Longitude outside valid range must be rejected');
pass('Live input-validator tests pass: defaults, SHGC, negative airflow and official weather provenance');

const hydronicHtml = fs.readFileSync(path.join(root, "app/src/main/assets/index.html"), "utf8");
assert.ok(hydronicHtml.includes('id="hydronic"') && hydronicHtml.includes('data-tab="hydronic"'));
pass("Project-based hydronic navigation and panel are present");
assert.ok(hydronicHtml.includes("64/Re") && hydronicHtml.includes("5.74/Math.pow(Re,0.9)") && hydronicHtml.includes("K*dyn"));
pass("Hydronic Darcy-Weisbach, Swamee-Jain and local-loss calculations are present");
assert.ok(hydronicHtml.includes("Kritik devre basınç kaybı") && hydronicHtml.includes("Kapalı devrelerde statik bina yüksekliği"));
pass("Hydronic critical-path report and closed-loop static-head caution are present");

// V13.6.39 HVAC discipline navigation and bilingual coverage checks.
const disciplineChecks = [
  ['discipline hub exists', html.includes('id="disciplineHub"')],
  ['seven HVAC discipline entry points exist', ['cooling','heating','ventilation','duct','hydronic','psychrometrics','equipment'].every(x=>html.includes('data-hvac-jump="'+x+'"'))],
  ['discipline navigation handler exists', html.includes('function hvacOpenDiscipline(target)')],
  ['discipline English labels exist', ['hubCooling','hubHeating','hubVentilation','hubDuct','hubHydronic','hubPsychro','hubEquipment'].every(x=>html.includes('data-i18n="'+x+'"'))],
  ['English dictionary contains discipline names', ['Cooling','Heating','Ventilation','Hydronics','Psychrometrics','Equipment & Systems'].every(x=>html.includes(x))],
  ['single 2D duct drawing workspace is used; duplicate inline editor is removed', html.includes('id="ductStudio"') && html.includes('id="dsCanvas"') && html.includes('window.hvacOpenDuctStudio=open') && (html.match(/id="dsCanvas"/g)||[]).length===1 && !html.includes('id="airRouteEditor"') && !html.includes('id="airRouteCanvas"')],
  ['fresh air and duct tiles open separate pages', html.includes('data-hvac-jump="ventilation"') && html.includes("target==='ventilation'") && html.includes("setActivePanel('fresh')") && html.includes('data-hvac-jump="duct"') && html.includes("target==='duct'") && html.includes("setActivePanel('airDesign')")]
];
for (const [name, ok] of disciplineChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) process.exitCode=1; }

// V13.6.46 duct lengths, responsive room cards and straight-duct friction checks
assert.ok(html.includes('data-key=\"sm\"') && html.includes('data-key=\"sb\"') && html.includes('data-key=\"rm\"') && html.includes('data-key=\"rb\"'), 'Each terminal must accept separate supply/return main and branch lengths');
assert.ok(html.includes('function friction(q,sz,L)') && html.includes('function makeRowsTable(rows,kind)'), 'Segment schedule calculates straight duct friction loss from entered lengths');
assert.ok(html.includes('className=\'da-room-card\'') && html.includes('grid-template-columns:1fr'), 'Automatic terminal inputs use responsive cards on narrow screens');

// V13.6.45 2D duct design studio checks
const ductStudioChecks = [
 ['dedicated full-screen 2D duct studio exists', html.includes('id="ductStudio"') && html.includes('id="dsCanvas"')],
 ['manual tools include duct, AHU, terminal and fittings', ['duct','ahu','terminal','elbow','tee','reducer','damper','delete'].every(x=>html.includes('data-ds-tool="'+x+'"'))],
 ['manual element properties and local save exist', ['dsName','dsFlow','dsWidth','dsHeight','dsLength','dsK','dsSave','hvacpro_duct_studio_v1'].every(x=>html.includes(x))],
 ['automatic design accepts AHU and terminal flow criteria', ['daFlow','daCount','daMainV','daBranchV','daShape','daRows','daGenerate'].every(x=>html.includes('id="'+x+'"'))],
 ['automatic duct sizing calculates supply and return segment dimensions', html.includes('function sizeFor(q,v,shape,ratio)') && html.includes('Üfleme terminal debileri toplamı') && html.includes('Dönüş/ emiş') && html.includes('daZoomIn') && html.includes('daCanvasWrap')],
 ['English translations include duct design workspace', html.includes("'Kanal Tasarım Stüdyosu':'Duct Design Studio'")],
 ['app version is 13.6.74 / versionCode 101', fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8').includes('versionCode = 101') && fs.readFileSync(path.join(root,'app/build.gradle.kts'),'utf8').includes('versionName = "13.6.74"')]
];
ductStudioChecks.push(['automatic ducts include editable local-loss coefficients and critical-path aggregation', ['data-key=\"skm\"','data-key=\"skb\"','data-key=\"rkm\"','data-key=\"rkb\"','function makeRowsTable(rows,kind)','const local=(sz,K)=>','sRows.critical.dp','rRows.critical.dp'].every(x=>html.includes(x))]);
const localLoss = 2.0 * 1.2 * 4.0 * 4.0 / 2;
near(localLoss, 19.2, 1e-9, 'duct fitting local-loss reference (K=2, rho=1.2, v=4 m/s)');

ductStudioChecks.push(['unlimited dynamic zone editor has add/remove controls and no 30-zone cap', html.includes('id="daAddRoom"') && html.includes('id="daRemoveLastRoom"') && !html.includes('Math.min(30') && !/id="daCount"[^>]*max=/.test(html)]);
ductStudioChecks.push(['equipment pressure-drop inputs and separate supply/return fan ESP are implemented',
 ['daSFilter','daRFilter','daSCoil','daRCoil','daSHru','daRHru','daSSilencer','daRSilencer','daSOther','daROther','daSSafety','daRSafety'].every(id=>html.includes('id="'+id+'"')) &&
 html.includes('sFanBase=sRows.critical.dp+sEq') && html.includes('rFanBase=rRows.critical.dp+rEq')]);
ductStudioChecks.push(['duct model explicitly discloses topology and fresh-air/exhaust limitations',
 html.includes('Taze hava/egzoz ayrı ağ olarak henüz modellenmez') && html.includes('keyfî çok düğümlü ağ çözümü değildir')]);

ductStudioChecks.push(['AHU capacity assistant uses per-zone cooling load, total supply airflow, fresh-air load and safety margin', ['data-key="cool"','id="ahuFreshFlow"','id="ahuSafety"','id="ahuSelectedKW"','id="ahuSelectedFlow"','id="ahuSizeCheck"','function calculateAhuCapacityRequirement(roomLoads,freshLoad,safety)','flow=rooms.reduce'].every(x=>html.includes(x))]);
const ahuRef = (loads,fresh,margin)=>{const base=loads.reduce((a,v)=>a+v,0)+fresh;return base*(1+margin/100)};
near(ahuRef([4.2,3.8,2.0],1.5,10),12.65,1e-9,'AHU capacity reference: room loads + fresh-air enthalpy load + 10% margin');
ductStudioChecks.push(['duplicate legacy drawing panel is absent from the Kanallar page', !html.includes('id="airRouteEditor"') && !html.includes('id="airRouteCanvas"')]);
for (const [name, ok] of ductStudioChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) process.exitCode=1; }

// V13.6.40 air distribution design module checks
assert(html.includes('id=\"airDistributionTool\"'), 'air distribution terminal tool exists');
assert(html.includes("target==='ventilation'") && html.includes('id="airDesign"') && html.includes('id="openDuctStudio"') && html.includes('id="ductStudio"') && html.includes('window.hvacOpenDuctStudio=open'), 'ventilation tile opens the dedicated 2D duct design studio');
assert(html.includes('id=\"ductPathTool\"'), 'duct critical-path tool exists');

// V13.6.50 full engineering workspace persistence checks.
assert(html.includes('function captureWorkspaceState()'), 'project workspace capture exists');
assert(html.includes('function restoreWorkspaceState(workspace)'), 'project workspace restore exists');
assert(html.includes('hydronicSegments') && html.includes('airRooms') && html.includes('manualDuctDrawing'), 'project workspace includes hydronic, automatic duct and manual duct state');
assert(html.includes('workspace.heatingCalculated') && html.includes('runHeatingProfessional()'), 'saved heating calculations are recalculated on restore');
console.log('PASS  Full engineering workspace save/restore hooks are present');

// V13.6.51 unified multi-discipline print report regression checks.
assert.ok(html.includes('id="engineeringReportAppendix"'), 'Unified engineering report appendix exists');
assert.ok(allScript.includes('function buildEngineeringReportAppendix()'), 'Engineering report appendix builder exists');
assert.ok(allScript.includes("['Hidronik boru ağı','hyResult']"), 'Hydronic result is included in the unified report');
assert.ok(allScript.includes("['Otomatik kanal ağı ve fan ESP','daResult']"), 'Duct network and fan ESP are included in the unified report');
assert.ok(allScript.includes('buildEngineeringReportAppendix();'), 'PDF/report action builds the multi-discipline appendix');
pass('Unified multi-discipline report appendix is present');
// V13.6.73 restored 81-province legacy climate starter profiles; no global climate provider.
assert.ok(fs.readFileSync(path.join(root,'app/src/main/AndroidManifest.xml'),'utf8').includes('android.permission.INTERNET'), 'Android internet permission remains available for app network features');
const climateData=JSON.parse(fs.readFileSync(path.join(root,'app/src/main/assets/climate-data-tr.json'),'utf8'));
assert.strictEqual(climateData.cities.length,81,'Bundled Turkish province climate starter dataset must contain exactly 81 province centres');
assert.ok(!fs.existsSync(path.join(root,'app/src/main/assets/climate-provider-config.js')), 'No global climate provider configuration is bundled');

assert.ok(html.includes('id="country"') && html.includes('populateCountryCities') && !html.includes('photon.komoot.io'), 'Türkiye-only province-centre selector must exist without foreign city lookup');
assert.ok(html.includes('data-module-save="hydronic"') && html.includes('data-module-save="duct"'), 'Hydronic and duct save actions must exist');
assert.ok(html.includes('data-module-pdf="hydronic"') && html.includes('data-module-pdf="duct"'), 'Hydronic and duct PDF actions must exist');
pass('Country-first location selector and independent discipline save/PDF controls are present');

assert.ok(html.includes('data-module-save="fresh"') && html.includes('data-module-pdf="fresh"'), 'Fresh-air module must have independent save and PDF actions');
pass('Fresh-air workspace has independent save and PDF controls');

// Professional entitlement boundary: free cooling/fresh-air remain available; advanced engineering workspaces are gated.
const proLockChecks = [
 ['all Professional modules are intentionally unlocked in this package', html.includes('const HVAC_PRO_ENTITLED = true') && html.includes('const HVAC_PRO_DEBUG_BUILD = false')],
 ['duct, hydronic and project navigation require Professional entitlement', html.includes("['airDesign','hydronic','projects'].includes(b.dataset.tab)&&!requireProfessional")],
 ['discipline hub gates duct, hydronic and equipment routes', ["target==='duct'){if(!requireProfessional('Kanal tasarımı')", "target==='hydronic'){if(!requireProfessional('Hidronik, fan ve pompa araçları')", "target==='equipment'){if(!requireProfessional('Cihaz, AHU ve sistem araçları')"].every(x=>html.includes(x))],
 ['advanced psychrometric process calculation is independently gated', html.includes("requireProfessional('Gelişmiş psikrometrik proses hesabı')")],
 ['fan and pump calculation is independently gated', html.includes("requireProfessional('Fan ve pompa hesapları')")],
 ['AHU capacity control is independently gated', html.includes("requireProfessional('AHU kapasite ve debi kontrolü')")],
 ['all standalone and module PDF exports require Professional entitlement', html.includes("requireProfessional('Bağımsız hesap PDF raporu')") && html.includes("requireProfessional('Modül PDF raporu')") && html.includes("requireProfessional('PDF raporu oluşturma')")],
 ['Professional scope and unlocked-build disclosure are visible', html.includes('id="proAccessStatus"') && html.includes('Bu sürümde tüm HVAC PRO Professional araçları açıktır.')],
 ['free fresh-air workspace remains independently accessible', html.includes("target==='ventilation'){setActivePanel('fresh')") && !html.includes("target==='ventilation'){if(!requireProfessional")],
];
for (const [name, ok] of proLockChecks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) process.exitCode=1; }
