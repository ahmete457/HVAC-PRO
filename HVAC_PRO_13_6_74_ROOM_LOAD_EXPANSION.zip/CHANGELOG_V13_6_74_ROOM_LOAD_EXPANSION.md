# HVAC PRO V13.6.74 — Mahal, cephe ve havalandırma modeli

## Sürüm
- Android versionName: `13.6.74`
- Android versionCode: `101`
- Önceki kaynak: `13.6.73 / versionCode 100`

## Eklenenler
1. Mahal kullanım türü: oturma odası, yatak odası, ofis, mağaza, restoran, eczane, sınıf, muayene odası, otel odası, depo, üretim alanı ve özel kullanım.
2. Kullanım türü seçimi kişi sayısı, kişi duyulur/gizli ısı, aydınlatma ve önerilen dış hava debisi için düzenlenebilir başlangıç değerleri sağlar. Bu değerler mevzuat minimumu olarak sunulmaz.
3. Havalandırma modu: standart split / mekanik taze hava yok veya mekanik taze hava sistemi var. Soğutma hesabına taze hava yalnızca mekanik modda eklenir; infiltrasyon ayrı kalır.
4. Üst mahal seçenekleri: iklimlendirilen hacim, iklimlendirilmeyen hacim, doğrudan çatı/teras, ısıtılmayan çatı arası ve manuel komşu sıcaklığı.
5. Cephe editörü: N, NE, E, SE, S, SW, W, NW yönlerinde birden fazla dış cephe ekleme/silme; her cephe için ayrı duvar ve cam alanı.
6. Duvar iletimi, cam iletimi ve güneş kazancı cephe satırları üzerinden ayrı ayrı toplanır. Güneş yön katsayıları ön hesap katsayılarıdır; saatlik güneş geometrisi veya yerel gölge analizi yerine geçmez.
7. Proje çalışma alanında cephe JSON verisi saklanır ve proje geri yüklenirken cephe editörü yeniden kurulur.
8. İngilizce arayüz için yeni alan ve cephe yönü etiketleri eklendi.

## Mühendislik / kapsam notları
- Standart split modu, dış hava debisini otomatik olarak soğutma yüküne eklemez. Kullanıcı mekanik taze hava sistemi bulunduğunu seçerse girilen debi psikrometrik yük hesabına dahil edilir.
- İnfiltrasyon debisi mekanik dış hava debisinden bağımsız hesaplanır.
- İklimlendirilen üst mahalde tavan iletim yükü sıfırlanır. Diğer üst mahal tiplerinde kullanıcı tasarım sıcaklığı veya dış hava koşulu kullanılır.
- Sekiz yönlü güneş katsayıları ön hesap içindir; proje tasarımında cam SHGC, gölgeleme, yerel güneş verisi ve saatlik güneş geometrisi doğrulanmalıdır.
- Eski tek cephe alanları arka uyumluluk için korunur ve ilk cephe satırına aktarılır.

## QA
- `node scripts/qa_validate.js`: PASS.
- `python3 scripts/qa_validate_project.py`: PASS.
- Bağımsız çoklu cephe, taze hava modu ve üst mahal referans vektörleri: PASS.
- `web/index.html` ve Android WebView `index.html`: byte-for-byte eşleşme.
- APK bu çalışma ortamında derlenmedi; Gradle ve Android SDK kurulu değil. Yeni APK GitHub Actions üzerinden oluşturulmalıdır.
