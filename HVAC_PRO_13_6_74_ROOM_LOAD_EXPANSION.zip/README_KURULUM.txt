HVAC PRO V13.6.74 – ALL MODULES UNLOCKED BUILD
This source package enables all HVAC PRO Professional modules without purchase verification.
Google Play Billing is not integrated and this package does not process in-app purchases.
This is an all-features-unlocked source build for testing/use, not a billing-enabled commercial release.

HVAC PRO 13.6.74 – GÜNCEL GİZLİLİK / LİSANS NOTU (06.11.2026)
===============================================================
- Güncel şehir seçimi Türkiye'nin 81 il merkezini yerel veriyle sunar. Bu sürümde Photon şehir araması ve OpenStreetMap harita verisi etkin değildir.
- Uygulama GPS/konum izni istemez. Proje ve hesaplama verileri uygulama içinde yerel işlenir; geliştirici sunucusuna gönderim servisi tanımlı değildir.
- Android sistem dosya seçicisi proje yedeği içe/dışa aktarmak için, Android yazdırma hizmeti PDF üretmek için kullanılır. Kullanıcı seçimiyle oluşturulan dosyalar geliştiriciye otomatik gönderilmez.
- Malatya TMYx verisi için Climate.OneBuilding atfı ve 5 yıllık kayıt sınırlaması uygulama içindeki “Veri Kaynakları ve Lisanslar” sayfasında açıklanır. Bu veri resmî ASHRAE tasarım koşulu değildir.
- Gizlilik politikası: web/privacy.html ve app/src/main/assets/privacy.html. Lisans bildirimleri: web/third-party-notices.html ve app/src/main/assets/third-party-notices.html.
- Google Play Billing bu sürümde henüz entegre değildir. Billing/analiz/reklam SDK'sı eklenirse gizlilik politikası ve Data safety beyanı dağıtımdan önce gerçek davranışa göre güncellenmelidir.
- Tarihsel CHANGELOG_V13.6.54 kayıtlarında Photon kullanımı anlatılır; bu açıklamalar güncel 13.6.74 kapsamını değil, eski sürüm geçmişini ifade eder.

GÜNCEL KAYNAK DURUMU (V13.6.74 / versionCode 101): Bu paketin güncel sürümü 13.6.74'tür. Aşağıdaki eski sürüm notları tarihsel değişiklik kaydıdır.

HVAC PRO — Android kaynak projesi
=================================

Bu paket derlenmiş APK değildir; Android kaynak projesidir.

V13.6.74 kapsamı:
- Türkçe / İngilizce arayüz; Türkiye'nin 81 il merkezi için çevrimdışı şehir seçimi.
- Soğutma ve ısıtma yükü, taze hava, psikrometri ve proses kontrolleri.
- Fan/pompa, pompa çalışma noktası, hidronik devre, kanal boyutlandırma ve 2D kanal tasarımı.
- AHU kapasite ön kontrolü, çoklu mahal özeti ve VRF borulama/ilave akışkan ön hesabı.
- Disiplin bazlı proje kaydı, JSON yedekleme ve modül kapsamı ayrı PDF raporları.
- Android WebView yerel yazdırma/PDF köprüsü.

ÖNEMLİ SINIRLAR:
Google Play Billing henüz entegre edilmemiştir; uygulama şu anda ödeme almaz.
Şehir iklim profilleri resmî MGM tasarım verisi olarak sunulmaz; eksik/varsayılan
veriler proje bazında doğrulanmalıdır. Hesaplar ön boyutlandırma niteliğindedir;
üretici seçim yazılımları, ilgili standartlar ve yetkili mühendislik kontrolü gerekir.
Android cihazda gerçek PDF çıktısı, menü/ekran akışları ve hesap senaryoları ayrıca
sınanmalıdır. Bu kaynak paketi tek başına yayın onayı anlamına gelmez.

APK oluşturma — GitHub Actions:
1. Bu kaynak klasörünün içeriğini GitHub deposunun main dalına yükleyin.
2. GitHub > Actions > Build HVAC PRO Android packages iş akışını açın.
3. Run workflow ile derlemeyi başlatın veya main dalına push yapın.
4. İş akışı JavaScript QA, Android yapısal QA, debug APK derlemesi ve Android lint çalıştırır.
5. Upload signing secrets tanımlıysa imzalı release APK/AAB de üretilir ve APK imzası doğrulanır.
6. Başarılı çalışmanın Artifacts bölümünden HVAC-PRO-v13.6.74-packages paketini indirin.
7. İmzalama anahtarı tanımlı değilse debug APK ve lint yine üretilir; release APK/AAB oluşmaz.

Gerekli release secrets: SIGNING_KEY_BASE64, SIGNING_STORE_PASSWORD,
SIGNING_KEY_ALIAS ve SIGNING_KEY_PASSWORD. Upload anahtarını güvenli tutun;
anahtar/parolaları kaynak koda eklemeyin. Debug APK yalnızca cihaz testi içindir.

V5 NOTU: Yapı elemanları için U değeri seçenekleri sadeleştirilmiştir. Listeden yalıtım seviyesini seçebilir veya Manuel değer gir seçeneğini kullanabilirsiniz. Ön seçimler yaklaşık değerlerdir; kesin proje değerleri yapı detaylarından doğrulanmalıdır.


V6 NOTU: Türkiye'nin 81 ili için yaklaşık dış hava sıcaklığı başlangıç değerleri eklendi. Bu değerler resmî/standart tasarım koşulu değildir; proje bazında meteoroloji veya kabul edilen tasarım iklim verileriyle doğrulanmalıdır. Cam güneş kazancı yön ve gölgeleme katsayısıyla yaklaşık düzeltilir. Taze hava yükü, entalpi kuru hava kütlesi bazında hesaplanacak şekilde güncellendi. Sıcaklık girişlerinde negatif değer desteği eklendi.

V9: Android WebView native PrintManager bridge eklendi. Raporu yazdır/PDF butonu Android yazdırma ekranını açar; hedef olarak 'PDF olarak kaydet' seçilerek dosya kaydedilebilir. Android cihazda gerçek çıktı testi yapılmalıdır.


V10: Yaz/kış tasarım koşulu alanları, ilçe/proje konumu, tasarım verisi kaynağı seçimi ve basınç kaynağı seçimi eklendi. Şehir profilleri ön kabul niteliğindedir; resmî meteorolojik tasarım verisi değildir. Kış sıcaklığı V10’da kayıt/raporlama girdisidir; ısıtma yükü hesabı henüz eklenmemiştir.

V11: Kış tasarım dış hava sıcaklığı girildiğinde yaklaşık ısıtma yükü ön hesabı gösterilir. Bu hesap; duvar, çatı, zemin, cam iletimi ve taze hava/infiltrasyon duyulur kaybını içerir. Zemin için dış hava farkı kullanımı basitleştirilmiştir; profesyonel proje hesabında döşeme/zemin ve komşu hacim koşulları ayrıca doğrulanmalıdır.

V11.1 düzeltmesi: Kış tasarım dış hava sıcaklığı alanı metin girişi olarak değiştirildi; negatif değerler ve virgüllü ondalık girişler (ör. -8,5) desteklenir.


V11.2 DÜZELTMELERİ
- Ekranda görünen hatalı \\n metni kaldırıldı.
- Kış tasarım sıcaklığı boş bırakıldığında önceki ısıtma sonucu kayıt hafızasından temizlenir.


V12.0 – GOOGLE PLAY HAZIRLIK AŞAMASI
- compileSdk ve targetSdk 36 olarak güncellendi.
- Android Gradle Plugin 8.10.1 ve Gradle 8.11.1 kullanılır.
- GitHub Actions artık test için debug APK ve yayın hazırlığı için release AAB üretir.
- Üretilen release AAB henüz imzalı değildir; Google Play'e yüklemek için güvenli upload keystore/signing yapılandırması ayrıca yapılmalıdır.
- Google Play Billing henüz eklenmedi. Professional/ısıtma kilidi satın alma doğrulaması tamamlanana kadar etkinleştirilmemelidir.
- Ürün kimliği planı: hvac_pro_professional_lifetime (tek seferlik, tüketilmeyen ürün). Fiyat hedefi 349 TL; Play Console'da ayrıca tanımlanacaktır.


HVAC PRO V12.2
- Isıtma hesabı ücretsiz sürümde Professional kilidi arkasına alındı.
- Şehir değişince kış dış hava sıcaklığı için rakıma dayalı yaklaşık ön kabul değeri doldurulur.
- Bu değer resmî tasarım meteoroloji verisi değildir; mühendislik projesinde doğrulanmalıdır.
- Google Play Billing henüz entegre değildir; uygulama şu anda ödeme almaz.
- Version code: 15, version name: 12.2.


V12.4 değişikliği: PDF raporu oluşturma/kaydetme işlemi Professional satın alma kontrolüne bağlandı. Google Play Billing henüz entegre değildir; doğrulanmış satın alma olmadan PDF dışa aktarımı açılmaz.


V12.4 ARAYÜZ GÜNCELLEMESİ
- Kurumsal lacivert, mavi ve beyaz renk paleti yenilendi.
- Ana gezinme menüsü mobil uyumlu alt menüye taşındı.
- Hesaplama ve Professional işlevleri korunmuştur.

V12.7: Professional mühendislik araçları arayüzü ve hesap fonksiyonları eklendi: kanal kesiti, Darcy-Weisbach düz/yerel basınç kaybı, kapasite kontrolü, çoklu mahal yük özeti ve ısıtma ön hesabı. Billing entegrasyonu henüz yoktur; HVAC_PRO_ENTITLED false olduğu için araçlar satın alma doğrulanana kadar kilitlidir. Sonuçlar ön boyutlandırma niteliğindedir.

V12.7: Kanal basınç kaybında Reynolds ve Swamee-Jain otomatik Darcy faktörü; esnek çoklu mahal (30 mahal); ısıtma hesabında zemin/komşu hacim sıcaklığı ve taze hava ısı geri kazanım verimi; giriş doğrulama iyileştirmeleri.


HVAC PRO V12.8
- Giriş doğrulamaları: bağıl nem 0–100%, basınç 50–120 kPa, emniyet payı 0–50%.
- Kanal debisi/hız/ölçü doğrulamaları ve boş giriş hatası düzeltildi.
- Basınç kaybı giriş sınırları güçlendirildi; geçiş rejimi uyarısı korunur.
- Soğutma emniyet payı, negatif net yükte yanlış pozitif gösterim üretmeyecek şekilde ayrıştırıldı.
- Isıtma hesabında tasarım sıcaklığı, zemin sıcaklığı, HRV verimi ve emniyet payı doğrulaması eklendi.
Not: Kaynak kodu düzeyinde güncellenmiştir. Android cihaz testi, resmi standart doğrulaması ve Google Play Billing entegrasyonu ayrıca yapılmalıdır.


HVAC PRO V13.0 – YAYIN HAZIRLIK PAKETİ
======================================
- Android versionName 13.0 / versionCode 24.
- Mevcut hesaplama ekranları ve Professional kilitleri korunmuştur.
- Uygulama içi gizlilik politikası ve kullanım kılavuzu HTML sayfaları eklenmiştir.
- PLAY_STORE_MATERIALS klasöründe Türkçe/İngilizce mağaza metin taslakları,
  gizlilik politikası taslağı, veri güvenliği hazırlık notları ve test planı bulunur.
- web/ klasöründe GitHub Pages için basit tanıtım sitesi taslağı vardır.

YAYIN ÖNCESİ ZORUNLU İŞLER:
1. Google Play hesabı kimlik doğrulaması tamamlanmalıdır.
2. hvac_pro_professional_lifetime ürünü Play Console'da tanımlanmalıdır.
3. Gerçek Google Play Billing ve güvenli satın alma doğrulaması yapılmalıdır.
4. Gizlilik politikasındaki [İLETİŞİM E-POSTASI] ve [GELİŞTİRİCİ/İŞLETME ADI]
   alanları doldurulup HTTPS üzerinden yayımlanmalıdır.
5. Data safety formu nihai APK, SDK'lar ve gerçek veri akışına göre tamamlanmalıdır.
6. Release APK/AAB için GitHub Actions imzalama secrets yapılandırması gerekir; imza ve derleme sonucu her workflow çalışmasında doğrulanmalıdır.
7. Kapalı test, cihaz testleri ve mühendislik doğrulaması tamamlanmalıdır.

GitHub Actions:
Kök .github/workflows/build-apk.yml dosyası depo kökünde korunmalıdır.


V13.1 IKON GUNCELLEMESI
Android launcher adaptive/round/monochrome ikonlari eklendi. Google Play 512x512 ikonu PLAY_STORE_MATERIALS klasorundedir.

V13.1.1 DERLEME DÜZELTMESİ
- Android manifest teması AppTheme olarak ayarlandı.
- androidx.core.splashscreen'e ait olmayan android:postSplashScreenTheme
  özniteliği kaldırıldı. Android'in sistem splash arka planı/ikon kaynakları korundu.
- versionCode 26 / versionName 13.1.1.

V13.2 TEMA GUNCELLEMESI
- Uygulama arayuzu ikonun lacivert/mavi/buz mavisi/turuncu marka paletine uyarlandi.
- Kartlar, alanlar, alt menu, butonlar ve sonuc panelleri koyu tema kontrastina gore duzenlendi.
- Baslik alanindaki kar tanesi yerine HVAC PRO marka ikonu eklendi.
- PWA theme_color ve background_color degerleri koyu marka temasina alindi.
- versionCode 27 / versionName 13.2.

V13.3: Kullanım kılavuzu tam İngilizce çeviriyle dil seçimine bağlandı. Harici kılavuz da dil seçicili. Üst marka alanı daha kompakt ve hizalı hale getirildi. VersionCode 28 / VersionName 13.3.

V13.4: English UI dictionary expanded for remaining calculation, fresh-air, project, Professional and engineering labels/help text. Language switching now also translates placeholders, titles, aria-labels and select options. VersionCode 29 / VersionName 13.4.

V13.5: English translation dictionary expanded for guide/report/static explanatory content. Text translation now applies to dynamically generated result and message nodes through a MutationObserver, and restores original Turkish text when switching back. VersionCode 30 / VersionName 13.5.

V13.5.1: JavaScript alert messages also pass through the active language dictionary. VersionCode 31 / VersionName 13.5.1.


V13.6: English-language dictionary structure corrected so the full translation set is actually available under the English locale. Navigation labels retain their icons, selected language is remembered on the device, and the language selector restores the saved choice on startup. JavaScript syntax validation passed. VersionCode 32 / VersionName 13.6.


PDF GELISTIRICI TEST MODU (V13.6.10)
- PDF raporu, yalnizca Android'in debug APK derlemesinde satin alma olmadan test edilebilir.
- GitHub Actions'in debug APK ciktisini kurarak Turkce ve Ingilizce PDF olusturmayi deneyin.
- Bu izin Android BuildConfig.DEBUG degerinden gelir; release derlemelerinde false olur.
- Release/Google Play surumunde PDF Professional satin alma kilidi korunur.
- Test modu diger Professional ozelliklerini acmaz.


V13.6.12 – ISITMA SONUÇ AYRIMI VE GÖRÜNÜRLÜK
- Isı geri kazanımı yalnızca mekanik taze hava debisine uygulanır; infiltrasyon ayrı ve geri kazanımsız hesaplanır.
- Isıtma sonuçlarında taze hava kaybı, infiltrasyon kaybı ve toplam havalandırma kaybı ayrı satırlarda gösterilir.
- Nihai ısıtma yükü satırında açık zemin/koyu yazı kontrastı düzeltildi.
- Uygulama başlığı/altbilgisi ve Android versionName 13.6.12, versionCode 44 olarak eşitlendi.
- Debug APK'da Professional test erişimi korunur; release sürümünde debug erişimi etkin değildir. Google Play Billing hâlâ entegre değildir.
- JavaScript sözdizimi ve ısı geri kazanımı/infiltrasyon regresyon vektörü kontrol edilmiştir. Bu ortamda Android APK derlemesi ve cihaz testi yapılmamıştır.


HVAC PRO V13.6.20 – İKLİM VERİSİ GÜVENLİK GÜNCELLEMESİ
- Yaz tasarım kuru termometre, eş zamanlı yaş termometre ve kış tasarım sıcaklığı doğrulanmış istasyon verisi olmadığı için null bırakıldı.
- Rakımdan kış tasarım sıcaklığı türeten bilimsel temeli olmayan otomatik yaklaşım kaldırıldı. Kış tasarım sıcaklığı kullanıcı tarafından kaynaklı olarak girilmelidir.
- Malatya rakımı MGM istasyon sayfasındaki 950 m değerine güncellendi; yaz/kış tasarım sıcaklıkları doğrulanana kadar resmi tasarım verisi olarak gösterilmez.
- Diğer şehirlerin mevcut rakım/yaz sıcaklığı/nem başlangıç değerleri açıkça yaklaşık ve doğrulanmamış olarak etiketlendi.
- Rakımdan hesaplanan basınç standart atmosfer tahminidir; ölçülmüş istasyon basıncı değildir.
- Android versionName 13.6.20 / versionCode 52.
- Kaynak kod paketi güncellendi; Android APK derlemesi ve gerçek cihaz regresyonu ayrıca yapılmalıdır.
- Şehir değişiminde kış tasarım sıcaklığı artık rakımdan türetilmez; boş bırakılır. Kaynağı doğrulanmış kış tasarım değeri girilmeden ısıtma hesabı çalışmaz. Malatya istasyonu rakım başlangıcı 950 m olarak güncellendi; yaz/kış tasarım sıcaklıkları doğrulanmış kabul edilmez.


HVAC PRO V13.6.21 – V20 KAYNAK DENETİMİ VE GİRİŞ GÜVENLİĞİ
- VersionCode 53 / versionName 13.6.21.
- Soğutma/ısıtma hesabı öncesi ortak sayısal giriş doğrulaması eklendi. Boş, aralık dışı, negatif veya SHGC/gölgeleme sınırını aşan değerler sessizce sıfıra çevrilerek sonuç üretemez.
- Taze hava debisi hesaplayıcısına ayrı giriş doğrulaması eklendi.
- Taze hava duyulur/gizli yük hesabı test edilebilir ortak fonksiyona ayrıldı; entalpi dengesi ve serbest soğutma işaret davranışı için referans testleri eklendi.
- Geçersiz girdilerle eski sonuç üzerinden PDF raporu oluşturma ve proje kaydetme engellendi. Girdi değişince eski ısıtma sonucu ekranda kalmaz.
- Tavan yüksekliğinin mevcut soğutma yükü modelinde kullanılmadığı arayüzde açıkça belirtildi.
- scripts/qa_validate.js; HTML ID/sözdizimi, 81 il iklim verisi tutarlılığı ve psikrometrik/entalpi referans vektörlerini denetler. scripts/qa_validate_project.py Android XML, Gradle, CSV/JSON ve GitHub derleme yapılandırmasını denetler. GitHub Actions bu testleri APK/AAB derlemesinden önce çalıştırır.
- Resmî MGM tasarım meteoroloji verisi, Google Play Billing, release imzalama ve gerçek Android cihaz/PDF testi bu kaynak paketiyle otomatik olarak doğrulanmış sayılmaz; ayrı tamamlanmalıdır.


HVAC PRO V13.6.29 – GÜNCEL KAYNAK PAKETİ DURUMU
- Android versionName 13.6.29 / versionCode 59.
- GitHub Actions artifact adı HVAC-PRO-v13.6.29-packages olarak eşitlendi.
- Workflow; iklim varlığı üretimi, JavaScript QA, Android yapısal QA, debug APK, imzalı release APK/AAB ve lint adımlarını çalıştırır.
- Bu kaynak denetiminde statik QA betikleri başarılıdır; Gradle derlemesi, Android lint ve gerçek cihaz/PDF testi bu ortamda çalıştırılmış sayılmaz.
- Google Play Billing henüz entegre değildir.
- Üretim assets klasöründeki tamamlanmış Android geliştirici doğrulama challenge dosyası kaldırılmıştır.


V13.6.29 QA ERİŞİMİ
- Debug APK: Mevcut uygulamada geliştirilmiş Professional özellikleri QA amacıyla açıktır (ısıtma, psikrometri, proje kaydı/yönetimi, mühendislik araçları ve PDF).
- Release APK/AAB: Professional erişimi Google Play Billing ile doğrulanmış satın alma gelene kadar kilitli kalır.
- Bu değişiklik yeni modüller eklemez; yalnızca mevcut Professional işlevlerinin debug sürümünde test edilmesini sağlar.
- Isıtma ve diğer hesaplar ön boyutlandırma niteliğindedir; proje özelinde teknik doğrulama gerekir.


V13.6.29 GELİŞMİŞ PSİKROMETRİ
- Hava karışımı kuru hava kütle dengesiyle hesaplanır.
- Isıtma, soğutma, nemlendirme ve nem alma prosesleri eklenmiştir.
- Isıl kapasite ve su transferi, girilen giriş/çıkış durumlarından hesaplanır.
- Ayrıntılar ve sınırlar CHANGELOG_V13_6_29.md dosyasındadır.

GUNCEL SURUM: HVAC PRO 13.6.36 (versionCode 66)
Yeni moduller: pompa Q-H / sistem egri kesisim analizi ve menfez-difuzor standart yuz olcusu on secimi. Pompa egri verileri uretici kataloglarindan girilmelidir.


V13.6.54 – Konum seçimi ve modül sayfaları
- Küresel iklim arama/gateway ve uygulama içine gömülü iklim veri dosyaları kaldırıldı.
- Ülke seçimi sonrası şehir seçimi: Türkiye'nin 81 ili çevrimdışı; diğer ülkeler için kullanıcı tarafından başlatılan Photon şehir araması (internet gerekir).
- Şehir araması yalnızca konum adını sağlar; iklim/tasarım hava verisi getirmez. Tasarım koşulları kullanıcı tarafından güvenilir kaynaktan girilmelidir.
- Şehir adı ve ülke kodu Photon/OSM konum arama servisine gönderilir; proje hesap verileri gönderilmez.
- Ana menü başlangıç ekranı oldu. Soğutma, ısıtma, taze hava, kanal, hidronik, psikrometri ve cihaz menüleri ayrı çalışma sayfalarına açılır; geri dönüş bağlantıları eklendi.

PRO ERİŞİM KAPSAMI – 13.6.74
--------------------------------
Professional (planlanan tek seferlik fiyat: 349 TL) kapsamı: ısıtma hesabı, tüm bağımsız PDF raporları, gelişmiş psikrometri, kanal tasarımı ve 2D kanal stüdyosu, fan/pompa, hidronik, AHU/cihaz kontrolleri, VRF ön hesabı ve proje kaydetme/yedekleme.
Ücretsiz kapsam: temel soğutma yükü çalışma alanı ve bağımsız taze hava hesabı.
Üretim sürümünde erişim doğrulanmış satın alma hakkı olmadan açılmaz. Debug APK'de yalnızca QA amacıyla Professional erişimi açıktır.
ÖNEMLİ: Google Play Billing henüz entegre edilmemiştir. Bu kaynakta gerçek satın alma veya geri yükleme yapılamaz. Yayın öncesinde Play Console tek seferlik ürün tanımı, Billing bağlantısı ve sunucu/Google Play satın alma doğrulaması tamamlanmalıdır.
