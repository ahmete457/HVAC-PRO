# HVAC PRO 13.6.48 QA report

- JavaScript QA: PASS (`node scripts/qa_validate.js`)
- Android/source structural QA: PASS (`python scripts/qa_validate_project.py`)
- HTML inline scripts parse and DOM IDs are unique.
- Existing 81-city climate dataset and provenance guards retained.
- Existing psychrometric, HVAC, hydronic and duct design regression checks pass.
- New duct local-loss reference vector: K=2, rho=1.2 kg/m³, v=4 m/s => 19.2 Pa (PASS).
- New editable ΣK inputs exist for supply/return main segments and branches.
- Critical-path estimate sums sequential shared-main losses to each terminal plus that terminal branch loss.

## Not performed

- APK build and Android device/UI test were not performed in this environment.
- Fitting coefficients are user-entered; the app does not infer K from fitting geometry.
- AHU component pressure drops and free node-edge topology are not yet included.
