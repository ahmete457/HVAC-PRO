#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'app/src/main/assets/climate-data-tr.json');
const target = path.join(root, 'app/src/main/assets/climate-data-tr.js');
const data = JSON.parse(fs.readFileSync(source, 'utf8'));
if (!Array.isArray(data.cities) || data.cities.length !== 81) {
  throw new Error('Türkiye climate dataset must contain exactly 81 city records.');
}
fs.writeFileSync(target, `/* Generated from climate-data-tr.json by scripts/generate_climate_js.js. Do not edit manually. */\nwindow.HVAC_CLIMATE_DATA = ${JSON.stringify(data)};\n`);
console.log(`Generated ${path.relative(root, target)} from ${path.relative(root, source)} (${data.cities.length} cities).`);
