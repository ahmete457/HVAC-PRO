plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    // BuildConfig is required for the debug-only PDF test bridge.
    buildFeatures {
        buildConfig = true
    }
    namespace = "com.hvacpro.app"
    compileSdk = 36
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    signingConfigs {
        create("release") {
            val storePath = System.getenv("HVAC_UPLOAD_STORE_FILE")
            val storePass = System.getenv("HVAC_UPLOAD_STORE_PASSWORD")
            val keyAliasValue = System.getenv("HVAC_UPLOAD_KEY_ALIAS")
            val keyPass = System.getenv("HVAC_UPLOAD_KEY_PASSWORD")

            if (!storePath.isNullOrBlank() &&
                !storePass.isNullOrBlank() &&
                !keyAliasValue.isNullOrBlank() &&
                !keyPass.isNullOrBlank()
            ) {
                storeFile = file(storePath)
                storePassword = storePass
                keyAlias = keyAliasValue
                keyPassword = keyPass
            }
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
    defaultConfig {
        applicationId = "com.hvacpro.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 67
        versionName = "13.6.37"
    }
}
