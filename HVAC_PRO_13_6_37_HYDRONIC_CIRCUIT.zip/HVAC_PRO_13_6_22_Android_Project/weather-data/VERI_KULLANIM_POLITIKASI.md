# HVAC PRO – Türkiye iklim verisi çalışma dosyası

Bu CSV, uygulamadaki mevcut 81 il ön kabul profilini dışarı alır. Değerler resmî tasarım meteoroloji verisi olarak doğrulanmış değildir.

## Güven sınıfları
- **A:** İstasyon, ölçüm dönemi, kaynak doküman ve tasarım yüzdelikleri doğrulanmış; uygulamada tasarım girdisi olarak kullanılabilir.
- **B:** Akademik/tarihsel kaynak mevcut, ancak dönem veya istasyon eşleştirmesi güncel proje için ayrıca kontrol gerektirir.
- **C:** Yaklaşık/ön kabul veya kaynağı doğrulanmamış; yalnızca kullanıcı tarafından düzenlenebilir başlangıç girdisi olabilir. Otomatik mühendislik tasarım değeri olarak sunulamaz.

## Tasarım verisi için zorunlu kayıt
Her istasyon kaydında istasyon adı/kodu, koordinat, istasyon rakımı, kaynak kuruluş/doküman, veri dönemi, yaz tasarım kuru termometre ve eş zamanlı yaş termometre koşulu, kış tasarım yüzdeliği (ör. %99,6) ve doğrulama notu tutulmalıdır. İl merkezi rakımı meteoroloji istasyonu rakımı yerine kullanılamaz.

## Uygulama davranışı
Şehir profilleri ön kabul olarak kalır. İstasyon, dönem ve kaynak doküman bilgisi proje kaydına ve PDF raporuna yazılır. Kullanıcı “Resmî tasarım meteoroloji verisi” seçerse bu üç alan zorunludur; alanların doldurulması tek başına verinin doğruluğunu kanıtlamaz. Kuru/yaş termometre eşzamanlılığı ve tasarım yüzdelikleri kaynak dokümandan ayrıca doğrulanmalıdır.

## Kaynak yaklaşımı
Öncelik MGM'nin istasyon bazlı resmî gözlem/iklim verileri ve kabul edilen tasarım iklim veri setleridir. Akademik tarihsel tablolar B sınıfı referans olarak tutulabilir; güncel ve doğrudan tasarım girdisi gibi etiketlenmemelidir. Kaynağı bulunmayan il değerleri A sınıfına yükseltilmez.
