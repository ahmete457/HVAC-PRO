plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    // BuildConfig is required for the debug-only PDF test bridge.
    buildFeatures {
        buildConfig = true
    }
    namespace = "com.hvacpro.app"
    compileSdk = 36
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    defaultConfig {
        applicationId = "com.hvacpro.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 47
        versionName = "13.6.15"
    }
}
